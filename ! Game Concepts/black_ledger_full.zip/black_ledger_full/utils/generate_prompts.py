#!/usr/bin/env python3
"""Genereer alle Black Ledger Full Build prompts.

Structuur: Fase → Sub → Prompt.
Elke prompt krijgt consistent template met context, taken, testing, git.
"""
from pathlib import Path
import json

BASE = Path("/home/claude/black_ledger_full")

# ============================================================
# PROMPT DEFINITIES
# Elke prompt: (nummer, fase_dir, sub_dir, titel, doel, taken_count, deps, context)
# ============================================================

PROMPTS = []

# ============================================================
# FASE F - CONTENT EXPANSION (43-120)
# ============================================================

# F1 - Additional Ships (43-58, 16 prompts)
F1_SHIPS = [
    ("USP Razor", "interceptor klasse - high speed low armor"),
    ("USP Guardian", "defender klasse - balanced all-round"),
    ("USP Crusher", "heavy fighter - hoge damage lagere speed"),
    ("Helios Enforcer playable", "na boss verslaan, ship captureable"),
    ("Helios Corvette", "medium combat ship"),
    ("Harkon Reaver variant", "scout variant vs eerder vieglbaar"),
    ("Harkon Executioner", "elite Harkon assassin ship"),
    ("Marshal Patrol variant", "lawful patrol ship"),
    ("Ghost Market Specter", "stealth smuggler"),
    ("Phantom Shade", "mysterious faction ship"),
    ("Fringe Hauler", "large cargo ship"),
    ("Drifter Wraith", "unique, one-shot encounter ship"),
]

for i, (name, desc) in enumerate(F1_SHIPS):
    nr = 43 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "F_content",
        "sub": "f1_ships",
        "fname": f"prompt_{nr:03d}_ship_{name.lower().replace(' ', '_').replace('-', '_')}.md",
        "titel": f"Ship: {name}",
        "doel": f"Implementeer {name} ({desc}) als bespelbaar/encounterable ship.",
        "taken": [
            f"Genereer ship stats (HP, shield, speed, agility, cargo) gebalanceerd tegen USP Talon baseline",
            f"NOVA asset pipeline: FreeCAD → Blender → Aseprite voor ship sprite (4 damage states × 8 angles)",
            f"Maak `scripts/ships/{name.lower().replace(' ', '_')}.gd` class die van BaseShip erft",
            f"Component mount points: weapons, engines, cargo config volgens {name} archetype",
            f"Balance-gecheck door Agent 10 Game Balance Jury",
            f"Toevoegen aan ship database in `resources/ship_database.tres`",
        ],
        "deps": list(range(43, nr)) + [4, 10, 17, 18],  # MVP prompts + vorige F1
        "context": f"""MVP: USP Talon basisklasse bestaat.
Eerdere ships in F1: {', '.join(f[0] for f in F1_SHIPS[:i]) if i > 0 else 'geen'}.
Design ref: docs/SHIP_CATALOG.md voor archetype definities.
Canon ref: docs/CANON_COMPLETE.md voor faction ship aesthetics.""",
        "testing": [
            f"Ship spawnt correct in Godot scene",
            f"Alle stats werken zoals gespecificeerd",
            f"Sprite sheet loadt zonder errors",
            f"Balance Jury verdict: accept (acceptabel binnen tolerance van baseline)",
            f"Animation states (idle/hit/destroyed) werken",
        ],
        "time_estimate": "2-3 uur",
    })

# Eindig met 4 variant upgrades (59-62 wordt F1 vervolg met ship variants)
# Correctie: F1 is 16 prompts, dus 43-58. 43+16=59, dus F2 start 59.
# Maar we hebben maar 12 ships = 12 prompts. Voeg 4 "ship variant" prompts toe.

F1_VARIANTS = [
    ("Ship damage states per faction", "paint schemes per faction op elk ship"),
    ("Ship class database complete", "centralized metadata voor alle ships"),
    ("Ship acquisition system", "shop + mission reward + capture"),
    ("Ship inspection UI", "detailed stats screen voor shop"),
]

for i, (name, desc) in enumerate(F1_VARIANTS):
    nr = 55 + i  # 55-58
    PROMPTS.append({
        "nr": nr,
        "fase": "F_content",
        "sub": "f1_ships",
        "fname": f"prompt_{nr:03d}_{name.lower().replace(' ', '_')}.md",
        "titel": name,
        "doel": desc,
        "taken": [
            "Implementeer core systeem volgens naam",
            "Integreer met bestaande ships uit prompts 43-54",
            "UI/UX waar relevant",
            "Save/load ondersteuning",
            "Test cases",
        ],
        "deps": list(range(43, nr)) + [4, 10, 17, 18],
        "context": f"Ship prompts 43-54 voltooid. Nu systemen voor ship management.",
        "testing": [
            "Functionaliteit werkt zoals beschreven",
            "Integreert met MVP save/load",
            "Geen regressions in MVP features",
        ],
        "time_estimate": "2-3 uur",
    })

# F2 - Complete Factions (59-72, 14 prompts)
F2_FACTIONS = [
    ("Helios Mandate core", "already enemy, make fully interactive met NPC dialogs"),
    ("Helios patrol behavior", "AI patrol routes door systems"),
    ("Helios reputation consequences", "hoe reputation met Helios alles beinvloedt"),
    ("Marshal Corps core", "sheriff faction systeem"),
    ("Marshal bounty assignments", "Marshal geeft bounty missies"),
    ("Marshal reputation deep", "vertrouwen/wantrouwen branching"),
    ("Ghost Market core", "black market NPC's + hidden stations"),
    ("Ghost Market prices", "black market prijsdifferenties"),
    ("Phantom Fleet mystery", "Phantom only glimpses, never direct contact"),
    ("Phantom Easter eggs", "hidden lore over Phantom"),
    ("Fringe Settlers core", "civilians, quest givers, helpers"),
    ("Fringe mini-economy", "Fringe settlements unieke goederen"),
    ("Faction war events", "factions vechten elkaar dynamisch"),
    ("Faction-cross missions", "missies die 2+ factions raken"),
]

for i, (name, desc) in enumerate(F2_FACTIONS):
    nr = 59 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "F_content",
        "sub": "f2_factions",
        "fname": f"prompt_{nr:03d}_{name.lower().replace(' ', '_').replace('-', '_')}.md",
        "titel": name,
        "doel": desc,
        "taken": [
            f"Implementeer faction systeem voor {name}",
            "Canon-conforme dialoog lines (via Agent 07 Narrative Jury)",
            "Reputation effects op gameplay",
            "NPC sprites + portraits via NOVA pipeline",
            "Integreren met bestaande reputation uit MVP prompt 39",
            "Documentatie update in CANON_COMPLETE.md",
        ],
        "deps": list(range(43, nr)) + [7, 17, 39],
        "context": f"MVP heeft basic reputation voor Harkon + Marshal. Nu uitbreiden naar alle 6 factions met deep mechanics.",
        "testing": [
            "NPCs spawnen en acteren volgens faction behavior",
            "Reputation verandert correct bij player actions",
            "Dialoog lines zijn canon-conform (Narrative Jury accept)",
            "Geen conflict met bestaande factions",
        ],
        "time_estimate": "3-4 uur",
    })

# F3 - Weapons (73-82, 10 prompts)
F3_WEAPONS = [
    "Plasma Cannon", "Fusion Missile", "Railgun", "Ion Cannon",
    "Cluster Bomb", "Mine Layer", "Tractor Beam", "Shield Drainer",
    "Weapon mod system (chips/upgrades)",
    "Weapon shop + crafting UI",
]
for i, name in enumerate(F3_WEAPONS):
    nr = 73 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "F_content",
        "sub": "f3_weapons",
        "fname": f"prompt_{nr:03d}_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('/', '_')}.md",
        "titel": name,
        "doel": f"Implementeer {name} met balance, VFX en audio.",
        "taken": [
            f"Stats definitie (damage, fire rate, energy cost, range)",
            "Projectile of effect scene",
            "VFX (muzzle flash, impact, trail)",
            "Audio (fire, impact, reload)",
            "Balance-check door Agent 10",
            "Toevoegen aan weapon database",
        ],
        "deps": list(range(43, nr)) + [11, 12, 13, 14, 18, 35],
        "context": "MVP heeft 3 weapons (pulse, missile, EMP). Nu systeem uitbreiden naar 15 totaal.",
        "testing": [
            "Weapon fires + damages correct",
            "VFX + audio sync",
            "Niet overpowered vs MVP baseline",
            "Shop kan weapon verkopen + buyen",
        ],
        "time_estimate": "2-3 uur",
    })

# F4 - Enemies (83-94, 12 prompts)
# 6 factions × 9 variants = 54 sprite groups maar als prompts clusteren per faction
F4_ENEMY_PROMPTS = [
    ("Harkon enemy roster (9 variants)", "Scout, Interceptor, Bomber, Gunship, Destroyer, Elite, Commander, Suicide, Drone"),
    ("Helios enemy roster", "Patrol, Enforcer, Hunter, Assault, Defense, Commander, Priest class, Zealot, Drone"),
    ("Marshal enforcement roster", "Patrol, Investigator, Pursuer, Heavy, Warden, Captain, K9, Mech, Drone"),
    ("Ghost Market roster", "Smuggler, Stealth, Trickster, Broker, Contract killer, Boss, Mule, Spy, Drone"),
    ("Phantom roster", "Shade, Wraith, Apparition, Voidling, Harbinger, Architect, Whisper, Echo, Phantom Drone"),
    ("Fringe defender roster", "Homesteader, Militia, Veteran, Mayor, Preacher, Hermit, Colonist, Kid, Drone"),
    ("Von Neumann drones (cross-faction)", "ancient threat, spawnt random, high priority target"),
    ("Enemy AI base class polish", "verbeterde AI behaviors: flee, flank, group tactics"),
    ("Enemy spawn director", "context-aware spawning based on location + reputation"),
    ("Boss enemies catalog", "5 boss types buiten Helios Enforcer uit MVP"),
    ("Elite encounter system", "5% chance op elite variant met buff + betere loot"),
    ("Enemy dialog barks", "enemies praten: taunts, warnings, death cries"),
]
for i, (name, desc) in enumerate(F4_ENEMY_PROMPTS):
    nr = 83 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "F_content",
        "sub": "f4_enemies",
        "fname": f"prompt_{nr:03d}_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:60]}.md",
        "titel": name,
        "doel": desc,
        "taken": [
            "Sprite generation via NOVA pipeline (Design Fase + FreeCAD + Blender + Aseprite)",
            "GDScript AI per variant in `scripts/enemies/<faction>/`",
            "Balance table per variant (HP, DPS, reward)",
            "Animation states compleet",
            "Audio hooks",
            "Database update",
        ],
        "deps": list(range(43, nr)) + [14, 15, 16, 17],
        "context": f"MVP heeft rookie + veteran enemies generic. Nu faction-specific rosters.",
        "testing": [
            "Alle 9 variants spawnen correct",
            "AI behavior verschilt per variant",
            "Sprite quality via Agent 01 Sprite Jury accept",
            "Balance binnen tolerance (Agent 10 accept)",
        ],
        "time_estimate": "4-6 uur",
    })

# F5 - Stations (95-104, 10 prompts)
F5_STATIONS = [
    "Korrigan-3 upgrade", "Marshal Outpost Alpha", "Helios Central",
    "Ghost Market hidden hub", "Fringe Homestead Beta", "Drifter's Rest",
    "Abandoned Research station", "Pirate Den Kappa",
    "Station services framework", "Station travel + docking",
]
for i, name in enumerate(F5_STATIONS):
    nr = 95 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "F_content",
        "sub": "f5_stations",
        "fname": f"prompt_{nr:03d}_{name.lower().replace(chr(39), '').replace(' ', '_').replace('-', '_').replace('+', 'and')}.md",
        "titel": name,
        "doel": f"Implementeer {name} als volledig ingame locatie.",
        "taken": [
            "Station interior background art",
            "Services layout (shop, mission board, character interaction)",
            "Unique NPCs per station",
            "Docking sequence",
            "Travel integratie met starmap (F61+ G1 prep)",
            "Save/load station-specific state",
        ],
        "deps": list(range(43, nr)) + [28, 29, 30, 31],
        "context": "MVP heeft Korrigan-3 station. Nu 7 extra stations + services framework.",
        "testing": [
            "Station loadt + rendert correct",
            "Services werken (shop + mission board + NPCs)",
            "Docking/undocking smooth",
            "State persists na quit/load",
        ],
        "time_estimate": "3-4 uur",
    })

# F6 - Levels (105-120, 16 prompts)
F6_LEVELS = [
    "Level 2 - Korrigan Asteroid Belt",
    "Level 3 - Harkon Ambush Zone",
    "Level 4 - Helios Patrol Gauntlet",
    "Level 5 - Marshal Escort Mission",
    "Level 6 - Nebula Run",
    "Level 7 - Ghost Market Raid",
    "Level 8 - Space Station Defense",
    "Level 9 - Wreck Salvage",
    "Level 10 - Mid-boss: Harkon Executioner",
    "Level 11-14 - Helios Invasion Arc (4 levels)",
    "Level 15-17 - Fringe Rescue Arc (3 levels)",
    "Level 18-20 - Phantom Discovery Arc (3 levels)",
    "Level 21-23 - Revenge Arc part 1 (3 levels)",
    "Level 24-26 - Revenge Arc part 2 (3 levels)",
    "Level 27 - Pre-finale",
    "Level 28 - The Ledger Confrontation (Final)",
]
for i, name in enumerate(F6_LEVELS):
    nr = 105 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "F_content",
        "sub": "f6_levels",
        "fname": f"prompt_{nr:03d}_{name.split(' - ')[0].lower().replace(' ', '_')[:30]}.md",
        "titel": name,
        "doel": f"Bouw {name} als speelbaar level.",
        "taken": [
            "Level design (wave patterns, spawn points, boss placement)",
            "Background art (parallax layers) via NOVA pipeline",
            "Music track via Audiocraft (Agent 29)",
            "Level-specific events (dialog, cutscenes)",
            "Balance tuning (difficulty curve)",
            "Save point + checkpoint system",
        ],
        "deps": list(range(43, nr)) + [19, 20, 21],
        "context": "MVP heeft level 1 (Korrigan-3 escape) + boss. Nu 27 extra levels volgens narrative arc.",
        "testing": [
            "Level speelbaar start-to-finish",
            "Difficulty voelt progressief (niet plotse spike)",
            "Story events triggeren correct",
            "Geen performance issues",
        ],
        "time_estimate": "3-5 uur",
    })

# ============================================================
# FASE G - DEEP SYSTEMS (121-190)
# ============================================================

# G1 - Starmap (121-134, 14 prompts)
G1_STARMAP = [
    "Starmap data structure (systems + jumpholes)",
    "Starmap UI rendering (2D map view)",
    "System selection + info panel",
    "Jumphole entry + travel animation",
    "Hyperspace travel sequence",
    "System discovery mechanic (fog of war)",
    "Wormhole secret travel (rare jumps)",
    "Route planner (auto-path)",
    "Scan range + detection mechanic",
    "Starmap bookmarks + notes",
    "Pirate zones + safe zones",
    "Trade lane visualization",
    "Emergency jump (hotkey)",
    "Starmap canvas polish",
]
for i, name in enumerate(G1_STARMAP):
    nr = 121 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "G_systems",
        "sub": "g1_starmap",
        "fname": f"prompt_{nr:03d}_starmap_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor starmap navigatie.",
        "taken": [
            "Data model in GDScript resource",
            "UI element in main scene hierarchy",
            "Input handling",
            "Save/load integratie",
            "Visual polish (animations, feedback)",
            "Test cases",
        ],
        "deps": list(range(43, nr)) + [99, 100],
        "context": "Referentie: docs/STARMAP_DESIGN.md voor volledig design. Vergelijk met Wing Commander Privateer starmap.",
        "testing": [
            "UI loadt + respond",
            "Navigation werkt end-to-end",
            "Save/load behoudt state",
            "Performance OK met 50+ systems",
        ],
        "time_estimate": "2-4 uur",
    })

# G2 - Datapad (135-152, 18 prompts)
G2_DATAPAD = [
    "Datapad core UI (3-column layout)",
    "Datapad entry data structure",
    "Ledger Book primary view",
    "News entries type + rendering",
    "Mission entries type",
    "Intel entries type (scans, tips)",
    "Contact entries type (NPCs)",
    "Cargo manifest entries",
    "Bounty intel entries",
    "Faction reputation summary entry",
    "Cross-reference engine core",
    "Cross-reference UI overlay",
    "Entry categorization + filtering",
    "Entry search (full-text)",
    "Entry timeline view",
    "Entry bookmark system",
    "Datapad shortcut keys + hotbar",
    "Datapad polish + animations",
]
for i, name in enumerate(G2_DATAPAD):
    nr = 135 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "G_systems",
        "sub": "g2_datapad",
        "fname": f"prompt_{nr:03d}_datapad_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor datapad systeem.",
        "taken": [
            "Entry class of UI component in Godot",
            "Integratie met bestaande systems (missions, cargo, npc)",
            "Visual design volgens docs/DATAPAD_SYSTEM.md",
            "Cross-references auto-detection (via Agent 28)",
            "Save/load support",
            "Testing",
        ],
        "deps": list(range(43, nr)) + [28],
        "context": "Ref: docs/DATAPAD_SYSTEM.md. Dit is het Ledger Book - zeer centraal in Black Ledger.",
        "testing": [
            "Entry rendering correct",
            "Cross-references werken",
            "Filtering + search responsief",
            "Geen XP-drop bij veel entries (100+)",
        ],
        "time_estimate": "2-4 uur",
    })

# G3 - Cargo (153-164, 12 prompts)
G3_CARGO = [
    "Cargo hold data structure",
    "Cargo item catalog (150+ items)",
    "Cargo weight + volume constraints",
    "Station trading UI",
    "Market price fluctuations",
    "Cargo scan mechanic (detection)",
    "Contraband flagging system",
    "Illegal goods penalties",
    "Cargo jettison + salvage",
    "Cargo mission integration",
    "Cargo capture from destroyed ships",
    "Cargo UI polish",
]
for i, name in enumerate(G3_CARGO):
    nr = 153 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "G_systems",
        "sub": "g3_cargo",
        "fname": f"prompt_{nr:03d}_cargo_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor cargo systeem.",
        "taken": [
            "Data model + Godot resource",
            "Integration met ship system (cargo bay)",
            "UI element waar relevant",
            "Economy integration (prices)",
            "Save/load",
            "Testing",
        ],
        "deps": list(range(43, nr)) + [4, 96],
        "context": "Privateer-inspired trading. Items kopen in systeem A, verkopen duurder in B. Cargo scan door Marshal = contraband risico.",
        "testing": [
            "Cargo adds/removes correct uit hold",
            "Weight constraints enforced",
            "Prices fluctueren per station",
            "Contraband detectie werkt",
        ],
        "time_estimate": "2-3 uur",
    })

# G4 - Bounty (165-178, 14 prompts)
G4_BOUNTY = [
    "Bounty board UI",
    "Bounty target data structure",
    "Bounty target AI (unique NPC per bounty)",
    "Bounty Ace class (recurring rivals)",
    "Bounty tracking + intel collection",
    "Bounty rewards + tiers",
    "Bounty revenge chain (NPC comes back)",
    "Bounty escalation system",
    "Notorious bounties (story-related)",
    "Bounty syndicates (groups)",
    "Bounty timer + expiration",
    "Bounty board generation algorithm",
    "Bounty completion feedback (news entry)",
    "Bounty board polish",
]
for i, name in enumerate(G4_BOUNTY):
    nr = 165 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "G_systems",
        "sub": "g4_bounty",
        "fname": f"prompt_{nr:03d}_bounty_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor bounty systeem.",
        "taken": [
            "Data model",
            "AI behavior voor bounty targets",
            "UI integratie (bounty board station view)",
            "Reward distribution",
            "Narrative hooks (news, dialog)",
            "Testing",
        ],
        "deps": list(range(43, nr)) + [37, 38],
        "context": "MVP heeft basic bounty missie. Nu full system met Aces, chains, notorious targets.",
        "testing": [
            "Bounties genereren zinnig",
            "Targets spawnen correct",
            "Rewards uitgekeerd",
            "Revenge chain activate bij target survive",
        ],
        "time_estimate": "2-4 uur",
    })

# G5 - Reputation deep (179-184, 6 prompts)
G5_REP = [
    "Reputation multi-axis (meer dan linear)",
    "Reputation consequences (access/prices/dialogs)",
    "Reputation recovery mechanics",
    "Faction war triggers",
    "Reputation-based mission unlock",
    "Reputation UI deep view",
]
for i, name in enumerate(G5_REP):
    nr = 179 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "G_systems",
        "sub": "g5_reputation",
        "fname": f"prompt_{nr:03d}_rep_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Deep mechanics beyond MVP reputation",
            "Integratie met alle faction systems",
            "UI feedback",
            "Save/load",
            "Testing",
        ],
        "deps": list(range(43, nr)) + [39, 65, 66],
        "context": "MVP heeft basic rep (-100 to +100) voor Harkon + Marshal. Nu multi-dimensionaal.",
        "testing": [
            "Rep mechanics werken correct",
            "Access gates enforced",
            "Dialogs passen bij rep",
        ],
        "time_estimate": "3-4 uur",
    })

# G6 - Economy (185-190, 6 prompts)
G6_ECON = [
    "Economy simulation core (supply/demand)",
    "System economy profiles",
    "Trade route discovery",
    "Economic events (shortage, boom)",
    "Player market impact",
    "Economy analytics dashboard (dev tool)",
]
for i, name in enumerate(G6_ECON):
    nr = 185 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "G_systems",
        "sub": "g6_economy",
        "fname": f"prompt_{nr:03d}_econ_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Simulation model",
            "Tick update logic",
            "Integratie met cargo trading",
            "Events trigger per type",
            "UI (waar relevant)",
        ],
        "deps": list(range(43, nr)),
        "context": "Wing Commander Privateer had static prices. Wij gaan dynamisch met supply/demand per systeem.",
        "testing": [
            "Prices fluctueren logisch",
            "Events triggeren + resolvent",
            "Player trading beinvloedt markt",
            "Performance OK (sim runt async)",
        ],
        "time_estimate": "3-5 uur",
    })

# ============================================================
# FASE H - PROCEDURAL + SYNTHARI (191-240)
# ============================================================

# H1 - Biomes (191-206, 16 prompts)
H1_BIOMES = [
    "Biome generator core (seed-based)",
    "Biome theme definitions (10 themes)",
    "Tileset generation per biome",
    "Parallax layer generation",
    "Hazard placement (asteroids, nebula, gravitywells)",
    "Enemy spawn tables per biome",
    "Loot tables per biome",
    "Music/ambience tagging",
    "Biome diversity (sub-variations)",
    "Biome weather/environmental effects",
    "Biome POIs (points of interest)",
    "Mission framework voor procedurele biomes",
    "Biome cache (vermijd regen)",
    "Biome gallery (discovered biomes)",
    "Biome tuning tool (dev)",
    "Biome polish + integratie",
]
for i, name in enumerate(H1_BIOMES):
    nr = 191 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "H_procedural",
        "sub": "h1_biomes",
        "fname": f"prompt_{nr:03d}_biome_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor procedural biomes.",
        "taken": [
            "Algorithm + data structure",
            "NOVA pipeline integratie voor tile generation",
            "Godot scene instantiation",
            "Save/load (seed opslaan, niet content)",
            "Testing met meerdere seeds",
        ],
        "deps": list(range(43, nr)) + [20, 21, 22],
        "context": "Ref: docs/BIOME_GENERATOR.md. Inspired by No Man's Sky / Starbound procedural.",
        "testing": [
            "Generated biomes voelen uniek",
            "Difficulty scales met player level",
            "Performance < 2s generation time",
            "Seed reproducibility",
        ],
        "time_estimate": "3-5 uur",
    })

# H2 - Synthari race (207-220, 14 prompts)
H2_SYNTHARI = [
    "Synthari character creation",
    "Synthari backstory integration (Zygon Incident)",
    "Synthari unique abilities",
    "Synthari ships (separate tech tree)",
    "Synthari dialog (alien perspective)",
    "Synthari faction relations (different from Man)",
    "De Kern / Rand / Stilte philosophical choice",
    "Synthari story path (alternate campaign)",
    "Synthari-specific missions",
    "Synthari endings variants",
    "Drempel mechanic (threshold crossing)",
    "Synthari → Silurian connection reveal",
    "New Game+ as Synthari",
    "Synthari polish",
]
for i, name in enumerate(H2_SYNTHARI):
    nr = 207 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "H_procedural",
        "sub": "h2_synthari",
        "fname": f"prompt_{nr:03d}_synthari_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor Synthari race.",
        "taken": [
            "Canon consultation (Agent 07 Narrative Jury)",
            "Implementation GDScript",
            "Asset generation via NOVA",
            "Save/load Synthari save slots",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Ref: docs/SYNTHARI_LORE.md + Surilians canon connection. Synthari is playable alien race met eigen arc.",
        "testing": [
            "Synthari path playable",
            "Canon consistent met Surilians lore",
            "Unieke mechanics werken",
            "Feel duidelijk anders dan Man path",
        ],
        "time_estimate": "3-5 uur",
    })

# H3 - Boarding (221-228, 8 prompts)
H3_BOARDING = [
    "Boarding trigger + minigame entry",
    "Boarding scene (corridor shooter)",
    "Boarding enemies (defenders)",
    "Boarding objectives (capture/steal/sabotage)",
    "Boarding rewards",
    "Boarding failure consequences",
    "Boarding-specific abilities",
    "Boarding polish",
]
for i, name in enumerate(H3_BOARDING):
    nr = 221 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "H_procedural",
        "sub": "h3_boarding",
        "fname": f"prompt_{nr:03d}_boarding_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor boarding minigame.",
        "taken": [
            "Scene setup",
            "Mechanics (side-view shooter per corridor)",
            "NOVA asset generation",
            "Integratie met main game",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Ref: docs/MEGALODON_SPEC.md - originally spec'd boarding minigame.",
        "testing": [
            "Boarding triggers bij disabled enemy ship",
            "Minigame speelbaar",
            "Rewards correct",
            "Terug naar main game smooth",
        ],
        "time_estimate": "3-4 uur",
    })

# H4 - Ship capture (229-234, 6 prompts)
H4_CAPTURE = [
    "Ship capture flow post-boarding",
    "Captured ship integration (switch control)",
    "Ship modification workbench",
    "Component swapping UI",
    "Faction-restricted components",
    "Ship capture polish",
]
for i, name in enumerate(H4_CAPTURE):
    nr = 229 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "H_procedural",
        "sub": "h4_ship_capture",
        "fname": f"prompt_{nr:03d}_capture_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Mechanic design",
            "UI waar relevant",
            "Save/load captured ship",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Privateer had ship capture mechanic. Wij doen zelfde maar met NOVA-powered mods.",
        "testing": [
            "Capture sequence werkt",
            "Ship swap smooth",
            "Modifications persist",
        ],
        "time_estimate": "2-3 uur",
    })

# H5 - Secret (235-240, 6 prompts)
H5_SECRET = [
    "Secret wormhole locations",
    "Secret Easter eggs system",
    "Hidden lore fragments",
    "Secret boss encounters",
    "Secret ship (Drifter unlock)",
    "Secret content unlock flow",
]
for i, name in enumerate(H5_SECRET):
    nr = 235 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "H_procedural",
        "sub": "h5_secret",
        "fname": f"prompt_{nr:03d}_secret_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Trigger condities",
            "Content per secret",
            "Discovery feedback",
            "Save tracking",
        ],
        "deps": list(range(43, nr)),
        "context": "Secrets motiveren replayability. Inspired by Tyrian 2000's secret levels.",
        "testing": [
            "Secrets triggerbaar zonder guide (subtle hints)",
            "Unieke rewards",
            "Niet game-breaking voor first playthrough",
        ],
        "time_estimate": "2-3 uur",
    })

# ============================================================
# FASE I - PLANETSIDE (241-290)
# ============================================================

# I1 - Blackthorne core (241-256, 16 prompts)
I1_CORE = [
    "Planetside scene framework (side-view 2.5D)",
    "Rex Varn character controller (ground)",
    "Rex Varn animation set (walk, jump, shoot, duck, climb)",
    "Jump + gravity mechanic",
    "Shooting mechanic (ground weapons)",
    "Weapon loadout (pistol, rifle, grenades)",
    "Enemy soldier AI",
    "Cover mechanic (take cover behind objects)",
    "Health + armor system (ground)",
    "Ground interactables (doors, terminals, chests)",
    "Ground physics (slopes, ledges, ladders)",
    "Checkpoint save system planetside",
    "Planetside UI (ground HUD)",
    "Planetside cam behavior",
    "Death + respawn flow",
    "Core planetside polish",
]
for i, name in enumerate(I1_CORE):
    nr = 241 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "I_planetside",
        "sub": "i1_core",
        "fname": f"prompt_{nr:03d}_ground_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor planetside mode.",
        "taken": [
            "Scene + node setup",
            "GDScript mechanics",
            "Asset hooks via NOVA pipeline",
            "Integratie met main game flow",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Blackthorne-inspired side-view shooter. Rex Varn landt op planeten voor specifieke missies.",
        "testing": [
            "Controls responsive",
            "Animation sync",
            "AI challenging but fair",
            "Transition space ↔ ground smooth",
        ],
        "time_estimate": "3-5 uur",
    })

# I2 - PDOK alien (257-268, 12 prompts)
I2_PDOK = [
    "PDOK tile ingest pipeline (Hoogeveen data)",
    "Tile to 2D layout conversion",
    "Alien texture overlay system",
    "Alien biome styles (5 variants)",
    "Texture shader (via Agent 22 + shaders)",
    "Mesh simplification voor performance",
    "Level streaming from PDOK tiles",
    "Alien vegetation placement",
    "Alien architecture (buildings transformed)",
    "Alien atmospheric effects",
    "PDOK quality validation",
    "PDOK integration polish",
]
for i, name in enumerate(I2_PDOK):
    nr = 257 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "I_planetside",
        "sub": "i2_pdok_alien",
        "fname": f"prompt_{nr:03d}_pdok_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name} voor PDOK alien textures.",
        "taken": [
            "NOVA pipeline integration (Agent 13 PDOK + 14 Baker + 22 Blender)",
            "Shader setup",
            "Asset batch per location",
            "Godot runtime integration",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Unique selling point: real Hoogeveen + buildings geotransformed als alien werelden. PDOK → mesh → alien retexture.",
        "testing": [
            "Real locations recognizable in silhouette",
            "Alien overlay overtuigend",
            "Performance OK op midrange",
            "Streaming zonder loading screens",
        ],
        "time_estimate": "3-5 uur",
    })

# I3 - NPCs (269-276, 8 prompts)
I3_NPCS = [
    "NPC character framework (ground)",
    "NPC sprite pipeline (NOVA)",
    "NPC schedules + routines",
    "NPC dialog state machine",
    "NPC reputation reactions",
    "NPC quest givers",
    "NPC merchants (ground shops)",
    "NPC polish",
]
for i, name in enumerate(I3_NPCS):
    nr = 269 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "I_planetside",
        "sub": "i3_npcs",
        "fname": f"prompt_{nr:03d}_npc_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Character class + behaviors",
            "Assets via NOVA (Agent 27 Storyboard Visual + 08 Character Art)",
            "Dialog hooks",
            "Quest integration",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "NPCs op planetside geven game levend gevoel. Elk NPC kan quest giver, shop, of gewoon flavor zijn.",
        "testing": [
            "NPCs acteren volgens schedule",
            "Dialog flow correct",
            "Quest handover werkt",
        ],
        "time_estimate": "2-3 uur",
    })

# I4 - Dialog (277-284, 8 prompts)
I4_DIALOG = [
    "Dialog tree data structure",
    "Dialog UI (portrait + text + options)",
    "Dialog branching based on reputation",
    "Dialog branching based on cargo/intel",
    "Dialog-triggered quests",
    "Dialog localization prep (dutch/english)",
    "Dialog skip/auto/log system",
    "Dialog polish",
]
for i, name in enumerate(I4_DIALOG):
    nr = 277 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "I_planetside",
        "sub": "i4_dialog",
        "fname": f"prompt_{nr:03d}_dialog_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Data structure",
            "UI component",
            "Integration met rep/inventory",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Dialog crucial voor narrative delivery. Moet voelen als echte keuzes.",
        "testing": [
            "Branches correct",
            "UI responsive",
            "Localization-ready",
        ],
        "time_estimate": "2-3 uur",
    })

# I5 - Ground missions (285-290, 6 prompts)
I5_GROUND_MISSIONS = [
    "Ground mission types (assassination, retrieval, escort, defend, sabotage, rescue)",
    "Ground mission generator",
    "Ground boss encounters (3 bosses)",
    "Ground stealth missions",
    "Ground puzzle missions",
    "Ground missions polish",
]
for i, name in enumerate(I5_GROUND_MISSIONS):
    nr = 285 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "I_planetside",
        "sub": "i5_missions",
        "fname": f"prompt_{nr:03d}_ground_mission_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Mission data + triggers",
            "Content per missie (5+ per type)",
            "Balance + rewards",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Planetside missions geven variatie tov space-only gameplay.",
        "testing": [
            "Alle mission types werken",
            "Balanced rewards",
            "Narrative fits canon",
        ],
        "time_estimate": "3-4 uur",
    })

# ============================================================
# FASE J - POLISH (291-340)
# ============================================================

# J1 - Voice (291-300, 10 prompts)
J1_VOICE = [
    "ElevenLabs voice profile assignment (alle chars)",
    "Rex Varn voice lines batch (100+)",
    "Helios faction voice batch",
    "Marshal faction voice batch",
    "Harkon faction voice batch",
    "Ghost Market + Phantom voice batch",
    "Fringe voice batch",
    "The Drifter voice (unique)",
    "Voice asset Jury validation pass",
    "Voice integration in game",
]
for i, name in enumerate(J1_VOICE):
    nr = 291 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "J_polish",
        "sub": "j1_voice",
        "fname": f"prompt_{nr:03d}_voice_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Script consolidation (alle lines per character)",
            "ElevenLabs batch generation (Agent 29)",
            "Audio Jury pass (Agent 03, 30)",
            "In-game integration",
            "Lip sync (if applicable)",
            "Cost tracking check (Agent 16)",
        ],
        "deps": list(range(43, nr)),
        "context": "Voice = huge credibility boost. ElevenLabs credits budget watchen via Cost Guard.",
        "testing": [
            "Voice lines matching character",
            "Audio quality accept (Jury)",
            "Playback smooth ingame",
            "Cost binnen budget",
        ],
        "time_estimate": "3-6 uur (ElevenLabs gen tijd)",
    })

# J2 - Music (301-310, 10 prompts)
J2_MUSIC = [
    "Music style guide (Black Ledger aesthetic)",
    "Audiocraft batch voor station music (8 tracks)",
    "Audiocraft batch voor combat music (10 tracks)",
    "Audiocraft batch voor exploration music (6 tracks)",
    "Boss music (4 unique tracks)",
    "Ambient planetside music (8 tracks)",
    "Dynamic music system (cross-fade)",
    "Music reactive to combat intensity",
    "Music asset Jury pass",
    "Music integration final",
]
for i, name in enumerate(J2_MUSIC):
    nr = 301 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "J_polish",
        "sub": "j2_music",
        "fname": f"prompt_{nr:03d}_music_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Audiocraft generation (Agent 29 of lokaal)",
            "Music manager in Godot",
            "Crossfade systeem",
            "Contextual triggers",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Music = soul of game. Tyrian 2000 had memorable Alexander Brandon score. Wij gaan AI maar met directing.",
        "testing": [
            "Music fits scene",
            "Transitions smooth",
            "No jarring cuts",
        ],
        "time_estimate": "2-5 uur",
    })

# J3 - News ticker (311-318, 8 prompts)
J3_NEWS = [
    "News broadcast data structure",
    "News event triggers (player actions)",
    "News event templates per faction",
    "News ticker UI (station display)",
    "Broadcaster portraits + voices",
    "Dynamic news generation (Agent 28)",
    "News affecting prices/reputation",
    "News polish",
]
for i, name in enumerate(J3_NEWS):
    nr = 311 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "J_polish",
        "sub": "j3_news",
        "fname": f"prompt_{nr:03d}_news_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Data model",
            "Trigger logic",
            "UI elements",
            "Narrative Jury consultation (Agent 07)",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Referentie MVP had NewsBroadcastSystem uit SpaceShooter. Nu uitbreiden tot live ticker.",
        "testing": [
            "News items genereren op events",
            "Fits canon",
            "Impact op economy visible",
        ],
        "time_estimate": "2-3 uur",
    })

# J4 - 3 Endings (319-328, 10 prompts)
J4_ENDINGS = [
    "Ending logic + trigger conditions",
    "Ending: Clean Slate (full playable)",
    "Ending: New Ledger (full playable)",
    "Ending: Ghosted (full playable)",
    "Ending cinematics per ending (storyboard + visuals)",
    "Ending credits roll",
    "New Game+ unlock system",
    "Ending stats + achievements",
    "Ending canon validation (Narrative Jury deep pass)",
    "Endings polish + final QA",
]
for i, name in enumerate(J4_ENDINGS):
    nr = 319 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "J_polish",
        "sub": "j4_endings",
        "fname": f"prompt_{nr:03d}_ending_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Branch logic",
            "Cinematic scenes (storyboards via Agent 27)",
            "Music + voice acted",
            "Canon consistency Jury",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Ref: docs/CANON_COMPLETE.md - 3 endings zijn heart van Black Ledger narrative.",
        "testing": [
            "Alle 3 bereikbaar via save",
            "Cinematic rendering smooth",
            "Consequent met player choices",
        ],
        "time_estimate": "4-6 uur",
    })

# J5 - The Drifter (329-334, 6 prompts)
J5_DRIFTER = [
    "Drifter encounter trigger system",
    "Drifter dialog deep branches",
    "Drifter ship unique mechanics",
    "Drifter lore reveal arc",
    "Drifter post-ending implications",
    "Drifter polish",
]
for i, name in enumerate(J5_DRIFTER):
    nr = 329 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "J_polish",
        "sub": "j5_drifter",
        "fname": f"prompt_{nr:03d}_drifter_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Encounter design",
            "Dialog tree",
            "Unique assets",
            "Narrative Jury",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "The Drifter = mystical figure. Niet te vroeg onthullen. Selectieve encounters.",
        "testing": [
            "Encounters niet te vaak (rare events)",
            "Dialog has weight",
            "Lore consistent",
        ],
        "time_estimate": "3-4 uur",
    })

# J6 - Canon integration pass (335-340, 6 prompts)
J6_CANON = [
    "Full canon consistency pass (all texts)",
    "Faction voice + tone consistency",
    "Timeline consistency check",
    "Character arc consistency",
    "Lore bible update with game content",
    "Canon final validation (Narrative Jury deep pass)",
]
for i, name in enumerate(J6_CANON):
    nr = 335 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "J_polish",
        "sub": "j6_canon",
        "fname": f"prompt_{nr:03d}_canon_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Uitvoeren {name}.",
        "taken": [
            "Scan alle in-game text",
            "Jury pass per context",
            "Fix inconsistencies",
            "Update canon docs",
            "Final sign-off",
        ],
        "deps": list(range(43, nr)),
        "context": "Laatste canon QA voor release. Kritiek voor Surilians shared universe consistency.",
        "testing": [
            "Alle text Jury-approved",
            "Geen timeline paradoxes",
            "Geen karakterbreaks",
        ],
        "time_estimate": "4-8 uur",
    })

# ============================================================
# FASE K - RELEASE (341-370)
# ============================================================

# K1 - Android (341-350, 10 prompts)
K1_ANDROID = [
    "Android build target setup",
    "Mobile controls (touch interface)",
    "Mobile UI scaling",
    "Mobile performance optimization",
    "Mobile asset compression",
    "Android signing + keystore",
    "Android permissions + manifest",
    "APK test on real devices (auto + NOVA)",
    "Mobile store listing prep (Google Play)",
    "Android polish + final APK",
]
for i, name in enumerate(K1_ANDROID):
    nr = 341 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "K_release",
        "sub": "k1_android",
        "fname": f"prompt_{nr:03d}_android_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Godot Android export setup",
            "Code adjustments voor mobile",
            "Asset variants waar nodig",
            "Testing op device",
        ],
        "deps": list(range(43, nr)),
        "context": "Android als secondary platform. Mobile-first designed zou te restrictief zijn, maar port is valuable.",
        "testing": [
            "APK installs clean",
            "Gameplay werkbaar op 6-inch screen",
            "60fps op midrange Android",
            "No critical crashes",
        ],
        "time_estimate": "3-5 uur",
    })

# K2 - Steam prep (351-358, 8 prompts)
K2_STEAM = [
    "Steam store page draft content",
    "Steam API integration (achievements, cloud saves)",
    "Steam Workshop prep (for later mods)",
    "Steam trading cards design",
    "Steam community features",
    "Steam beta/demo branch setup",
    "Steam release checklist",
    "Steam launch materials",
]
for i, name in enumerate(K2_STEAM):
    nr = 351 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "K_release",
        "sub": "k2_steam",
        "fname": f"prompt_{nr:03d}_steam_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Steam SDK integration waar relevant",
            "Content generation via NOVA",
            "Testing",
        ],
        "deps": list(range(43, nr)),
        "context": "Steam is primary PC distribution. Prep maar geen publish (dat gebeurt buiten dev stream).",
        "testing": [
            "Steam features werken",
            "Content professional",
            "Ready voor submit review",
        ],
        "time_estimate": "2-4 uur",
    })

# K3 - Balance final (359-364, 6 prompts)
K3_BALANCE = [
    "Full balance pass Level 1-10",
    "Full balance pass Level 11-20",
    "Full balance pass Level 21-28",
    "Economy balance (prices, rewards)",
    "Difficulty curve validation",
    "Balance signed off by Agent 10 deep",
]
for i, name in enumerate(K3_BALANCE):
    nr = 359 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "K_release",
        "sub": "k3_balance",
        "fname": f"prompt_{nr:03d}_balance_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Uitvoeren {name}.",
        "taken": [
            "Simulated playthroughs",
            "Data collection + analysis",
            "Tweaks waar nodig",
            "Agent 10 Jury pass",
            "Document wijzigingen",
        ],
        "deps": list(range(43, nr)),
        "context": "Laatste balance pass voor release. Moet voelen niet frustrerend, niet te makkelijk.",
        "testing": [
            "Player metrics binnen target range",
            "Geen soft-lock situations",
            "Fun curve monoton",
        ],
        "time_estimate": "4-8 uur",
    })

# K4 - QA automation (365-368, 4 prompts)
K4_QA = [
    "Automated smoke tests",
    "Regression test suite",
    "Performance benchmark suite",
    "Nightly build QA pipeline",
]
for i, name in enumerate(K4_QA):
    nr = 365 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "K_release",
        "sub": "k4_qa",
        "fname": f"prompt_{nr:03d}_qa_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Implementeer {name}.",
        "taken": [
            "Test framework setup",
            "Test cases per critical path",
            "CI integration",
            "Reporting",
        ],
        "deps": list(range(43, nr)),
        "context": "Solo dev kan niet alles handmatig testen. Automation essentieel.",
        "testing": [
            "Tests runnen groen",
            "Caught real issues",
            "Speed acceptable",
        ],
        "time_estimate": "3-5 uur",
    })

# K5 - Launch content (369-370, 2 prompts)
K5_LAUNCH = [
    "Launch trailer + screenshots (via NOVA Storyboard + Renderer)",
    "Launch day checklist + post-launch plan",
]
for i, name in enumerate(K5_LAUNCH):
    nr = 369 + i
    PROMPTS.append({
        "nr": nr,
        "fase": "K_release",
        "sub": "k5_launch",
        "fname": f"prompt_{nr:03d}_launch_{name.lower().replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')[:40]}.md",
        "titel": name,
        "doel": f"Prepareer {name}.",
        "taken": [
            "Asset generation via NOVA",
            "Content writing",
            "Timeline + logistics",
            "Post-launch plan",
        ],
        "deps": list(range(43, nr)),
        "context": "Laatste stap voor release. Moet polished zijn, eerste indruk telt.",
        "testing": [
            "Materials professional",
            "Plan uitvoerbaar",
            "Contingencies voor launch day",
        ],
        "time_estimate": "4-6 uur",
    })


print(f"Totaal prompts gedefinieerd: {len(PROMPTS)}")
print(f"Range: {PROMPTS[0]['nr']} - {PROMPTS[-1]['nr']}")

# Schrijf JSON manifest voor referentie
manifest = {
    "total_prompts": len(PROMPTS),
    "range": f"{PROMPTS[0]['nr']}-{PROMPTS[-1]['nr']}",
    "by_fase": {},
    "prompts": [{k: v for k, v in p.items() if k != 'deps'} for p in PROMPTS]
}
for p in PROMPTS:
    fase = p['fase']
    manifest['by_fase'][fase] = manifest['by_fase'].get(fase, 0) + 1

manifest_path = BASE / "00_master" / "PROMPT_MANIFEST.json"
manifest_path.write_text(json.dumps(manifest, indent=2))
print(f"Manifest: {manifest_path}")
print(f"Per fase: {manifest['by_fase']}")
