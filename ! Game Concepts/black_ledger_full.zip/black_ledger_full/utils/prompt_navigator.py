#!/usr/bin/env python3
"""Black Ledger Full Build - Prompt Navigator.

Handig tool om prompts te vinden, status te tracken, en progressie te meten.

Usage:
    python prompt_navigator.py --next            # Toon volgende prompt om aan te pakken
    python prompt_navigator.py --current         # Toon huidige fase status
    python prompt_navigator.py --fase F_content  # Toon alle prompts in fase
    python prompt_navigator.py --mark-done 43    # Markeer prompt 43 als voltooid
    python prompt_navigator.py --progress        # Toon overall progress
"""
import argparse
import json
import sys
from pathlib import Path

BASE = Path(__file__).parent.parent  # relative to utils/ dir
MANIFEST = BASE / "00_master" / "PROMPT_MANIFEST.json"
PROGRESS_FILE = BASE / "00_master" / "PROGRESS.json"


def load_manifest():
    if not MANIFEST.exists():
        print(f"Manifest ontbreekt: {MANIFEST}")
        sys.exit(1)
    return json.loads(MANIFEST.read_text())


def load_progress():
    if not PROGRESS_FILE.exists():
        return {"completed": [], "in_progress": None, "notes": {}}
    return json.loads(PROGRESS_FILE.read_text())


def save_progress(progress):
    PROGRESS_FILE.write_text(json.dumps(progress, indent=2))


def cmd_next(args):
    manifest = load_manifest()
    progress = load_progress()
    completed = set(progress['completed'])
    
    for p in manifest['prompts']:
        if p['nr'] not in completed:
            print(f"\nVolgende prompt: #{p['nr']:03d} - {p['titel']}")
            print(f"Fase: {p['fase']} / {p['sub']}")
            print(f"Time estimate: {p['time_estimate']}")
            print(f"Doel: {p['doel']}")
            print(f"\nBestand: {p['fname']}")
            prompt_path = BASE / p['fase'] / p['sub'] / p['fname']
            if prompt_path.exists():
                print(f"Open: {prompt_path}")
            else:
                print(f"(Prompt file niet gevonden, regenerate?)")
            return
    
    print("Alle 328 prompts voltooid! Ga naar K5 prompt 370 voor release.")


def cmd_current(args):
    manifest = load_manifest()
    progress = load_progress()
    completed = set(progress['completed'])
    
    # Bepaal huidige fase (laatste incompleet)
    current_fase = None
    for p in manifest['prompts']:
        if p['nr'] not in completed:
            current_fase = p['fase']
            break
    
    if not current_fase:
        print("Alle fases voltooid!")
        return
    
    # Stats voor huidige fase
    fase_prompts = [p for p in manifest['prompts'] if p['fase'] == current_fase]
    fase_done = sum(1 for p in fase_prompts if p['nr'] in completed)
    fase_total = len(fase_prompts)
    
    print(f"\nHuidige fase: {current_fase}")
    print(f"Progress: {fase_done}/{fase_total} ({100*fase_done//fase_total}%)")
    print(f"\nNog te doen in deze fase:")
    for p in fase_prompts:
        if p['nr'] not in completed:
            status = "▶" if p['nr'] == progress.get('in_progress') else " "
            print(f"  {status} #{p['nr']:03d} {p['titel']}")


def cmd_fase(args):
    manifest = load_manifest()
    progress = load_progress()
    completed = set(progress['completed'])
    
    fase_prompts = [p for p in manifest['prompts'] if p['fase'] == args.fase]
    if not fase_prompts:
        print(f"Fase '{args.fase}' niet gevonden.")
        valid = sorted(set(p['fase'] for p in manifest['prompts']))
        print(f"Valid fases: {valid}")
        return
    
    print(f"\nFase {args.fase}: {len(fase_prompts)} prompts\n")
    current_sub = None
    for p in fase_prompts:
        if p['sub'] != current_sub:
            current_sub = p['sub']
            print(f"\n--- {current_sub} ---")
        status = "✓" if p['nr'] in completed else ("▶" if p['nr'] == progress.get('in_progress') else " ")
        print(f"  {status} #{p['nr']:03d} {p['titel']}")


def cmd_mark_done(args):
    manifest = load_manifest()
    progress = load_progress()
    
    nr = args.mark_done
    # Verify prompt exists
    p = next((p for p in manifest['prompts'] if p['nr'] == nr), None)
    if not p:
        print(f"Prompt #{nr} niet gevonden in manifest.")
        return
    
    if nr in progress['completed']:
        print(f"Prompt #{nr} was al gemarkeerd als voltooid.")
        return
    
    progress['completed'].append(nr)
    progress['completed'].sort()
    if progress.get('in_progress') == nr:
        progress['in_progress'] = None
    save_progress(progress)
    
    print(f"Prompt #{nr} ({p['titel']}) gemarkeerd als voltooid.")
    print(f"Totaal voltooid: {len(progress['completed'])}/328")


def cmd_progress(args):
    manifest = load_manifest()
    progress = load_progress()
    completed = set(progress['completed'])
    
    total = len(manifest['prompts'])
    done = len(completed)
    pct = 100 * done // total
    
    print(f"\n=== Black Ledger Full Build Progress ===\n")
    print(f"Overall: {done}/{total} ({pct}%)")
    print(f"In progress: {progress.get('in_progress', 'none')}")
    
    print(f"\nPer fase:")
    for fase in ['F_content', 'G_systems', 'H_procedural', 'I_planetside', 'J_polish', 'K_release']:
        fase_prompts = [p for p in manifest['prompts'] if p['fase'] == fase]
        fase_done = sum(1 for p in fase_prompts if p['nr'] in completed)
        fase_total = len(fase_prompts)
        fase_pct = 100 * fase_done // fase_total if fase_total else 0
        bar = "█" * (fase_pct // 5) + "░" * (20 - fase_pct // 5)
        print(f"  {fase:20} {bar} {fase_done}/{fase_total} ({fase_pct}%)")
    
    # Estimated remaining time
    total_hours = sum(
        int(p['time_estimate'].split('-')[0]) 
        for p in manifest['prompts'] 
        if p['nr'] not in completed
    )
    print(f"\nEstimated remaining: {total_hours}-{total_hours*2} hours")
    print(f"At 2 prompts/day: {(total - done) // 2} days = {(total - done) // 14} weeks")


def cmd_start(args):
    manifest = load_manifest()
    progress = load_progress()
    
    nr = args.start
    p = next((p for p in manifest['prompts'] if p['nr'] == nr), None)
    if not p:
        print(f"Prompt #{nr} niet gevonden.")
        return
    
    progress['in_progress'] = nr
    save_progress(progress)
    
    prompt_path = BASE / p['fase'] / p['sub'] / p['fname']
    print(f"Started: #{nr} {p['titel']}")
    print(f"Bestand: {prompt_path}")


def main():
    parser = argparse.ArgumentParser(description="Black Ledger Full Build Prompt Navigator")
    parser.add_argument("--next", action="store_true", help="Toon volgende prompt")
    parser.add_argument("--current", action="store_true", help="Toon huidige fase status")
    parser.add_argument("--fase", help="Toon alle prompts in fase")
    parser.add_argument("--mark-done", type=int, help="Markeer prompt X als voltooid")
    parser.add_argument("--start", type=int, help="Start werken aan prompt X")
    parser.add_argument("--progress", action="store_true", help="Toon overall progress")
    args = parser.parse_args()
    
    if args.next:
        cmd_next(args)
    elif args.current:
        cmd_current(args)
    elif args.fase:
        cmd_fase(args)
    elif args.mark_done:
        cmd_mark_done(args)
    elif args.start:
        cmd_start(args)
    elif args.progress:
        cmd_progress(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
