# Black Ledger Project Health Check
# Run voor starten van elke dev sessie

param(
    [string]$GameProjectPath = "L:\1 Nova Cursor Output\Dark Ledger"
)

Write-Host ""
Write-Host "=== Black Ledger Health Check ===" -ForegroundColor Cyan
Write-Host ""

# Check 1: Game project exists
Write-Host "1. Game project:" -ForegroundColor Cyan
if (Test-Path $GameProjectPath) {
    Write-Host "   OK: $GameProjectPath" -ForegroundColor Green
    
    # Check 1a: project.godot
    $godotFile = Join-Path $GameProjectPath "project.godot"
    Write-Host "   project.godot: $(if (Test-Path $godotFile) { 'OK' } else { 'MISSING' })" -ForegroundColor $(if (Test-Path $godotFile) { "Green" } else { "Red" })
    
    # Check 1b: Git repo
    $gitDir = Join-Path $GameProjectPath ".git"
    Write-Host "   Git repo: $(if (Test-Path $gitDir) { 'OK' } else { 'MISSING' })" -ForegroundColor $(if (Test-Path $gitDir) { "Green" } else { "Red" })
    
    if (Test-Path $gitDir) {
        Push-Location $GameProjectPath
        try {
            $status = git status --porcelain 2>&1
            $changes = ($status | Measure-Object).Count
            Write-Host "   Uncommitted changes: $changes files" -ForegroundColor $(if ($changes -eq 0) { "Green" } else { "Yellow" })
            
            $lastCommit = git log -1 --pretty=format:"%h %s" 2>&1
            Write-Host "   Last commit: $lastCommit" -ForegroundColor Gray
        } finally {
            Pop-Location
        }
    }
} else {
    Write-Host "   MISSING: $GameProjectPath" -ForegroundColor Red
    Write-Host "   MVP moet eerst gebouwd zijn. Zie black_ledger_mvp package." -ForegroundColor Yellow
}

# Check 2: NOVA v2 services
Write-Host ""
Write-Host "2. NOVA v2 services:" -ForegroundColor Cyan
try {
    $r = Invoke-WebRequest -Uri "http://178.104.207.194:5679" -TimeoutSec 5 -UseBasicParsing -ErrorAction SilentlyContinue
    Write-Host "   N8n main (5679): $(if ($r.StatusCode -lt 500) { 'OK' } else { 'DOWN' })" -ForegroundColor $(if ($r.StatusCode -lt 500) { "Green" } else { "Red" })
} catch {
    Write-Host "   N8n main (5679): UNREACHABLE" -ForegroundColor Red
}
try {
    $r = Invoke-WebRequest -Uri "http://178.104.207.194:5680" -TimeoutSec 5 -UseBasicParsing -ErrorAction SilentlyContinue
    Write-Host "   N8n webhook (5680): $(if ($r.StatusCode -lt 500) { 'OK' } else { 'DOWN' })" -ForegroundColor $(if ($r.StatusCode -lt 500) { "Green" } else { "Red" })
} catch {
    Write-Host "   N8n webhook (5680): UNREACHABLE" -ForegroundColor Red
}

# Check 3: Agent statussen
Write-Host ""
Write-Host "3. NOVA agents:" -ForegroundColor Cyan
$statusDir = "L:\!Nova V2\status"
if (Test-Path $statusDir) {
    $agents = Get-ChildItem $statusDir -Filter "agent_*_status.json"
    $active = 0
    $fallback = 0
    $failed = 0
    foreach ($f in $agents) {
        try {
            $s = Get-Content $f.FullName -Raw | ConvertFrom-Json
            if ($s.status -eq "active") {
                if ($s.fallback_mode) { $fallback++ } else { $active++ }
            } elseif ($s.status -eq "failed") {
                $failed++
            }
        } catch {}
    }
    Write-Host "   Active (full): $active" -ForegroundColor Green
    Write-Host "   Active (fallback): $fallback" -ForegroundColor Yellow
    Write-Host "   Failed: $failed" -ForegroundColor $(if ($failed -eq 0) { "Green" } else { "Red" })
    
    if (($active + $fallback) -lt 20) {
        Write-Host "   WARNING: < 20 agents actief. Full Build productie kan stroef lopen." -ForegroundColor Yellow
    }
} else {
    Write-Host "   NOVA v2 status dir niet gevonden" -ForegroundColor Red
}

# Check 4: Ollama
Write-Host ""
Write-Host "4. Ollama (lokaal):" -ForegroundColor Cyan
try {
    $r = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -TimeoutSec 3 -UseBasicParsing
    $tags = ($r.Content | ConvertFrom-Json).models
    Write-Host "   OK: $($tags.Count) modellen geladen" -ForegroundColor Green
    foreach ($m in $tags) {
        Write-Host "     - $($m.name)" -ForegroundColor Gray
    }
} catch {
    Write-Host "   UNREACHABLE: Ollama niet actief" -ForegroundColor Yellow
}

# Check 5: Disk space
Write-Host ""
Write-Host "5. Disk space:" -ForegroundColor Cyan
$lDrive = Get-PSDrive L -ErrorAction SilentlyContinue
if ($lDrive) {
    $freeGb = [math]::Round($lDrive.Free / 1GB, 2)
    $totalGb = [math]::Round(($lDrive.Free + $lDrive.Used) / 1GB, 2)
    $pctFree = [math]::Round(($lDrive.Free / ($lDrive.Free + $lDrive.Used)) * 100, 0)
    Write-Host "   L: drive: $freeGb GB free / $totalGb GB ($pctFree%)" -ForegroundColor $(if ($pctFree -gt 20) { "Green" } elseif ($pctFree -gt 10) { "Yellow" } else { "Red" })
    if ($pctFree -lt 20) {
        Write-Host "   WARNING: < 20% free. Asset pipeline kan stuck raken." -ForegroundColor Yellow
    }
}

# Summary
Write-Host ""
Write-Host "=== Klaar om te werken? ===" -ForegroundColor Cyan
$readyCheck = (Test-Path $GameProjectPath) -and (Test-Path $godotFile)
if ($readyCheck) {
    Write-Host "JA - Open volgende prompt en ga door" -ForegroundColor Green
} else {
    Write-Host "NEE - Fix hierboven gerapporteerde issues eerst" -ForegroundColor Yellow
}
Write-Host ""
