# Validate Fase - Black Ledger Full Build
# Controleert of alle prompts in een fase compleet zijn en tests groen

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("F_content", "G_systems", "H_procedural", "I_planetside", "J_polish", "K_release")]
    [string]$Fase,
    
    [string]$GameProjectPath = "L:\1 Nova Cursor Output\Dark Ledger",
    [switch]$Detailed
)

Write-Host ""
Write-Host "=== Validate Fase $Fase ===" -ForegroundColor Cyan
Write-Host ""

$fullBuildDir = "L:\!Nova V2\black_ledger_full"
$faseDir = Join-Path $fullBuildDir $Fase

if (-not (Test-Path $faseDir)) {
    Write-Host "Fase directory niet gevonden: $faseDir" -ForegroundColor Red
    exit 1
}

# Ranges per fase
$promptRanges = @{
    "F_content" = @(43, 120)
    "G_systems" = @(121, 190)
    "H_procedural" = @(191, 240)
    "I_planetside" = @(241, 290)
    "J_polish" = @(291, 340)
    "K_release" = @(341, 370)
}

$range = $promptRanges[$Fase]
$expectedCount = $range[1] - $range[0] + 1
Write-Host "Expected: prompts $($range[0])-$($range[1]) = $expectedCount prompts" -ForegroundColor Gray

# Check 1: Alle prompt files aanwezig
Write-Host ""
Write-Host "Check 1: Prompt files aanwezig..." -ForegroundColor Cyan
$promptFiles = Get-ChildItem -Path $faseDir -Recurse -Filter "prompt_*.md"
$actualCount = $promptFiles.Count
if ($actualCount -eq $expectedCount) {
    Write-Host "  OK: $actualCount prompts" -ForegroundColor Green
} else {
    Write-Host "  MISMATCH: expected $expectedCount, found $actualCount" -ForegroundColor Yellow
}

# Check 2: Git log toont commits per prompt
Write-Host ""
Write-Host "Check 2: Git commits..." -ForegroundColor Cyan
if (Test-Path $GameProjectPath) {
    Push-Location $GameProjectPath
    try {
        $commits = git log --oneline --all 2>&1
        $promptCommits = @()
        foreach ($line in $commits) {
            $promptFiles | ForEach-Object {
                $title = ($_.BaseName -replace '^prompt_\d{3}_', '').Replace('_', ' ')
                if ($line -match [regex]::Escape($title.Substring(0, [Math]::Min(20, $title.Length)))) {
                    $promptCommits += $_.BaseName
                }
            }
        }
        $uniqueCommits = $promptCommits | Select-Object -Unique
        Write-Host "  $($uniqueCommits.Count) / $expectedCount prompts lijken gecommit" -ForegroundColor $(if ($uniqueCommits.Count -eq $expectedCount) { "Green" } else { "Yellow" })
    } finally {
        Pop-Location
    }
} else {
    Write-Host "  SKIP: game project pad niet gevonden" -ForegroundColor Gray
}

# Check 3: Godot project valid
Write-Host ""
Write-Host "Check 3: Godot project valid..." -ForegroundColor Cyan
$godotProject = Join-Path $GameProjectPath "project.godot"
if (Test-Path $godotProject) {
    Write-Host "  OK: project.godot bestaat" -ForegroundColor Green
    # Check voor ship database etc based on fase
    switch ($Fase) {
        "F_content" {
            $shipDb = Join-Path $GameProjectPath "resources\ship_database.tres"
            $test = Test-Path $shipDb
            Write-Host "  $(if ($test) { 'OK' } else { 'MISSING' }): ship_database.tres" -ForegroundColor $(if ($test) { "Green" } else { "Yellow" })
        }
        "G_systems" {
            $starmap = Join-Path $GameProjectPath "scripts\starmap"
            $test = Test-Path $starmap
            Write-Host "  $(if ($test) { 'OK' } else { 'MISSING' }): scripts/starmap/" -ForegroundColor $(if ($test) { "Green" } else { "Yellow" })
        }
        "H_procedural" {
            $biomes = Join-Path $GameProjectPath "scripts\biomes"
            $test = Test-Path $biomes
            Write-Host "  $(if ($test) { 'OK' } else { 'MISSING' }): scripts/biomes/" -ForegroundColor $(if ($test) { "Green" } else { "Yellow" })
        }
        "I_planetside" {
            $ground = Join-Path $GameProjectPath "scenes\planetside"
            $test = Test-Path $ground
            Write-Host "  $(if ($test) { 'OK' } else { 'MISSING' }): scenes/planetside/" -ForegroundColor $(if ($test) { "Green" } else { "Yellow" })
        }
        "J_polish" {
            $voice = Join-Path $GameProjectPath "assets\audio\voice"
            $test = Test-Path $voice
            Write-Host "  $(if ($test) { 'OK' } else { 'MISSING' }): assets/audio/voice/" -ForegroundColor $(if ($test) { "Green" } else { "Yellow" })
        }
        "K_release" {
            $exports = Join-Path $GameProjectPath "export_presets.cfg"
            $test = Test-Path $exports
            Write-Host "  $(if ($test) { 'OK' } else { 'MISSING' }): export_presets.cfg" -ForegroundColor $(if ($test) { "Green" } else { "Yellow" })
        }
    }
} else {
    Write-Host "  SKIP: project.godot niet gevonden" -ForegroundColor Gray
}

# Check 4: NOVA agents required voor deze fase draaien
Write-Host ""
Write-Host "Check 4: NOVA agents required voor $Fase..." -ForegroundColor Cyan
$requiredAgents = switch ($Fase) {
    "F_content" { @("01", "02", "10", "20", "21", "22", "23") }
    "G_systems" { @("02", "07", "18", "28") }
    "H_procedural" { @("02", "07", "20", "22") }
    "I_planetside" { @("13", "14", "15", "20", "22") }
    "J_polish" { @("03", "07", "27", "29", "30") }
    "K_release" { @("10", "19") }
}

$statusDir = "L:\!Nova V2\status"
if (Test-Path $statusDir) {
    $availableAgents = @()
    Get-ChildItem $statusDir -Filter "agent_*_status.json" | ForEach-Object {
        try {
            $s = Get-Content $_.FullName -Raw | ConvertFrom-Json
            if ($s.status -eq "active") {
                $availableAgents += $s.agent_number
            }
        } catch {}
    }
    foreach ($req in $requiredAgents) {
        $found = $availableAgents -contains $req
        Write-Host "  Agent $req : $(if ($found) { 'ACTIVE' } else { 'MISSING' })" -ForegroundColor $(if ($found) { "Green" } else { "Red" })
    }
}

# Summary
Write-Host ""
Write-Host "=== Summary ===" -ForegroundColor Cyan
Write-Host "Fase: $Fase"
Write-Host "Prompts directory: $actualCount / $expectedCount files"
Write-Host "Volgende stap:"
if ($actualCount -eq $expectedCount) {
    Write-Host "  Deze fase is structureel compleet. Run individuele prompts in volgorde." -ForegroundColor Green
} else {
    Write-Host "  Re-run generator om prompt files aan te vullen." -ForegroundColor Yellow
}
Write-Host ""
