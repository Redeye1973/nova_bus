#!/usr/bin/env python3
"""Schrijf alle prompt MD files uit het manifest."""
from pathlib import Path
import json

BASE = Path("/home/claude/black_ledger_full")

# Load alle prompt definities via execfile pattern
import importlib.util
spec = importlib.util.spec_from_file_location("gen", BASE / "utils" / "generate_prompts.py")
gen_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen_module)
PROMPTS = gen_module.PROMPTS

# Template voor elke prompt file
def render_prompt(p: dict) -> str:
    deps_str = ", ".join(str(d) for d in p['deps'][-10:])  # Laatste 10 deps
    taken_list = "\n".join(f"{i+1}. {t}" for i, t in enumerate(p['taken']))
    testing_list = "\n".join(f"- {t}" for t in p['testing'])
    
    return f"""# Prompt {p['nr']:03d}: {p['titel']}

**Fase**: {p['fase']}  
**Sub**: {p['sub']}  
**Time estimate**: {p['time_estimate']}

## Doel

{p['doel']}

## Context

{p['context']}

**Recente dependencies**: prompts {deps_str}

## Project locatie

`L:\\1 Nova Cursor Output\\Dark Ledger\\`

## Taken

{taken_list}

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\\!Nova V2\\status\\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

{testing_list}

## Git

Na succes:
```
cd "L:\\1 Nova Cursor Output\\Dark Ledger"
git add .
git commit -m "{p['sub']}: {p['titel'].lower()}"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\\utils\\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

{'Prompt ' + str(p['nr'] + 1) if p['nr'] < 370 else 'LAST PROMPT - run final QA!'}
"""

# Schrijf alle files
count = 0
for p in PROMPTS:
    # Normalize fname - remove special chars that could break fs
    fname_safe = p['fname'].replace("'", '').replace('(', '').replace(')', '').replace('/', '_')
    target_dir = BASE / p['fase'] / p['sub']
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / fname_safe
    target.write_text(render_prompt(p))
    count += 1

print(f"Wrote {count} prompt files")
print(f"Verification:")
for fase in ['F_content', 'G_systems', 'H_procedural', 'I_planetside', 'J_polish', 'K_release']:
    fase_dir = BASE / fase
    files = list(fase_dir.rglob("prompt_*.md"))
    print(f"  {fase}: {len(files)} files")
