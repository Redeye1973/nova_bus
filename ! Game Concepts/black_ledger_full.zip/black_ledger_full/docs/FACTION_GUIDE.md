# Faction Guide - Black Ledger

Gedetailleerde guide voor F2 prompts (59-72). Zie ook `docs/CANON_COMPLETE.md` voor story context.

## 6 Factions overzicht

| Faction | Rol | Kleurschema | Aesthetic | Primary Ships |
|---------|-----|-------------|-----------|---------------|
| Harkon | Primary antagonist | Dark red, black | Industrial, spiked | Reaver, Executioner |
| Helios Mandate | Authoritarian corporate | Gold, white | Clean, temple-like | Enforcer, Corvette |
| Marshal Corps | Law enforcement | Blue, silver | Uniform, utility | Patrol, Pursuer |
| Ghost Market | Black market | Dark purple, green | Hidden tech, mysterious | Specter, Smuggler |
| Phantom Fleet | Mystery force | Ethereal white, void | Not-of-this-world | Shade, Wraith |
| Fringe Settlers | Civilian frontier | Earthy browns, reds | Cobbled-together, homemade | Hauler, Militia |

## Reputation mechanics

Range: -100 tot +100

- **-100 to -75**: Kill on sight, blacklisted
- **-74 to -25**: Hostile, will attack
- **-24 to +24**: Neutral
- **+25 to +74**: Friendly, discounts, missions available
- **+75 to +100**: Allied, elite missions, exclusive ships/weapons

Cross-faction: helpen aan Faction A = rep verlies bij Faction B (als rivaals).

Rivalry matrix:
- Harkon ↔ Marshal: -0.5× (helpen marshal kost harkon rep)
- Helios ↔ Ghost Market: -0.7× (strong rivals)
- Helios ↔ Fringe: -0.3× (Helios ziet Fringe als rebels)
- Phantom: isolationist, geen directe rivals maar ook geen allies

## Per faction deep dive

### Harkon (prompts 59-60)
**Lore**: Opkomende piratenclan, groeit in macht. Rex Varn heeft persoonlijke vete.  
**Gameplay**: Primary enemy source vroeg-game. Reveal: leader = Rex's oude partner.  
**Missions**: Tegen Harkon (Marshal bounties), of infiltreren (Ghost Market sympathizers).

### Helios Mandate (prompts 61-63)
**Lore**: Corporate-authoritarian hybride. Controleert 40% van systems. Religion-like hierarchy.  
**Gameplay**: Patrol gauntlets, Enforcer encounters. Can ally, maar cost to freedom.  
**Missions**: Tribute collection, heretic hunting, expansion - morally grey.  
**Unique mechanic**: Helios ships hebben "doctrine points" die passives activeren.

### Marshal Corps (prompts 64-66)
**Lore**: Onafhankelijk lawkeeper body. Niet corrupt maar pragmatisch. Oude hands.  
**Gameplay**: Bounty hunting, escort, pursuit. Most "good guys" maar bound by procedure.  
**Missions**: Bounty targets, civil order, investigation.  
**Unique mechanic**: Marshal rep unlocks legal recourse (sue Helios, request backup).

### Ghost Market (prompts 67-68)
**Lore**: Semi-organized black market. Not one leader, many brokers. Everyone welcome als je betaalt.  
**Gameplay**: Hidden stations, contraband trade, illegal mods. High risk high reward.  
**Missions**: Smuggling, data heists, assassinations (morally dark).  
**Unique mechanic**: Access tot otherwise-impossible items, maar aantrekt Marshal attention.

### Phantom Fleet (prompts 69-70)
**Lore**: Mystery. Onbekende origin. Only ever glimpsed. Connection to Silurians hinted.  
**Gameplay**: Rare encounters. Phantom ships appear, disappear. Dialog sparingly.  
**Missions**: Cryptic quests with unusual rewards.  
**Unique mechanic**: Phantom favor unlocks reality-bending abilities (jump skip, precog).  
**Canon link**: Zie `SYNTHARI_LORE.md` - Phantom might be Synthari scouts OR Silurian remnants.

### Fringe Settlers (prompts 71-72)
**Lore**: Colonists on harsh worlds. Not organized politically, but tight-knit.  
**Gameplay**: Quest givers, info sources, occasional militia support.  
**Missions**: Protect settlements, deliver supplies, rescue kidnapped.  
**Unique mechanic**: Fringe friendship = safe harbor anywhere (hide from Marshal, rest, heal).

## Faction war triggers (prompt 73 is in F3 but referenced here)

Dynamic world events:

- If Helios rep ≥ 75 AND Harkon rep ≤ -50: Helios launches crackdown on Harkon. Chaos in Harkon-held systems for 5 in-game days.
- If Ghost Market rep ≥ 75: Ghost Market offers Rex a "seat at the table" quest.
- If Marshal rep ≥ 90 AND any faction ≤ -90: Marshal offers "Lawbringer" endgame quest.
- If Phantom rep present (any positive): unlocks "The Drifter" encounter at 20% rate.

## Cross-faction missions

Mission types where 2+ factions are involved (e.g., Marshal wants you to infiltrate Ghost Market while maintaining Ghost Market rep):
- Prompt 72 implements the framework
- Missions give choices: lie to one faction, honest approach, double-cross

## Dialog style per faction

Belangrijk voor Agent 07 Narrative Jury en Agent 29 voice:

- **Harkon**: coarse, threats, short sentences. "You crossed us. Wrong move."
- **Helios**: formal, corporate-religious. "The Mandate provides. Your compliance honors."
- **Marshal**: professional, procedural. "I need to ask you some questions. Take your time."
- **Ghost Market**: evasive, jargon, pricing obsession. "Twenty thousand. Final offer. Or find another broker."
- **Phantom**: enigmatic, incomplete sentences. "The path you walk... has been walked. And yet."
- **Fringe**: earnest, colloquial. "Stranger, you saved my kid. That don't get forgotten out here."

## Faction palettes (voor NOVA Agent 20 Design Fase)

Elke faction krijgt 16-color palette voor ship sprites:

- Harkon: deep reds, blacks, brass, bone white
- Helios: golds, whites, royal blues, marble
- Marshal: navy blues, silvers, patina greens
- Ghost Market: purples, neon greens, dark chrome
- Phantom: ethereal whites, voids, iridescents
- Fringe: rust, leather browns, dusty reds, tarps

NOVA pipeline gebruikt deze als basis voor ship/station/NPC consistency.

## Integration met G5 Deep Reputation

F2 gives each faction basic rep mechanics. G5 (prompts 179-184) deepens:
- Multi-axis rep (trust vs fear vs respect)
- Branching consequences (rep affects dialog trees, shop access, mission availability)
- Reputation recovery paths (quest lines to redeem yourself)
