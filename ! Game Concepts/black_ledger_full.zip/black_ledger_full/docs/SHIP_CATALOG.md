# Ship Catalog - Black Ledger

Complete ship archetypes voor gebruik in F1 prompts (43-58).

## Baseline: USP Talon (MVP)

Uit MVP prompt_04_ship_component_system.md. Alle andere ships gemeten tegen deze baseline:

| Stat | USP Talon | Waarde |
|------|-----------|--------|
| HP | 100 | 1.0× |
| Shield | 50 | 1.0× |
| Speed | 300 | 1.0× |
| Agility (turn rate) | 3.0 | 1.0× |
| Cargo capacity | 20 | 1.0× |
| Weapon mounts | 2 | baseline |
| Engine efficiency | 1.0 | baseline |

Rex Varn's ship. All-rounder.

## F1 Ships (prompts 43-54)

### USP Razor (prompt 43)
**Archetype**: Interceptor  
**HP**: 70, Shield: 30, Speed: 450, Agility: 5.0, Cargo: 10, Mounts: 2  
**Role**: Hit-and-run, scout missions  
**Acquisition**: Shop Korrigan-3 (level 5)

### USP Guardian (prompt 44)
**Archetype**: Defender  
**HP**: 120, Shield: 80, Speed: 250, Agility: 2.5, Cargo: 25, Mounts: 3  
**Role**: Escort missions, tank builds  
**Acquisition**: Marshal Outpost (rep 50+)

### USP Crusher (prompt 45)
**Archetype**: Heavy fighter  
**HP**: 150, Shield: 60, Speed: 220, Agility: 2.0, Cargo: 15, Mounts: 4  
**Role**: Boss fights, arena battles  
**Acquisition**: Ghost Market (level 15)

### Helios Enforcer playable (prompt 46)
**Archetype**: Captured ship from MVP boss  
**HP**: 140, Shield: 90, Speed: 280, Agility: 3.2, Cargo: 18, Mounts: 3  
**Role**: Mid-game workhorse, lore-relevant  
**Acquisition**: Defeat MVP boss + boarding (H3)

### Helios Corvette (prompt 47)
**Archetype**: Medium combat  
**HP**: 130, Shield: 75, Speed: 260, Agility: 2.8, Cargo: 22, Mounts: 3  
**Role**: Helios faction mission reward  
**Acquisition**: Helios rep 75+

### Harkon Reaver (prompt 48)
**Archetype**: Scout variant  
**HP**: 80, Shield: 40, Speed: 380, Agility: 4.5, Cargo: 12, Mounts: 2  
**Role**: Harkon infiltration  
**Acquisition**: Capture via boarding, or Ghost Market

### Harkon Executioner (prompt 49)
**Archetype**: Elite assassin  
**HP**: 110, Shield: 70, Speed: 340, Agility: 4.0, Cargo: 14, Mounts: 3  
**Role**: High-risk high-reward combat  
**Acquisition**: Mid-boss reward (level 10)

### Marshal Patrol (prompt 50)
**Archetype**: Lawful patrol  
**HP**: 115, Shield: 65, Speed: 290, Agility: 3.1, Cargo: 20, Mounts: 3  
**Role**: Marshal faction alignment ship  
**Acquisition**: Marshal rep 90+

### Ghost Market Specter (prompt 51)
**Archetype**: Stealth smuggler  
**HP**: 95, Shield: 55, Speed: 320, Agility: 3.8, Cargo: 35, Mounts: 2 + cloak slot  
**Role**: Smuggling, evasion  
**Acquisition**: Ghost Market rep 60+

### Phantom Shade (prompt 52)
**Archetype**: Mysterious  
**HP**: 105, Shield: 150 (unique - shield-heavy), Speed: 310, Agility: 3.4, Cargo: 16, Mounts: 2 + phantom slot  
**Role**: Lore-heavy encounter ship  
**Acquisition**: Phantom secret quest

### Fringe Hauler (prompt 53)
**Archetype**: Large cargo  
**HP**: 140, Shield: 45, Speed: 200, Agility: 1.8, Cargo: 80, Mounts: 2  
**Role**: Dedicated trader  
**Acquisition**: Fringe rep 50+

### Drifter Wraith (prompt 54)
**Archetype**: Unique one-of  
**HP**: 125, Shield: 100, Speed: 330, Agility: 3.6, Cargo: 18, Mounts: 3 + drifter slot (unique ability)  
**Role**: Secret unlock, endgame  
**Acquisition**: Complete Drifter arc (J5)

## F1 Variants (prompts 55-58)

- Prompt 55: Faction paint schemes (visual only, no stat changes)
- Prompt 56: Central ship database resource
- Prompt 57: Acquisition system (shop/reward/capture/quest unlock flags)
- Prompt 58: Ship inspection UI (detailed stats screen)

## Synthari Ships (H2 prompts 207-220)

Separate tech tree, revealed when playing Synthari campaign:

- Xeth Stinger (Synthari interceptor)
- Xeth Voidrunner (Synthari scout)
- Xeth Prism (Synthari defender met shield tech)
- Xeth Monolith (Synthari heavy)
- 4 more variants

Synthari ships have unique "resonance" mount type - mechanic exclusive to H2.

## Balance regels

1. **Total stat budget**: HP + Shield + Speed + (Agility × 50) + (Cargo × 2) = 500-600 voor standard ships
2. **Specialty tax**: specialty ships (extreme one stat) betalen in andere stats
3. **Mount count**: meer mounts = lagere stats elders
4. **Agent 10 Jury**: elke nieuwe ship moet "accept" krijgen
5. **Progression**: vroege ships < mid-game < late-game, maar altijd situationeel waardevol

## Ship database structuur

`resources/ship_database.tres` (Godot Resource):

```gdscript
class_name ShipDatabase extends Resource

@export var ships: Array[ShipData] = []

func get_ship(id: String) -> ShipData:
    for ship in ships:
        if ship.id == id:
            return ship
    return null
```

Elke ShipData bevat stats, sprite_path, acquisition_flags, faction_affinity, unique_mechanic_ref.
