# Prompt 208: Synthari backstory integration (Zygon Incident)

**Fase**: H_procedural  
**Sub**: h2_synthari  
**Time estimate**: 3-5 uur

## Doel

Implementeer Synthari backstory integration (Zygon Incident) voor Synthari race.

## Context

Ref: docs/SYNTHARI_LORE.md + Surilians canon connection. Synthari is playable alien race met eigen arc.

**Recente dependencies**: prompts 198, 199, 200, 201, 202, 203, 204, 205, 206, 207

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Canon consultation (Agent 07 Narrative Jury)
2. Implementation GDScript
3. Asset generation via NOVA
4. Save/load Synthari save slots
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Synthari path playable
- Canon consistent met Surilians lore
- Unieke mechanics werken
- Feel duidelijk anders dan Man path

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "h2_synthari: synthari backstory integration (zygon incident)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 209
