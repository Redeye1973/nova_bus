# Prompt 239: Secret ship (Drifter unlock)

**Fase**: H_procedural  
**Sub**: h5_secret  
**Time estimate**: 2-3 uur

## Doel

Implementeer Secret ship (Drifter unlock).

## Context

Secrets motiveren replayability. Inspired by Tyrian 2000's secret levels.

**Recente dependencies**: prompts 229, 230, 231, 232, 233, 234, 235, 236, 237, 238

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Trigger condities
2. Content per secret
3. Discovery feedback
4. Save tracking

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Secrets triggerbaar zonder guide (subtle hints)
- Unieke rewards
- Niet game-breaking voor first playthrough

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "h5_secret: secret ship (drifter unlock)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 240
