# Prompt 227: Boarding-specific abilities

**Fase**: H_procedural  
**Sub**: h3_boarding  
**Time estimate**: 3-4 uur

## Doel

Implementeer Boarding-specific abilities voor boarding minigame.

## Context

Ref: docs/MEGALODON_SPEC.md - originally spec'd boarding minigame.

**Recente dependencies**: prompts 217, 218, 219, 220, 221, 222, 223, 224, 225, 226

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Scene setup
2. Mechanics (side-view shooter per corridor)
3. NOVA asset generation
4. Integratie met main game
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Boarding triggers bij disabled enemy ship
- Minigame speelbaar
- Rewards correct
- Terug naar main game smooth

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "h3_boarding: boarding-specific abilities"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 228
