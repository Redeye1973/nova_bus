# H_procedural - Procedural + Synthari

**Prompts**: 191-240  
**Duration**: 2 maanden  
**Scope**: Procedural content + Synthari race playable.

## Key output

Procedural biomes oneindig, Synthari playable met alternate campaign

## Sub-fases

| Sub | Prompts | Beschrijving |
|-----|---------|--------------|
| h1_biomes | 191-206 | Procedural biome generator, 10 themes, seed-based |
| h2_synthari | 207-220 | Synthari race playable met eigen tech en endings |
| h3_boarding | 221-228 | Boarding minigame (corridor shooter) |
| h4_ship_capture | 229-234 | Ship capture + modification workbench |
| h5_secret | 235-240 | Wormholes, Easter eggs, hidden content |

## Prerequisite

- MVP compleet en speelbaar
- Vorige fasen in deze Full Build afgerond (indien van toepassing)
- NOVA v2 agents operationeel

## Workflow

1. Open sub directory (bv. `h1_biomes/`)
2. Begin met laagst genummerde prompt
3. Cursor autonome build van prompt
4. Testen per acceptance criteria in prompt
5. Git commit
6. Volgende prompt

## Validation na afgeronde fase

Run:
```powershell
.\utils\validate_fase.ps1 -Fase H_procedural
```

Controleert:
- Alle prompts gecommit
- Tests groen
- Geen regression vs MVP
- Canon consistency

## Milestones

Schrijf milestone file `docs/milestone_H_procedural.md` na voltooiing met:
- Datum
- Prompts voltooid: X/Y
- Issues gevonden + fixes
- Volgende fase readiness

## Go to next fase criteria

**Go** als:
- 90%+ prompts voltooid zonder critical issues
- Playtest sessie bevestigt gameplay flow
- Geen regressions in MVP features

**Stop + fix** als:
- Performance degradation significant
- Critical bugs in core mechanics  
- Canon drift detected

