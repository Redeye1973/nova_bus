# Prompt 193: Tileset generation per biome

**Fase**: H_procedural  
**Sub**: h1_biomes  
**Time estimate**: 3-5 uur

## Doel

Implementeer Tileset generation per biome voor procedural biomes.

## Context

Ref: docs/BIOME_GENERATOR.md. Inspired by No Man's Sky / Starbound procedural.

**Recente dependencies**: prompts 186, 187, 188, 189, 190, 191, 192, 20, 21, 22

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Algorithm + data structure
2. NOVA pipeline integratie voor tile generation
3. Godot scene instantiation
4. Save/load (seed opslaan, niet content)
5. Testing met meerdere seeds

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Generated biomes voelen uniek
- Difficulty scales met player level
- Performance < 2s generation time
- Seed reproducibility

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "h1_biomes: tileset generation per biome"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 194
