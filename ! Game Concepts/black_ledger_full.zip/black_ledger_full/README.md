# Black Ledger Full Build

Complete content + systems build na MVP vertical slice. Sequentiële Cursor prompts 43-370 verdeeld over 6 fasen (F t/m K).

## Vereisten

- MVP compleet gedraaid en speelbaar (Korrigan-3 escape + boss)
- NOVA v2 pipeline operationeel (32 agents draaiend)
- RTX 5060 Ti 16GB geïnstalleerd voor AI acceleratie
- Black Ledger project in `L:\1 Nova Cursor Output\Dark Ledger\`

## Structuur

```
Fase F - Content Expansion       [prompts 43-120] ~78 prompts
Fase G - Deep Systems            [prompts 121-190] ~70 prompts
Fase H - Procedural + Synthari   [prompts 191-240] ~50 prompts
Fase I - Planetside              [prompts 241-290] ~50 prompts
Fase J - Polish + Content        [prompts 291-340] ~50 prompts
Fase K - Release Prep            [prompts 341-370] ~30 prompts
```

Totaal: ~328 prompts. Elke prompt 1-3 uur Cursor werk. Totaal: 6-12 maanden solo dev met 24/7 PC.

## Schaalbaarheid

Als je dit te groot vindt:
- **Minimum viable product**: fase F + K = speelbare demo met 10 levels
- **Core experience**: F + G + K = volledige space gameplay
- **Rich experience**: F + G + H + J + K = met Synthari + procedureel
- **Complete vision**: alles = Wing Commander Privateer scope

## Start

Open `00_master/START_HERE.md` en volg stappen.

## Design basis

Hele pipeline baseert op:
- `docs/CANON_COMPLETE.md` - Black Ledger lore compleet
- `docs/SYNTHARI_LORE.md` - Synthari race details (uit BLACK_LEDGER_SYNTHARI_LORE.md)
- `docs/MEGALODON_SPEC.md` - originele 8-prompt megaspec
- `docs/DATAPAD_SYSTEM.md` - Ledger Book mechanic
- `docs/STARMAP_DESIGN.md` - jumpholes + wormholes
- `docs/BIOME_GENERATOR.md` - procedural worlds
