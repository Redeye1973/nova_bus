# G_systems - Deep Systems

**Prompts**: 121-190  
**Duration**: 2-3 maanden  
**Scope**: Wing Commander Privateer mechanics: starmap, datapad, cargo, bounty, reputation deep, economy.

## Key output

Volledige starmap met jumpholes en wormholes, Ledger Book, cargo systeem, bounty + revenge

## Sub-fases

| Sub | Prompts | Beschrijving |
|-----|---------|--------------|
| g1_starmap | 121-134 | Starmap navigation met jumpholes en wormholes |
| g2_datapad | 135-152 | Datapad + Ledger Book (cross-reference engine) |
| g3_cargo | 153-164 | Cargo hold, market, scanning, contraband |
| g4_bounty | 165-178 | Bounty system met Ace NPCs en revenge chains |
| g5_reputation | 179-184 | Multi-axis reputation met consequences |
| g6_economy | 185-190 | Supply/demand economy simulation |

## Prerequisite

- MVP compleet en speelbaar
- Vorige fasen in deze Full Build afgerond (indien van toepassing)
- NOVA v2 agents operationeel

## Workflow

1. Open sub directory (bv. `g1_starmap/`)
2. Begin met laagst genummerde prompt
3. Cursor autonome build van prompt
4. Testen per acceptance criteria in prompt
5. Git commit
6. Volgende prompt

## Validation na afgeronde fase

Run:
```powershell
.\utils\validate_fase.ps1 -Fase G_systems
```

Controleert:
- Alle prompts gecommit
- Tests groen
- Geen regression vs MVP
- Canon consistency

## Milestones

Schrijf milestone file `docs/milestone_G_systems.md` na voltooiing met:
- Datum
- Prompts voltooid: X/Y
- Issues gevonden + fixes
- Volgende fase readiness

## Go to next fase criteria

**Go** als:
- 90%+ prompts voltooid zonder critical issues
- Playtest sessie bevestigt gameplay flow
- Geen regressions in MVP features

**Stop + fix** als:
- Performance degradation significant
- Critical bugs in core mechanics  
- Canon drift detected

