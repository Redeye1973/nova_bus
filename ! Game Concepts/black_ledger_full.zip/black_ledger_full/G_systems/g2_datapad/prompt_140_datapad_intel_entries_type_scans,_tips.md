# Prompt 140: Intel entries type (scans, tips)

**Fase**: G_systems  
**Sub**: g2_datapad  
**Time estimate**: 2-4 uur

## Doel

Implementeer Intel entries type (scans, tips) voor datapad systeem.

## Context

Ref: docs/DATAPAD_SYSTEM.md. Dit is het Ledger Book - zeer centraal in Black Ledger.

**Recente dependencies**: prompts 131, 132, 133, 134, 135, 136, 137, 138, 139, 28

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Entry class of UI component in Godot
2. Integratie met bestaande systems (missions, cargo, npc)
3. Visual design volgens docs/DATAPAD_SYSTEM.md
4. Cross-references auto-detection (via Agent 28)
5. Save/load support
6. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Entry rendering correct
- Cross-references werken
- Filtering + search responsief
- Geen XP-drop bij veel entries (100+)

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "g2_datapad: intel entries type (scans, tips)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 141
