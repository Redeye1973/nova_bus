# Prompt 181: Reputation recovery mechanics

**Fase**: G_systems  
**Sub**: g5_reputation  
**Time estimate**: 3-4 uur

## Doel

Implementeer Reputation recovery mechanics.

## Context

MVP heeft basic rep (-100 to +100) voor Harkon + Marshal. Nu multi-dimensionaal.

**Recente dependencies**: prompts 174, 175, 176, 177, 178, 179, 180, 39, 65, 66

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Deep mechanics beyond MVP reputation
2. Integratie met alle faction systems
3. UI feedback
4. Save/load
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Rep mechanics werken correct
- Access gates enforced
- Dialogs passen bij rep

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "g5_reputation: reputation recovery mechanics"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 182
