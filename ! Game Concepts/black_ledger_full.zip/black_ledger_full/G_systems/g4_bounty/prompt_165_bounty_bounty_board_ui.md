# Prompt 165: Bounty board UI

**Fase**: G_systems  
**Sub**: g4_bounty  
**Time estimate**: 2-4 uur

## Doel

Implementeer Bounty board UI voor bounty systeem.

## Context

MVP heeft basic bounty missie. Nu full system met Aces, chains, notorious targets.

**Recente dependencies**: prompts 157, 158, 159, 160, 161, 162, 163, 164, 37, 38

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Data model
2. AI behavior voor bounty targets
3. UI integratie (bounty board station view)
4. Reward distribution
5. Narrative hooks (news, dialog)
6. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Bounties genereren zinnig
- Targets spawnen correct
- Rewards uitgekeerd
- Revenge chain activate bij target survive

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "g4_bounty: bounty board ui"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 166
