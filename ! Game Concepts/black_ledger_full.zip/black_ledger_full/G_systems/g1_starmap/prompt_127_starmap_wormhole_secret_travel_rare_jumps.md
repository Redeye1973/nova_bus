# Prompt 127: Wormhole secret travel (rare jumps)

**Fase**: G_systems  
**Sub**: g1_starmap  
**Time estimate**: 2-4 uur

## Doel

Implementeer Wormhole secret travel (rare jumps) voor starmap navigatie.

## Context

Referentie: docs/STARMAP_DESIGN.md voor volledig design. Vergelijk met Wing Commander Privateer starmap.

**Recente dependencies**: prompts 119, 120, 121, 122, 123, 124, 125, 126, 99, 100

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Data model in GDScript resource
2. UI element in main scene hierarchy
3. Input handling
4. Save/load integratie
5. Visual polish (animations, feedback)
6. Test cases

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- UI loadt + respond
- Navigation werkt end-to-end
- Save/load behoudt state
- Performance OK met 50+ systems

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "g1_starmap: wormhole secret travel (rare jumps)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 128
