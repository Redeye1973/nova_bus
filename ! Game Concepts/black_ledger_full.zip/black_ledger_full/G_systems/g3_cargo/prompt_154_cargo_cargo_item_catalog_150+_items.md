# Prompt 154: Cargo item catalog (150+ items)

**Fase**: G_systems  
**Sub**: g3_cargo  
**Time estimate**: 2-3 uur

## Doel

Implementeer Cargo item catalog (150+ items) voor cargo systeem.

## Context

Privateer-inspired trading. Items kopen in systeem A, verkopen duurder in B. Cargo scan door Marshal = contraband risico.

**Recente dependencies**: prompts 146, 147, 148, 149, 150, 151, 152, 153, 4, 96

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Data model + Godot resource
2. Integration met ship system (cargo bay)
3. UI element waar relevant
4. Economy integration (prices)
5. Save/load
6. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Cargo adds/removes correct uit hold
- Weight constraints enforced
- Prices fluctueren per station
- Contraband detectie werkt

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "g3_cargo: cargo item catalog (150+ items)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 155
