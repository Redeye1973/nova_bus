# Prompt 190: Economy analytics dashboard (dev tool)

**Fase**: G_systems  
**Sub**: g6_economy  
**Time estimate**: 3-5 uur

## Doel

Implementeer Economy analytics dashboard (dev tool).

## Context

Wing Commander Privateer had static prices. Wij gaan dynamisch met supply/demand per systeem.

**Recente dependencies**: prompts 180, 181, 182, 183, 184, 185, 186, 187, 188, 189

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Simulation model
2. Tick update logic
3. Integratie met cargo trading
4. Events trigger per type
5. UI (waar relevant)

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Prices fluctueren logisch
- Events triggeren + resolvent
- Player trading beinvloedt markt
- Performance OK (sim runt async)

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "g6_economy: economy analytics dashboard (dev tool)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 191
