# Master Plan - Black Ledger Full Build

## Fase overzicht

### Fase F - Content Expansion (prompts 43-120, 78 prompts)

**Doel**: alle content breedte. Ships, factions, weapons, enemies, stations, levels.

**Sub-fases**:

| Sub | Onderwerp | Prompts | Output |
|-----|-----------|---------|--------|
| F1 | Additional Ships (USP Razor, Helios Corvette, Harkon Reaver, etc) | 43-58 | 8 extra ships + variants |
| F2 | Complete Factions (alle 6 interactief) | 59-72 | Helios, Marshal, Ghost Market, Phantom, Fringe elk werkend |
| F3 | Full Weapon System | 73-82 | 15 weapon types, mod slots, upgrade tree |
| F4 | Enemy Roster | 83-94 | 6 factions × 9 ship variants = 54 enemies |
| F5 | Station Network | 95-104 | 8 stations elk uniek met services |
| F6 | All 28 Levels | 105-120 | Korrigan-3 → Boss Final |

### Fase G - Deep Systems (prompts 121-190, 70 prompts)

**Doel**: Wing Commander Privateer mechanics.

| Sub | Onderwerp | Prompts |
|-----|-----------|---------|
| G1 | Starmap + Jumpholes | 121-134 |
| G2 | Datapad + Ledger Book | 135-152 |
| G3 | Cargo System + Scanning | 153-164 |
| G4 | Bounty + Revenge System | 165-178 |
| G5 | Deep Reputation (branching consequences) | 179-184 |
| G6 | Economy Simulation | 185-190 |

### Fase H - Procedural + Synthari (prompts 191-240, 50 prompts)

**Doel**: infinite content + playable alien race.

| Sub | Onderwerp | Prompts |
|-----|-----------|---------|
| H1 | Procedural Biome Generator | 191-206 |
| H2 | Synthari Race (playable) | 207-220 |
| H3 | Boarding Minigame | 221-228 |
| H4 | Ship Capture + Modification | 229-234 |
| H5 | Secret Content (wormholes, Easter eggs) | 235-240 |

### Fase I - Planetside (prompts 241-290, 50 prompts)

**Doel**: Blackthorne-style side-scrolling shooter met GIS terrain.

| Sub | Onderwerp | Prompts |
|-----|-----------|---------|
| I1 | Blackthorne Core (side-view shooter) | 241-256 |
| I2 | PDOK 3D Tiles + Aliens Textures | 257-268 |
| I3 | NPC System (planetside) | 269-276 |
| I4 | Dialog System | 277-284 |
| I5 | Ground Missions | 285-290 |

### Fase J - Polish + Content (prompts 291-340, 50 prompts)

**Doel**: alles voelt alive.

| Sub | Onderwerp | Prompts |
|-----|-----------|---------|
| J1 | Voice Acting (ElevenLabs all chars) | 291-300 |
| J2 | Full Music Score (28 tracks) | 301-310 |
| J3 | News Ticker + Dynamic Events | 311-318 |
| J4 | 3 Endings Fully Playable | 319-328 |
| J5 | The Drifter Encounter System | 329-334 |
| J6 | Canon Integration Pass | 335-340 |

### Fase K - Release (prompts 341-370, 30 prompts)

**Doel**: launch-ready.

| Sub | Onderwerp | Prompts |
|-----|-----------|---------|
| K1 | Android Port + Mobile Controls | 341-350 |
| K2 | Steam Integration Prep | 351-358 |
| K3 | Balance Final Pass | 359-364 |
| K4 | QA Automation | 365-368 |
| K5 | Launch Content (trailer, screenshots) | 369-370 |

## Tijdschatting

Onder deze aannames:
- 24/7 PC met NOVA v2 agents helpend
- Jij werkt 3-5u/dag aan game
- 2 prompts per dag gemiddeld (1u review/test + nachtelijke agent work)

| Scope | Prompts | Dagen | Maanden |
|-------|---------|-------|---------|
| Optie A (F+K) | 108 | 54 | 2.5 |
| Optie B (F+G+K) | 178 | 89 | 4.5 |
| Optie C (All) | 328 | 164 | 8 |

Realistisch: **12 maanden voor Optie C** inclusief bug fixes, refactoring, burn-out buffers.

## Asset productie load per fase

NOVA pipeline moet deze assets maken:

### Fase F
- 8 ships × 4 damage states × 8 angles = 256 ship sprites
- 54 enemies × 4 states = 216 enemy sprites
- 6 faction palette packs
- 15 weapon icons + projectile sprites
- 8 station interior backgrounds
- 28 level background tilesets

Total: ~600-800 art assets

### Fase G
- 150+ cargo item icons
- 20+ datapad illustrations
- Starmap system (data + sprites)
- Bounty portraits (50+)

### Fase H
- Procedural biome tilesets (infinite, maar ~20 base variaties)
- Synthari ship sprites (8 ships × 4 states × 8 angles = 256)
- Synthari character sprites
- Boarding minigame sprites (corridors, guards, etc)

### Fase I
- Planetside character sprites (Rex Varn side-view + animations)
- Alien texture maps voor PDOK tiles
- 20+ NPC portraits
- Dialog UI

### Fase J
- Voice: 500+ lines × alle characters = 2000-5000 audio files
- Music: 28 full tracks + variations
- News broadcaster portraits + audio

Totaal assets: **3000-5000 files** via NOVA pipeline. Zonder pipeline: onmogelijk. Met pipeline: 6-12 maanden gradueel.

## Kritieke beslissingen

### Beslissing 1: Scope nu vastleggen
Niet tijdens development switchen. Kies optie bij start.

### Beslissing 2: Multiplayer? (NEE)
Multiplayer verdubbelt complexity. Niet in scope. Single player only.

### Beslissing 3: Mod support? (LATER)
Nice-to-have na v1.0 launch. Niet in Full Build.

### Beslissing 4: VR support? (NEE)
Top-down shmup vertaalt slecht naar VR. Niet doen.

### Beslissing 5: Art style consistency
Tyrian 2000 aesthetic. Pixel art + minimal 3D. Niet mengen met realistic render.

### Beslissing 6: Platforms
- Primary: Windows (MVP al hier)
- Secondary: Android (Fase K1)
- Tertiary: Linux, MacOS (bonus, Godot ondersteunt)
- NIET: iOS (App Store hassle)
- NIET: Console (publishers te duur)

## Parallel workstreams

Tijdens solo dev:
- **Code stream**: jij + Cursor (sequentiële prompts)
- **Asset stream**: NOVA v2 agents (parallel 24/7)
- **Design stream**: jij tijdens pauzes, update canon docs
- **Test stream**: automated via Build Agent + jouw playtesting

Dit parallellisme is waarom NOVA waarde heeft.

## Success criteria

**Optie A geslaagd als**:
- 28 levels speelbaar end-to-end
- 9 ships verkrijgbaar
- 6 factions hebben werkende reputation
- Geen critical bugs
- 60fps op midrange hardware

**Optie B geslaagd als**:
- + starmap navigatie werkt
- + 30+ missies bounty/escort/cargo/patrol
- + datapad leest als echte ingame boek
- + economy feels alive

**Optie C geslaagd als**:
- + Synthari run volledig speelbaar
- + procedurele sectoren oneindig herspeelbaar
- + planetside mode als afwisseling
- + 3 endings cinematic + consequent

## Wat NIET in Full Build

Expliciet uit scope:
- Expansions post-launch (aparte track)
- Character customization visueel (Man/Vrouw only, niet face editor)
- Ship customization cosmetisch (alleen mechanic via components)
- Multiplayer (nooit)
- Live service / seizoenen (nooit)
- NFT / blockchain (nooit)

## Volgende stap

Open `F_content/README.md`
