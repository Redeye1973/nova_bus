# START HIER - Black Ledger Full Build

## Voor je begint

1. **MVP moet speelbaar zijn**. Test eerst de vertical slice:
   - Starten bij Korrigan-3 station
   - USP Talon vliegbaar, 3 weapons werkend
   - Helios Enforcer boss verslaanbaar
   - Save/load werkt
   - Character creation (Man variant) compleet
   - Windows .exe build runt

2. **NOVA v2 pipeline moet draaien**. Check:
   ```powershell
   .\utils\status_check.ps1
   ```
   Minstens 25/32 agents active of fallback.

3. **Hardware check**: RTX 5060 Ti 16GB aanwezig, Ollama heeft Qwen 2.5 Coder 9B geladen.

4. **Backup**: maak volledige backup van MVP project VOOR je begint met Full Build.
   ```powershell
   Copy-Item "L:\1 Nova Cursor Output\Dark Ledger\" "L:\backups\DarkLedger_MVP_baseline_$(Get-Date -Format 'yyyy-MM-dd')\" -Recurse
   ```

## Strategische keuze voordat je start

Je hoeft NIET alle 328 prompts te doen. Kies jouw scope:

### Optie A: "Complete Tyrian Plus" (Fase F + K only, ~108 prompts)
- Alle 28 levels + 9 ships + 6 factions compleet
- 3-4 maanden werk
- Eindresultaat: rijke top-down shmup zoals Tyrian 2000 maar dieper
- **Laat weg**: datapad ledger book, procedureel, planetside, Synthari

### Optie B: "Wing Commander Privateer" (Fase F + G + K, ~178 prompts)
- Alles van A + starmap met jumpholes + datapad + cargo + bounty systeem
- 6-8 maanden werk
- Eindresultaat: complete space trading + combat simulator
- **Laat weg**: planetside, procedureel oneindig, Synthari

### Optie C: "Full Vision" (alle fases, ~328 prompts)
- Alles van B + Synthari race + procedureel + planetside + 3 endings full
- 12+ maanden werk
- Eindresultaat: unieke space RPG met planetside shooter segmenten
- Nvm: dit is realistisch 2 jaar solo dev

### Optie D: "Progressive release" (aanbevolen)
- Eerst fase F - release als Early Access
- Krijg feedback en inkomen
- Dan G - major update
- Dan H/I/J/K - volgende expansion
- Eindresultaat: releaseable tussentijdse versies, risk-managed

**Beslissing nemen**: bepaal scope VOORDAT je start. Halverwege van scope switchen kost tijd.

## Volgorde per fase

Elke fase heeft eigen README. Volg deze volgorde:

1. Lees fase README
2. Open eerste prompt in fase
3. Gebruik MVP prompt template patroon
4. Cursor bouwt, jij test
5. Git commit per prompt
6. Volgende prompt

**GEEN prompt overslaan** zonder dependency check. Prompts zijn sequentieel om dependency redenen.

## Prompt template (zelfde als MVP)

Elke prompt in deze build volgt dit patroon:

```
# Prompt XX: [titel]
## Doel
[wat bouwen]
## Context
- MVP: al gebouwd
- Vorige prompts: [nummers]
- Design reference: docs/[relevant doc].md
## Taken
1. [stap]
2. [stap]
## Testing
- [acceptance criteria]
## Git
Commit message: "[component]: [change]"
```

## Daily workflow

```
09:00 - Check pipeline status (status_check.ps1)
09:15 - Open volgende prompt in Cursor
09:30 - Laat Cursor 1-2u autonoom werken
11:30 - Review + test
12:00 - Commit + volgende prompt
...
17:00 - Daily build (via Build Agent)
18:00 - Smoketest latest build
```

## Als iets faalt

1. **Check dependency**: waren vorige prompts echt af?
2. **Check NOVA agents**: asset agents responsief?
3. **Rollback**: `git checkout` naar last working commit
4. **Split up**: prompt te groot? Handmatig splitsen
5. **Escalatie**: nieuwe Claude sessie met context

## Klaar om te beginnen?

Ga naar `F_content/README.md` voor Fase F (Content Expansion).
