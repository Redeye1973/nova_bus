# K_release - Release Prep

**Prompts**: 341-370  
**Duration**: 1 maand  
**Scope**: Launch-ready: Android port, Steam prep, balance, QA, launch materials.

## Key output

Android APK, Steam page ready, balanced, QA-tested, launch content compleet

## Sub-fases

| Sub | Prompts | Beschrijving |
|-----|---------|--------------|
| k1_android | 341-350 | Android build + mobile controls |
| k2_steam | 351-358 | Steam integration + store page |
| k3_balance | 359-364 | Final balance pass alle levels |
| k4_qa | 365-368 | QA automation + regression tests |
| k5_launch | 369-370 | Launch trailer + day checklist |

## Prerequisite

- MVP compleet en speelbaar
- Vorige fasen in deze Full Build afgerond (indien van toepassing)
- NOVA v2 agents operationeel

## Workflow

1. Open sub directory (bv. `k1_android/`)
2. Begin met laagst genummerde prompt
3. Cursor autonome build van prompt
4. Testen per acceptance criteria in prompt
5. Git commit
6. Volgende prompt

## Validation na afgeronde fase

Run:
```powershell
.\utils\validate_fase.ps1 -Fase K_release
```

Controleert:
- Alle prompts gecommit
- Tests groen
- Geen regression vs MVP
- Canon consistency

## Milestones

Schrijf milestone file `docs/milestone_K_release.md` na voltooiing met:
- Datum
- Prompts voltooid: X/Y
- Issues gevonden + fixes
- Volgende fase readiness

## Go to next fase criteria

**Go** als:
- 90%+ prompts voltooid zonder critical issues
- Playtest sessie bevestigt gameplay flow
- Geen regressions in MVP features

**Stop + fix** als:
- Performance degradation significant
- Critical bugs in core mechanics  
- Canon drift detected

