# Prompt 352: Steam API integration (achievements, cloud saves)

**Fase**: K_release  
**Sub**: k2_steam  
**Time estimate**: 2-4 uur

## Doel

Implementeer Steam API integration (achievements, cloud saves).

## Context

Steam is primary PC distribution. Prep maar geen publish (dat gebeurt buiten dev stream).

**Recente dependencies**: prompts 342, 343, 344, 345, 346, 347, 348, 349, 350, 351

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Steam SDK integration waar relevant
2. Content generation via NOVA
3. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Steam features werken
- Content professional
- Ready voor submit review

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "k2_steam: steam api integration (achievements, cloud saves)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 353
