# Prompt 369: Launch trailer + screenshots (via NOVA Storyboard + Renderer)

**Fase**: K_release  
**Sub**: k5_launch  
**Time estimate**: 4-6 uur

## Doel

Prepareer Launch trailer + screenshots (via NOVA Storyboard + Renderer).

## Context

Laatste stap voor release. Moet polished zijn, eerste indruk telt.

**Recente dependencies**: prompts 359, 360, 361, 362, 363, 364, 365, 366, 367, 368

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Asset generation via NOVA
2. Content writing
3. Timeline + logistics
4. Post-launch plan

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Materials professional
- Plan uitvoerbaar
- Contingencies voor launch day

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "k5_launch: launch trailer + screenshots (via nova storyboard + renderer)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 370
