# Prompt 362: Economy balance (prices, rewards)

**Fase**: K_release  
**Sub**: k3_balance  
**Time estimate**: 4-8 uur

## Doel

Uitvoeren Economy balance (prices, rewards).

## Context

Laatste balance pass voor release. Moet voelen niet frustrerend, niet te makkelijk.

**Recente dependencies**: prompts 352, 353, 354, 355, 356, 357, 358, 359, 360, 361

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Simulated playthroughs
2. Data collection + analysis
3. Tweaks waar nodig
4. Agent 10 Jury pass
5. Document wijzigingen

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Player metrics binnen target range
- Geen soft-lock situations
- Fun curve monoton

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "k3_balance: economy balance (prices, rewards)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 363
