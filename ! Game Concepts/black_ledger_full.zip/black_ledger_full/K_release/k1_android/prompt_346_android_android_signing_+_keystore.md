# Prompt 346: Android signing + keystore

**Fase**: K_release  
**Sub**: k1_android  
**Time estimate**: 3-5 uur

## Doel

Implementeer Android signing + keystore.

## Context

Android als secondary platform. Mobile-first designed zou te restrictief zijn, maar port is valuable.

**Recente dependencies**: prompts 336, 337, 338, 339, 340, 341, 342, 343, 344, 345

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Godot Android export setup
2. Code adjustments voor mobile
3. Asset variants waar nodig
4. Testing op device

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- APK installs clean
- Gameplay werkbaar op 6-inch screen
- 60fps op midrange Android
- No critical crashes

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "k1_android: android signing + keystore"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 347
