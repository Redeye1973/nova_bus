# Prompt 302: Audiocraft batch voor station music (8 tracks)

**Fase**: J_polish  
**Sub**: j2_music  
**Time estimate**: 2-5 uur

## Doel

Implementeer Audiocraft batch voor station music (8 tracks).

## Context

Music = soul of game. Tyrian 2000 had memorable Alexander Brandon score. Wij gaan AI maar met directing.

**Recente dependencies**: prompts 292, 293, 294, 295, 296, 297, 298, 299, 300, 301

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Audiocraft generation (Agent 29 of lokaal)
2. Music manager in Godot
3. Crossfade systeem
4. Contextual triggers
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Music fits scene
- Transitions smooth
- No jarring cuts

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "j2_music: audiocraft batch voor station music (8 tracks)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 303
