# J_polish - Polish + Rich Content

**Prompts**: 291-340  
**Duration**: 1-2 maanden  
**Scope**: Alles voelt alive: voice, music, news, endings, Drifter, canon.

## Key output

Voice acted, full OST, dynamic news, 3 endings, Drifter arc, canon-consistent

## Sub-fases

| Sub | Prompts | Beschrijving |
|-----|---------|--------------|
| j1_voice | 291-300 | ElevenLabs voice voor alle characters |
| j2_music | 301-310 | Audiocraft 28+ music tracks |
| j3_news | 311-318 | News ticker + dynamic events |
| j4_endings | 319-328 | 3 endings fully playable + cinematics |
| j5_drifter | 329-334 | The Drifter encounter arc |
| j6_canon | 335-340 | Canon final consistency pass |

## Prerequisite

- MVP compleet en speelbaar
- Vorige fasen in deze Full Build afgerond (indien van toepassing)
- NOVA v2 agents operationeel

## Workflow

1. Open sub directory (bv. `j1_voice/`)
2. Begin met laagst genummerde prompt
3. Cursor autonome build van prompt
4. Testen per acceptance criteria in prompt
5. Git commit
6. Volgende prompt

## Validation na afgeronde fase

Run:
```powershell
.\utils\validate_fase.ps1 -Fase J_polish
```

Controleert:
- Alle prompts gecommit
- Tests groen
- Geen regression vs MVP
- Canon consistency

## Milestones

Schrijf milestone file `docs/milestone_J_polish.md` na voltooiing met:
- Datum
- Prompts voltooid: X/Y
- Issues gevonden + fixes
- Volgende fase readiness

## Go to next fase criteria

**Go** als:
- 90%+ prompts voltooid zonder critical issues
- Playtest sessie bevestigt gameplay flow
- Geen regressions in MVP features

**Stop + fix** als:
- Performance degradation significant
- Critical bugs in core mechanics  
- Canon drift detected

