# Prompt 338: Character arc consistency

**Fase**: J_polish  
**Sub**: j6_canon  
**Time estimate**: 4-8 uur

## Doel

Uitvoeren Character arc consistency.

## Context

Laatste canon QA voor release. Kritiek voor Surilians shared universe consistency.

**Recente dependencies**: prompts 328, 329, 330, 331, 332, 333, 334, 335, 336, 337

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Scan alle in-game text
2. Jury pass per context
3. Fix inconsistencies
4. Update canon docs
5. Final sign-off

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Alle text Jury-approved
- Geen timeline paradoxes
- Geen karakterbreaks

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "j6_canon: character arc consistency"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 339
