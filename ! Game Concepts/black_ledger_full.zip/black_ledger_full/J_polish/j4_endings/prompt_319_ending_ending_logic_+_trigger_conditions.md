# Prompt 319: Ending logic + trigger conditions

**Fase**: J_polish  
**Sub**: j4_endings  
**Time estimate**: 4-6 uur

## Doel

Implementeer Ending logic + trigger conditions.

## Context

Ref: docs/CANON_COMPLETE.md - 3 endings zijn heart van Black Ledger narrative.

**Recente dependencies**: prompts 309, 310, 311, 312, 313, 314, 315, 316, 317, 318

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Branch logic
2. Cinematic scenes (storyboards via Agent 27)
3. Music + voice acted
4. Canon consistency Jury
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Alle 3 bereikbaar via save
- Cinematic rendering smooth
- Consequent met player choices

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "j4_endings: ending logic + trigger conditions"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 320
