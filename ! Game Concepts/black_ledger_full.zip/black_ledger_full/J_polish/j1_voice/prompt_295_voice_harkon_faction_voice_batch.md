# Prompt 295: Harkon faction voice batch

**Fase**: J_polish  
**Sub**: j1_voice  
**Time estimate**: 3-6 uur (ElevenLabs gen tijd)

## Doel

Implementeer Harkon faction voice batch.

## Context

Voice = huge credibility boost. ElevenLabs credits budget watchen via Cost Guard.

**Recente dependencies**: prompts 285, 286, 287, 288, 289, 290, 291, 292, 293, 294

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Script consolidation (alle lines per character)
2. ElevenLabs batch generation (Agent 29)
3. Audio Jury pass (Agent 03, 30)
4. In-game integration
5. Lip sync (if applicable)
6. Cost tracking check (Agent 16)

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Voice lines matching character
- Audio quality accept (Jury)
- Playback smooth ingame
- Cost binnen budget

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "j1_voice: harkon faction voice batch"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 296
