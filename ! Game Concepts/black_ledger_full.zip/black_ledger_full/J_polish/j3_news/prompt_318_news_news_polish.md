# Prompt 318: News polish

**Fase**: J_polish  
**Sub**: j3_news  
**Time estimate**: 2-3 uur

## Doel

Implementeer News polish.

## Context

Referentie MVP had NewsBroadcastSystem uit SpaceShooter. Nu uitbreiden tot live ticker.

**Recente dependencies**: prompts 308, 309, 310, 311, 312, 313, 314, 315, 316, 317

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Data model
2. Trigger logic
3. UI elements
4. Narrative Jury consultation (Agent 07)
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- News items genereren op events
- Fits canon
- Impact op economy visible

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "j3_news: news polish"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 319
