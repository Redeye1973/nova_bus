# Asset Production Tracker

Overzicht van ALLE assets die NOVA v2 pipeline moet produceren voor Full Build.

## Strategie

- **Parallel**: jij codeert in Cursor, NOVA produceert assets via 24/7 PC
- **Batch**: grote batches overnight (bv. 50 sprites tegelijk)
- **Prioriteit**: assets voor huidige fase eerst, volgende fase voorbereiden
- **Fallback**: placeholders uit Gekochte Assets voor prototyping, hi-fi later

## Per fase asset budget

### Fase F - Content (200-600 assets)

#### F1 Ships (~250 sprites)
- 12 ships × 4 damage states × 8 angles = 384 ship sprites  
- + faction paint variants = ~500 totaal
- **Producer**: Agent 21 FreeCAD → 22 Blender → 23 Aseprite
- **ETA**: 2-3 weken parallel

#### F2 Factions NPCs (~80 portraits)
- 6 factions × 8-15 NPCs = ~60-90 character portraits  
- + faction logos, banners = ~120 totaal
- **Producer**: Agent 27 Storyboard Visual + 08 Character Art Jury
- **ETA**: 1-2 weken

#### F3 Weapons (~60 icons + VFX)
- 15 weapons × 4 (icon + projectile + muzzle + impact) = 60+
- **Producer**: Agent 35 Raster 2D Processor
- **ETA**: 1 week

#### F4 Enemies (~350 sprites)
- 6 factions × 9 variants × 4 states × 8 angles (minus redundant) = ~350  
- **Producer**: Same als ships
- **ETA**: 3-4 weken parallel

#### F5 Stations (~50 backgrounds)
- 8 stations × 5 rooms = 40 interiors  
- + exterior shots = 50 totaal
- **Producer**: Agent 22 Blender Renderer + 33 Architecture
- **ETA**: 2 weken

#### F6 Levels (~200 level assets)
- 28 levels × background layers (3 parallax) + tilesets = ~200
- **Producer**: Agent 20 Design Fase + 22 Renderer
- **ETA**: 3-4 weken

**Fase F totaal: ~1200 visual assets + geluiden per actie**

### Fase G - Systems (~300 assets)

- 150 cargo item icons
- 50+ starmap icons, UI elements
- 20 datapad illustrations
- 30+ bounty target portraits
- 50+ economic graphs/visuals

**Fase G totaal: ~300 assets**

### Fase H - Procedural + Synthari (~500 assets)

- 10 biome base tilesets × 3 variations = 30 tilesets
- 8 Synthari ships × 4 × 8 = 256 sprites
- 30+ Synthari NPCs
- Boarding minigame sprites (corridors, guards)

### Fase I - Planetside (~400 assets)

- Rex Varn ground animations (walk, jump, shoot × 20+ frames)
- 20+ alien textures voor PDOK tiles
- 30+ planetside NPCs
- Environmental props (crates, doors, terminals)

### Fase J - Polish (~5000 audio files)

Dit is de grote batch:
- Voice: 500 lines × variations = 2000-5000 audio files
- Music: 28 tracks × 3 states = 84 music files
- SFX library: 200+ distinct sounds

### Fase K - Release (~50 assets)

- Marketing screenshots (20)
- Trailer clips (10 scenes)
- Store page graphics (10)
- Android icons/splash (10)

## Totaal

Naar verwachting: **2500-3500 visual assets** + **3000-5000 audio files**

Zonder NOVA pipeline: niet haalbaar solo. Met NOVA pipeline + 24/7 PC: 6-12 maanden gespreid.

## Asset tracking

Maak spreadsheet `assets_plan/asset_tracker.xlsx` met:

| Asset ID | Fase | Type | Description | Producer Agent | Status | Completion |
|----------|------|------|-------------|----------------|--------|------------|
| ship_razor_damage_0 | F1 | sprite | USP Razor undamaged | 21+22+23 | pending | 0% |
| ...|

Update wekelijks. NOVA Agent 19 Distribution kan dit scripten uit status calls.

## Prioritization

Prioriteit volgorde:
1. **Fase prerequisite** - assets die huidige prompt nodig heeft
2. **Next fase prep** - assets voor komende 2 weken
3. **Nice-to-have** - variations, alternatives

Bij capacity shortage: skip nice-to-haves, focus prerequisites.

## Quality gates

Elke asset passes Jury:
- Sprites: Agent 01
- 3D: Agent 04
- Audio: Agent 03 + 30
- 2D illustration: Agent 09

Fail rate target: < 5% reject. Als > 10% reject: iets mis met pipeline design, investigate.

## Backup strategie

Asset outputs in MinIO met versioning. Elke 48 uur sync naar local backup. Bij crash: restore from last sync. Rebuild from source indien nodig (Meshy cache lost etc).

## Cost tracking

Agent 16 Cost Guard monitor:
- ElevenLabs credits (voice)
- Meshy credits (reference 3D)
- Ollama compute (lokaal, stroom)
- Hetzner server (storage, bandwidth)

Maandelijks budget: €150-300 incl voice + music generatie. Als over: knijp Fase J voice scope.

## Asset locations

- **Generated**: MinIO bucket `black-ledger-assets/` op Hetzner
- **Final in game**: `L:\1 Nova Cursor Output\Dark Ledger\assets\` (Godot project)
- **Placeholders**: `L:\Nova Assets\Gekochte Assets\Pixel Art\`
- **References**: `L:\Nova Assets\references\`

## Automation

NOVA v2 automation:
1. Cursor prompt specifies nodig asset in taken
2. Script triggert Agent 12 Bake Orchestrator
3. Orchestrator dispatches relevant agent chain
4. Output lands in MinIO bucket
5. Sync script pulls into Godot project overnight
6. Jij ziet assets op volgende ochtend in Godot

Dit is de kern van NOVA waarde: jij bouwt logic, agents bouwen art.
