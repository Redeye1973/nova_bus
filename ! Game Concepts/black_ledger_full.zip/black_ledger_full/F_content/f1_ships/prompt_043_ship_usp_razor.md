# Prompt 043: Ship: USP Razor

**Fase**: F_content  
**Sub**: f1_ships  
**Time estimate**: 2-3 uur

## Doel

Implementeer USP Razor (interceptor klasse - high speed low armor) als bespelbaar/encounterable ship.

## Context

MVP: USP Talon basisklasse bestaat.
Eerdere ships in F1: geen.
Design ref: docs/SHIP_CATALOG.md voor archetype definities.
Canon ref: docs/CANON_COMPLETE.md voor faction ship aesthetics.

**Recente dependencies**: prompts 4, 10, 17, 18

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Genereer ship stats (HP, shield, speed, agility, cargo) gebalanceerd tegen USP Talon baseline
2. NOVA asset pipeline: FreeCAD → Blender → Aseprite voor ship sprite (4 damage states × 8 angles)
3. Maak `scripts/ships/usp_razor.gd` class die van BaseShip erft
4. Component mount points: weapons, engines, cargo config volgens USP Razor archetype
5. Balance-gecheck door Agent 10 Game Balance Jury
6. Toevoegen aan ship database in `resources/ship_database.tres`

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Ship spawnt correct in Godot scene
- Alle stats werken zoals gespecificeerd
- Sprite sheet loadt zonder errors
- Balance Jury verdict: accept (acceptabel binnen tolerance van baseline)
- Animation states (idle/hit/destroyed) werken

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "f1_ships: ship: usp razor"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 44
