# Prompt 057: Ship acquisition system

**Fase**: F_content  
**Sub**: f1_ships  
**Time estimate**: 2-3 uur

## Doel

shop + mission reward + capture

## Context

Ship prompts 43-54 voltooid. Nu systemen voor ship management.

**Recente dependencies**: prompts 51, 52, 53, 54, 55, 56, 4, 10, 17, 18

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Implementeer core systeem volgens naam
2. Integreer met bestaande ships uit prompts 43-54
3. UI/UX waar relevant
4. Save/load ondersteuning
5. Test cases

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Functionaliteit werkt zoals beschreven
- Integreert met MVP save/load
- Geen regressions in MVP features

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "f1_ships: ship acquisition system"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 58
