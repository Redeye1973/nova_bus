# Prompt 072: Faction-cross missions

**Fase**: F_content  
**Sub**: f2_factions  
**Time estimate**: 3-4 uur

## Doel

missies die 2+ factions raken

## Context

MVP heeft basic reputation voor Harkon + Marshal. Nu uitbreiden naar alle 6 factions met deep mechanics.

**Recente dependencies**: prompts 65, 66, 67, 68, 69, 70, 71, 7, 17, 39

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Implementeer faction systeem voor Faction-cross missions
2. Canon-conforme dialoog lines (via Agent 07 Narrative Jury)
3. Reputation effects op gameplay
4. NPC sprites + portraits via NOVA pipeline
5. Integreren met bestaande reputation uit MVP prompt 39
6. Documentatie update in CANON_COMPLETE.md

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- NPCs spawnen en acteren volgens faction behavior
- Reputation verandert correct bij player actions
- Dialoog lines zijn canon-conform (Narrative Jury accept)
- Geen conflict met bestaande factions

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "f2_factions: faction-cross missions"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 73
