# Prompt 105: Level 2 - Korrigan Asteroid Belt

**Fase**: F_content  
**Sub**: f6_levels  
**Time estimate**: 3-5 uur

## Doel

Bouw Level 2 - Korrigan Asteroid Belt als speelbaar level.

## Context

MVP heeft level 1 (Korrigan-3 escape) + boss. Nu 27 extra levels volgens narrative arc.

**Recente dependencies**: prompts 98, 99, 100, 101, 102, 103, 104, 19, 20, 21

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Level design (wave patterns, spawn points, boss placement)
2. Background art (parallax layers) via NOVA pipeline
3. Music track via Audiocraft (Agent 29)
4. Level-specific events (dialog, cutscenes)
5. Balance tuning (difficulty curve)
6. Save point + checkpoint system

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Level speelbaar start-to-finish
- Difficulty voelt progressief (niet plotse spike)
- Story events triggeren correct
- Geen performance issues

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "f6_levels: level 2 - korrigan asteroid belt"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 106
