# Prompt 082: Weapon shop + crafting UI

**Fase**: F_content  
**Sub**: f3_weapons  
**Time estimate**: 2-3 uur

## Doel

Implementeer Weapon shop + crafting UI met balance, VFX en audio.

## Context

MVP heeft 3 weapons (pulse, missile, EMP). Nu systeem uitbreiden naar 15 totaal.

**Recente dependencies**: prompts 78, 79, 80, 81, 11, 12, 13, 14, 18, 35

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Stats definitie (damage, fire rate, energy cost, range)
2. Projectile of effect scene
3. VFX (muzzle flash, impact, trail)
4. Audio (fire, impact, reload)
5. Balance-check door Agent 10
6. Toevoegen aan weapon database

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Weapon fires + damages correct
- VFX + audio sync
- Niet overpowered vs MVP baseline
- Shop kan weapon verkopen + buyen

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "f3_weapons: weapon shop + crafting ui"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 83
