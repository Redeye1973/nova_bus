# Prompt 085: Marshal enforcement roster

**Fase**: F_content  
**Sub**: f4_enemies  
**Time estimate**: 4-6 uur

## Doel

Patrol, Investigator, Pursuer, Heavy, Warden, Captain, K9, Mech, Drone

## Context

MVP heeft rookie + veteran enemies generic. Nu faction-specific rosters.

**Recente dependencies**: prompts 79, 80, 81, 82, 83, 84, 14, 15, 16, 17

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Sprite generation via NOVA pipeline (Design Fase + FreeCAD + Blender + Aseprite)
2. GDScript AI per variant in `scripts/enemies/<faction>/`
3. Balance table per variant (HP, DPS, reward)
4. Animation states compleet
5. Audio hooks
6. Database update

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Alle 9 variants spawnen correct
- AI behavior verschilt per variant
- Sprite quality via Agent 01 Sprite Jury accept
- Balance binnen tolerance (Agent 10 accept)

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "f4_enemies: marshal enforcement roster"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 86
