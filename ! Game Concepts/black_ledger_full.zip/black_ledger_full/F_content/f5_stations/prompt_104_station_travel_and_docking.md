# Prompt 104: Station travel + docking

**Fase**: F_content  
**Sub**: f5_stations  
**Time estimate**: 3-4 uur

## Doel

Implementeer Station travel + docking als volledig ingame locatie.

## Context

MVP heeft Korrigan-3 station. Nu 7 extra stations + services framework.

**Recente dependencies**: prompts 98, 99, 100, 101, 102, 103, 28, 29, 30, 31

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Station interior background art
2. Services layout (shop, mission board, character interaction)
3. Unique NPCs per station
4. Docking sequence
5. Travel integratie met starmap (F61+ G1 prep)
6. Save/load station-specific state

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Station loadt + rendert correct
- Services werken (shop + mission board + NPCs)
- Docking/undocking smooth
- State persists na quit/load

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "f5_stations: station travel + docking"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 105
