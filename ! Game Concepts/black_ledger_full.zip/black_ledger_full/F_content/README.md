# F_content - Content Expansion

**Prompts**: 43-120  
**Duration**: 2-4 maanden  
**Scope**: Alle content breedte: ships, factions, weapons, enemies, stations, levels.

## Key output

28 levels compleet, 12 ships, 6 factions met NPCs, 15 weapons, 54 enemy variants, 8 stations

## Sub-fases

| Sub | Prompts | Beschrijving |
|-----|---------|--------------|
| f1_ships | 43-58 | Ship catalog expansion naar 12 ships + variants |
| f2_factions | 59-72 | Alle 6 factions fully interactive met NPCs en reputation |
| f3_weapons | 73-82 | 15 weapon types + mod systeem |
| f4_enemies | 83-94 | 6 factions × 9 enemy variants = 54 enemy types |
| f5_stations | 95-104 | 7 extra stations + services framework |
| f6_levels | 105-120 | Alle 28 levels van Korrigan-3 tot Finale |

## Prerequisite

- MVP compleet en speelbaar
- Vorige fasen in deze Full Build afgerond (indien van toepassing)
- NOVA v2 agents operationeel

## Workflow

1. Open sub directory (bv. `f1_ships/`)
2. Begin met laagst genummerde prompt
3. Cursor autonome build van prompt
4. Testen per acceptance criteria in prompt
5. Git commit
6. Volgende prompt

## Validation na afgeronde fase

Run:
```powershell
.\utils\validate_fase.ps1 -Fase F_content
```

Controleert:
- Alle prompts gecommit
- Tests groen
- Geen regression vs MVP
- Canon consistency

## Milestones

Schrijf milestone file `docs/milestone_F_content.md` na voltooiing met:
- Datum
- Prompts voltooid: X/Y
- Issues gevonden + fixes
- Volgende fase readiness

## Go to next fase criteria

**Go** als:
- 90%+ prompts voltooid zonder critical issues
- Playtest sessie bevestigt gameplay flow
- Geen regressions in MVP features

**Stop + fix** als:
- Performance degradation significant
- Critical bugs in core mechanics  
- Canon drift detected

