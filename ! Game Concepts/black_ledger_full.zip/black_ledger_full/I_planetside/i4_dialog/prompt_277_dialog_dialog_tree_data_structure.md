# Prompt 277: Dialog tree data structure

**Fase**: I_planetside  
**Sub**: i4_dialog  
**Time estimate**: 2-3 uur

## Doel

Implementeer Dialog tree data structure.

## Context

Dialog crucial voor narrative delivery. Moet voelen als echte keuzes.

**Recente dependencies**: prompts 267, 268, 269, 270, 271, 272, 273, 274, 275, 276

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Data structure
2. UI component
3. Integration met rep/inventory
4. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Branches correct
- UI responsive
- Localization-ready

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "i4_dialog: dialog tree data structure"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 278
