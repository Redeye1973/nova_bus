# I_planetside - Planetside

**Prompts**: 241-290  
**Duration**: 2-3 maanden  
**Scope**: Blackthorne-style side-view shooter segmenten met GIS-based terrain.

## Key output

Planetside mode werkend, PDOK Hoogeveen als alien werelden, NPCs + dialog

## Sub-fases

| Sub | Prompts | Beschrijving |
|-----|---------|--------------|
| i1_core | 241-256 | Blackthorne-style core (platforming shooter) |
| i2_pdok_alien | 257-268 | PDOK 3D tiles + alien textures |
| i3_npcs | 269-276 | Planetside NPCs met schedules |
| i4_dialog | 277-284 | Dialog tree met branching |
| i5_missions | 285-290 | Ground mission types |

## Prerequisite

- MVP compleet en speelbaar
- Vorige fasen in deze Full Build afgerond (indien van toepassing)
- NOVA v2 agents operationeel

## Workflow

1. Open sub directory (bv. `i1_core/`)
2. Begin met laagst genummerde prompt
3. Cursor autonome build van prompt
4. Testen per acceptance criteria in prompt
5. Git commit
6. Volgende prompt

## Validation na afgeronde fase

Run:
```powershell
.\utils\validate_fase.ps1 -Fase I_planetside
```

Controleert:
- Alle prompts gecommit
- Tests groen
- Geen regression vs MVP
- Canon consistency

## Milestones

Schrijf milestone file `docs/milestone_I_planetside.md` na voltooiing met:
- Datum
- Prompts voltooid: X/Y
- Issues gevonden + fixes
- Volgende fase readiness

## Go to next fase criteria

**Go** als:
- 90%+ prompts voltooid zonder critical issues
- Playtest sessie bevestigt gameplay flow
- Geen regressions in MVP features

**Stop + fix** als:
- Performance degradation significant
- Critical bugs in core mechanics  
- Canon drift detected

