# Prompt 285: Ground mission types (assassination, retrieval, escort, defend, sabotage, rescue)

**Fase**: I_planetside  
**Sub**: i5_missions  
**Time estimate**: 3-4 uur

## Doel

Implementeer Ground mission types (assassination, retrieval, escort, defend, sabotage, rescue).

## Context

Planetside missions geven variatie tov space-only gameplay.

**Recente dependencies**: prompts 275, 276, 277, 278, 279, 280, 281, 282, 283, 284

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Mission data + triggers
2. Content per missie (5+ per type)
3. Balance + rewards
4. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Alle mission types werken
- Balanced rewards
- Narrative fits canon

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "i5_missions: ground mission types (assassination, retrieval, escort, defend, sabotage, rescue)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 286
