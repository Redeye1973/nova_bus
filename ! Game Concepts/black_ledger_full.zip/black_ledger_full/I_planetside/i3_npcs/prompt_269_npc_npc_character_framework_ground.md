# Prompt 269: NPC character framework (ground)

**Fase**: I_planetside  
**Sub**: i3_npcs  
**Time estimate**: 2-3 uur

## Doel

Implementeer NPC character framework (ground).

## Context

NPCs op planetside geven game levend gevoel. Elk NPC kan quest giver, shop, of gewoon flavor zijn.

**Recente dependencies**: prompts 259, 260, 261, 262, 263, 264, 265, 266, 267, 268

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Character class + behaviors
2. Assets via NOVA (Agent 27 Storyboard Visual + 08 Character Art)
3. Dialog hooks
4. Quest integration
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- NPCs acteren volgens schedule
- Dialog flow correct
- Quest handover werkt

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "i3_npcs: npc character framework (ground)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 270
