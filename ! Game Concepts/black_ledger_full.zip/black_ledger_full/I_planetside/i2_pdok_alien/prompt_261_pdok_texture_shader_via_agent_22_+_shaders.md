# Prompt 261: Texture shader (via Agent 22 + shaders)

**Fase**: I_planetside  
**Sub**: i2_pdok_alien  
**Time estimate**: 3-5 uur

## Doel

Implementeer Texture shader (via Agent 22 + shaders) voor PDOK alien textures.

## Context

Unique selling point: real Hoogeveen + buildings geotransformed als alien werelden. PDOK → mesh → alien retexture.

**Recente dependencies**: prompts 251, 252, 253, 254, 255, 256, 257, 258, 259, 260

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. NOVA pipeline integration (Agent 13 PDOK + 14 Baker + 22 Blender)
2. Shader setup
3. Asset batch per location
4. Godot runtime integration
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Real locations recognizable in silhouette
- Alien overlay overtuigend
- Performance OK op midrange
- Streaming zonder loading screens

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "i2_pdok_alien: texture shader (via agent 22 + shaders)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 262
