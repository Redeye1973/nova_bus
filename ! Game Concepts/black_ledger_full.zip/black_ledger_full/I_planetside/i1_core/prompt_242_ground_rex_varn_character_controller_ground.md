# Prompt 242: Rex Varn character controller (ground)

**Fase**: I_planetside  
**Sub**: i1_core  
**Time estimate**: 3-5 uur

## Doel

Implementeer Rex Varn character controller (ground) voor planetside mode.

## Context

Blackthorne-inspired side-view shooter. Rex Varn landt op planeten voor specifieke missies.

**Recente dependencies**: prompts 232, 233, 234, 235, 236, 237, 238, 239, 240, 241

## Project locatie

`L:\1 Nova Cursor Output\Dark Ledger\`

## Taken

1. Scene + node setup
2. GDScript mechanics
3. Asset hooks via NOVA pipeline
4. Integratie met main game flow
5. Testing

## NOVA agents om aan te roepen

Waar relevant, gebruik deze agents via webhooks:
- Agent 01 Sprite Jury voor sprite QA
- Agent 02 Code Jury voor GDScript review  
- Agent 07 Narrative Jury voor canon consistency
- Agent 10 Balance Jury voor stats review
- Agent 17 Error Agent als iets misgaat

Check `L:\!Nova V2\status\` voor actieve agents.

## Canon references

- `docs/CANON_COMPLETE.md` - master canon Black Ledger
- `docs/SHIP_CATALOG.md` - ships
- `docs/FACTION_GUIDE.md` - factions
- `docs/SYNTHARI_LORE.md` - Synthari race  
- `docs/STARMAP_DESIGN.md` - starmap
- `docs/DATAPAD_SYSTEM.md` - datapad
- `docs/BIOME_GENERATOR.md` - procedural biomes
- `docs/MEGALODON_SPEC.md` - originele mega spec

## Testing criteria

- Controls responsive
- Animation sync
- AI challenging but fair
- Transition space ↔ ground smooth

## Git

Na succes:
```
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "i1_core: rex varn character controller (ground)"
```

## Troubleshooting

Als deze prompt faalt:
1. Check NOVA agents status (`.\utils\status_check.ps1`)
2. Check vorige prompt in zelfde sub is compleet
3. Rollback met `git reset --hard HEAD~1` indien nodig
4. Consult `docs/DEBUGGING_GUIDE.md` uit NOVA v2 package

## Volgende prompt

Prompt 243
