# START HIER - Black Ledger MVP Build

## Voordat je begint

### Voorwaarden check

```powershell
# 1. NOVA v2 Pipeline klaar?
$statuses = Get-ChildItem "L:\!Nova V2\status\agent_*_status.json"
$activeCount = ($statuses | ForEach-Object { (Get-Content $_.FullName | ConvertFrom-Json) } | Where-Object { $_.status -eq "active" -or $_.status -eq "active" -and $_.fallback_mode }).Count
Write-Host "Active agents: $activeCount"

# Verwacht: minimaal 20/33 agents active

# 2. Godot 4.6.2 beschikbaar?
& "C:\Program Files\Godot\godot.exe" --version 2>&1 | Select-Object -First 1
# Of waar je Godot ook hebt

# 3. Black Ledger canon beschikbaar?
Test-Path "L:\!Nova V2\canon\BLACK_LEDGER_STORY_BIBLE.md"
Test-Path "L:\!Nova V2\canon\BLACK_LEDGER_SYNTHARI_LORE.md"

# 4. Git repo klaar?
cd "L:\1 Nova Cursor Output\Dark Ledger"
git status
# Als niet: git init
```

### Setup canon files (als nog niet)

```powershell
# Maak canon directory
$canonDir = "L:\!Nova V2\canon"
New-Item -ItemType Directory -Force -Path $canonDir | Out-Null

# Kopieer canon uit Black Ledger ideas (aanname: je hebt deze files ergens)
# Als nog niet aanwezig, vraag Claude ze opnieuw te genereren uit eerdere sessie

# Verify
Get-ChildItem $canonDir
```

## Stap 1: Backup huidige staat

```powershell
# Full NOVA v2 backup eerst
cd "L:\!Nova V2"
.\nova_v2_pipeline_build\utils\full_backup.ps1 -IncludePostgres

# Backup Dark Ledger project als het al bestaat
if (Test-Path "L:\1 Nova Cursor Output\Dark Ledger") {
    $backup = "L:\!Nova V2\backups\dark_ledger_pre_mvp_$(Get-Date -Format 'yyyy-MM-dd')"
    Copy-Item "L:\1 Nova Cursor Output\Dark Ledger\" $backup -Recurse -Force
    Write-Host "Dark Ledger backup: $backup"
}
```

## Stap 2: Project locatie verifiëren

```powershell
# Target project path
$projectPath = "L:\1 Nova Cursor Output\Dark Ledger"

# Als folder niet bestaat, maak aan
if (-not (Test-Path $projectPath)) {
    New-Item -ItemType Directory -Force -Path $projectPath | Out-Null
    cd $projectPath
    git init
    Write-Host "Fresh Dark Ledger project created"
} else {
    cd $projectPath
    git status
    Write-Host "Existing Dark Ledger project found"
}
```

## Stap 3: Pipeline job definities klaarzetten

Deze file vertelt NOVA v2 agents wat te genereren tijdens build:

```powershell
# Kopieer asset plan naar project
Copy-Item ".\assets_plan\pipeline_jobs.json" "$projectPath\.nova_pipeline_jobs.json"
```

## Stap 4: Design document lezen

Open en lees:
- `00_master/GAME_DESIGN_MVP.md` - volledige design voor MVP
- `00_master/SCOPE_DEFINITION.md` - wat WEL, wat NIET
- `docs/BLACK_LEDGER_CANON.md` - compacte lore reference

Dit is belangrijk - je wilt begrijpen wat je bouwt voordat Cursor begint.

## Stap 5: Directory structuur voorbereiden

```powershell
$projectPath = "L:\1 Nova Cursor Output\Dark Ledger"
$dirs = @(
    "scripts/core",
    "scripts/player",
    "scripts/enemies",
    "scripts/weapons",
    "scripts/ui",
    "scripts/levels",
    "scripts/missions",
    "scripts/station",
    "scripts/managers",
    "scripts/resources",
    "scenes/player",
    "scenes/enemies",
    "scenes/levels",
    "scenes/station",
    "scenes/ui",
    "scenes/effects",
    "resources/ship_data",
    "resources/weapon_data",
    "resources/mission_data",
    "resources/enemy_data",
    "assets/sprites/player",
    "assets/sprites/enemies",
    "assets/sprites/projectiles",
    "assets/sprites/effects",
    "assets/sprites/ui",
    "assets/audio/music",
    "assets/audio/sfx",
    "assets/audio/voice",
    "assets/fonts",
    "save_data",
    "docs"
)

foreach ($d in $dirs) {
    New-Item -ItemType Directory -Force -Path "$projectPath\$d" | Out-Null
}

Write-Host "Directory structuur klaar"
```

## Stap 6: Eerste prompt klaar maken

Open het volgende bestand voor je eerste Cursor prompt:

```
01_foundation/prompt_01_godot_project_setup.md
```

## Werkwijze per prompt

1. **Lees de prompt file** volledig door
2. **Check voorwaarden** aan de top
3. **Kopieer prompt blok** (tussen ``` markers)
4. **Plak in Cursor Composer** (Ctrl+I)
5. **Laat Cursor werken**
6. **Monitor voortgang**:
   ```powershell
   Get-Content "L:\1 Nova Cursor Output\Dark Ledger\docs\build_log_$(Get-Date -Format 'yyyy-MM-dd').md" -Wait
   ```
7. **Test in Godot**:
   - Open project in Godot editor
   - Run relevante scene
   - Verify werkt
8. **Git commit**:
   ```powershell
   cd "L:\1 Nova Cursor Output\Dark Ledger"
   git add .
   git commit -m "feat: [wat gebouwd in deze prompt]"
   ```
9. **Naar volgende prompt**

## Tussenstops

**Per 5 prompts**: doe een quick playtest
- Open project in Godot
- Run main scene
- Test wat je hebt
- Note bugs in `docs/known_issues.md`

**Per fase**: grondige playtest
- Speel van begin tot relevante punt
- Test alle nieuwe systemen
- Schrijf `docs/playtest_notes_fase_X.md`

**Na 42 prompts**: alpha playtest
- Windows build exporteren
- Installeer + test vanuit user perspective
- 3+ complete playthroughs

## Bij problemen

**Cursor loop**: open nieuwe Composer, zeg "resume vanaf laatste commit"

**Godot error**: check Output panel, googlen, of vraag Claude in nieuwe sessie

**NOVA agent faalt**: 
- Check agent status
- Reset en retry
- Of skip pipeline output, gebruik placeholder assets
- MVP werkt met placeholders, refinement kan later

**Scope creep**: kijk naar `SCOPE_DEFINITION.md` - als feature niet daar staat, NIET bouwen

## Tracking

Houd bij:
- Prompt afgerond? Vink af in `PROMPT_INDEX.md`
- Bug gevonden? Log in `docs/known_issues.md`
- Feature werkt? Test in dagelijkse playtest
- Commit regelmatig

## Ready?

Als stappen 1-5 groen zijn: open `01_foundation/prompt_01_godot_project_setup.md` en begin.

Geschatte totale tijd: 42 prompts × 3u = 126 uur Cursor werk
Met 24/7 PC + 2-3u dagelijkse test/debug: **6-8 weken voor werkend MVP**
