# Black Ledger MVP - Prompt Index

42 sequentiele prompts in 6 fases.

## Fase 1 Foundation (8 prompts)

| # | Naam | File | Est. tijd |
|---|------|------|-----------|
| 01 | Godot Project Setup | `01_foundation/prompt_01_godot_project_setup.md` | 1-2u |
| 02 | Core Singletons | `01_foundation/prompt_02_core_singletons.md` | 2-3u |
| 03 | Resource Classes | `01_foundation/prompt_03_resource_classes.md` | 2-3u |
| 04 | Ship Component System | `01_foundation/prompt_04_ship_component_system.md` | 3-4u |
| 05 | GameConstants + Enums | `01_foundation/prompt_05_game_constants.md` | 1-2u |
| 06 | Asset Pipeline Setup | `01_foundation/prompt_06_asset_pipeline.md` | 2-3u |
| 07 | Save/Load System | `01_foundation/prompt_07_save_load_system.md` | 3-4u |
| 08 | Settings + Config | `01_foundation/prompt_08_settings_config.md` | 2-3u |

**Subtotaal: 16-24 uur**

## Fase 2 Core Gameplay (10 prompts)

| # | Naam | File | Est. tijd |
|---|------|------|-----------|
| 09 | Player Ship Controller | `02_core_gameplay/prompt_09_player_controller.md` | 3-4u |
| 10 | HealthComponent + Shield | `02_core_gameplay/prompt_10_health_shield.md` | 2-3u |
| 11 | Weapon Base System | `02_core_gameplay/prompt_11_weapon_system.md` | 3-4u |
| 12 | Pulse Cannon | `02_core_gameplay/prompt_12_pulse_cannon.md` | 2u |
| 13 | Missile Launcher | `02_core_gameplay/prompt_13_missile_launcher.md` | 2-3u |
| 14 | EMP Device | `02_core_gameplay/prompt_14_emp_device.md` | 2-3u |
| 15 | Enemy AI Rookie | `02_core_gameplay/prompt_15_enemy_ai_rookie.md` | 3-4u |
| 16 | Enemy AI Veteran | `02_core_gameplay/prompt_16_enemy_ai_veteran.md` | 2-3u |
| 17 | Score + Streak Manager | `02_core_gameplay/prompt_17_score_manager.md` | 2u |
| 18 | VFX + Audio Manager | `02_core_gameplay/prompt_18_vfx_audio.md` | 3-4u |

**Subtotaal: 24-31 uur**

## Fase 3 First Level (8 prompts)

| # | Naam | File | Est. tijd |
|---|------|------|-----------|
| 19 | Level Scene Base | `03_first_level/prompt_19_level_scene.md` | 2-3u |
| 20 | Parallax Background | `03_first_level/prompt_20_parallax.md` | 2u |
| 21 | Wave Manager | `03_first_level/prompt_21_wave_manager.md` | 3u |
| 22 | Enemy Spawning | `03_first_level/prompt_22_enemy_spawning.md` | 2-3u |
| 23 | Power-ups | `03_first_level/prompt_23_powerups.md` | 2-3u |
| 24 | Boss: Helios Enforcer | `03_first_level/prompt_24_boss_enforcer.md` | 4-6u |
| 25 | Level 1 Korrigan Escape | `03_first_level/prompt_25_level1_korrigan.md` | 3-4u |
| 26 | Level Transitions | `03_first_level/prompt_26_level_transitions.md` | 2-3u |

**Subtotaal: 20-28 uur**

## Fase 4 Station Hub (6 prompts)

| # | Naam | File | Est. tijd |
|---|------|------|-----------|
| 27 | Station Scene Base | `04_station_hub/prompt_27_station_scene.md` | 2-3u |
| 28 | Station UI Framework | `04_station_hub/prompt_28_station_ui.md` | 3-4u |
| 29 | Shop System | `04_station_hub/prompt_29_shop_system.md` | 3-4u |
| 30 | Character Creation | `04_station_hub/prompt_30_character_creation.md` | 2-3u |
| 31 | Main Menu | `04_station_hub/prompt_31_main_menu.md` | 2-3u |
| 32 | Save Slots UI | `04_station_hub/prompt_32_save_slots.md` | 2-3u |

**Subtotaal: 14-20 uur**

## Fase 5 Missions (6 prompts)

| # | Naam | File | Est. tijd |
|---|------|------|-----------|
| 33 | Mission Data Structure | `05_missions/prompt_33_mission_data.md` | 2u |
| 34 | Mission Briefing UI | `05_missions/prompt_34_mission_briefing.md` | 3-4u |
| 35 | Bounty Board | `05_missions/prompt_35_bounty_board.md` | 3u |
| 36 | Mission 1 Clean Sweep | `05_missions/prompt_36_mission1.md` | 2-3u |
| 37 | Mission 2 Cargo Run | `05_missions/prompt_37_mission2.md` | 3-4u |
| 38 | Mission 3 Bounty Voss | `05_missions/prompt_38_mission3.md` | 3-4u |

**Subtotaal: 16-20 uur**

## Fase 6 Integration (4 prompts)

| # | Naam | File | Est. tijd |
|---|------|------|-----------|
| 39 | Reputation System | `06_integration/prompt_39_reputation.md` | 2-3u |
| 40 | Ending Teaser Cutscene | `06_integration/prompt_40_ending_teaser.md` | 3-4u |
| 41 | Balance Pass | `06_integration/prompt_41_balance_pass.md` | 4-6u |
| 42 | Windows Build + Polish | `06_integration/prompt_42_build_polish.md` | 4-6u |

**Subtotaal: 13-19 uur**

## Totaal

**Alle 42 prompts**: 103-142 uur Cursor werk

Met 24/7 PC: 5-7 weken doorlopend
Met 8u/dag: 12-18 weken

## Voortgang tracking

Vink af zodra klaar:

Fase 1: [ ] 01 [ ] 02 [ ] 03 [ ] 04 [ ] 05 [ ] 06 [ ] 07 [ ] 08
Fase 2: [ ] 09 [ ] 10 [ ] 11 [ ] 12 [ ] 13 [ ] 14 [ ] 15 [ ] 16 [ ] 17 [ ] 18
Fase 3: [ ] 19 [ ] 20 [ ] 21 [ ] 22 [ ] 23 [ ] 24 [ ] 25 [ ] 26
Fase 4: [ ] 27 [ ] 28 [ ] 29 [ ] 30 [ ] 31 [ ] 32
Fase 5: [ ] 33 [ ] 34 [ ] 35 [ ] 36 [ ] 37 [ ] 38
Fase 6: [ ] 39 [ ] 40 [ ] 41 [ ] 42

## Na MVP

Als alle 42 prompts klaar en playtests goed gaan:
- git tag v1.0.0-mvp
- Open Full Build package
- Ga door met prompt 43 (= Full Build prompt 1)
