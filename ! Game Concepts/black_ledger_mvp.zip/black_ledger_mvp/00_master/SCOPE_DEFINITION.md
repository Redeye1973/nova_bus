# MVP Scope Definition - WEL vs NIET

Ter voorkoming van scope creep. Als iets niet op de WEL-lijst staat, bouw het niet in MVP.

## IN SCOPE (MVP = v1.0)

### Core gameplay
- Top-down 2D space shooter combat
- 1 speelbaar ship (USP Talon)
- 3 wapentypes (Pulse Cannon, Missiles, EMP)
- Shield + Armor damage model
- Enemy waves (2 waves + boss per level)
- Score + credits systeem
- 60 FPS target

### Content
- 1 speelbare level (Korrigan-3 escape)
- 1 boss (Helios Enforcer)
- 1 station (Outer Rim Outpost)
- 3 missies (eliminate, escort, bounty hunt)
- 2 facties interactief (Harkon, Marshal Authority)
- 4 ander facties zichtbaar maar statisch op rep 0

### UI
- Main menu met save/load
- Settings (volume, controls)
- HUD tijdens gameplay
- Mission briefing scherm
- Station hub UI
- Winkel UI
- Bounty board UI
- Character creation (alleen Man versie)

### Progression
- 3 missies completable
- Ship upgrades (3 items in winkel)
- Weapon upgrades (Pulse Cannon 3 levels)
- Reputation changes (Harkon en MA)
- Ending teaser (cliffhanger naar full game)

### Technical
- Save/load systeem (3 slots, JSON)
- Settings persistence
- Windows build export
- Under 500MB file size

## UIT SCOPE (komt in Full Build)

### Extra gameplay
- NIET: Cargo system
- NIET: Cargo scan enforcement
- NIET: Starmap met multiple sectors
- NIET: Wormholes + jumpholes
- NIET: Ejection + boarding minigame
- NIET: Ship capture
- NIET: Tractor beam + loot systeem
- NIET: Planetside/Blackthorne mode (GIS)
- NIET: Procedural biomes

### Extra content
- NIET: 27 andere levels (2 t/m 28)
- NIET: Andere 8 ships (Harkon Blade, Helios Excavator, etc)
- NIET: 9 weapon types (alleen 3 in MVP)
- NIET: 6 factions interactief
- NIET: Datacubes collectie
- NIET: Secret levels
- NIET: Remnant Lance
- NIET: Synthari race speelbaar
- NIET: Vrouw versie speelbaar (Rexa)

### Extra systemen
- NIET: Datapad ledger book volledig
- NIET: Cross-reference engine
- NIET: Bounty hunter simulation
- NIET: Revenge storyline complete
- NIET: The Drifter verschijningen
- NIET: 3 endings (Clean Slate / New Ledger / Ghosted)
- NIET: News ticker dynamic events
- NIET: Story continuity checks

### Extra UI
- NIET: Complete starmap UI
- NIET: Datapad viewer UI
- NIET: Cross-reference UI
- NIET: Hangar met multiple ships
- NIET: Cargo configuration UI
- NIET: Advanced bounty filters

### Audio
- NIET: Volledige voice acting met ElevenLabs
- NIET: Music generation via Audiocraft (placeholders eerst)
- NIET: 28 level-specifieke music tracks

### Technical
- NIET: Android APK build
- NIET: Steam integration
- NIET: Achievement systeem
- NIET: Multiplayer (niet ooit)
- NIET: Cloud saves

## Gray area - beslis bewust

Als je deze dingen WILT toevoegen, bewust beslissen:

### Modulair ship component systeem

**MVP minimum**: Eén USP Talon als enkel sprite.
**Optie**: Basis modulair systeem NU bouwen = 8-12 extra uur werk
**Voordeel**: Makkelijker uitbouwen later
**Nadeel**: Scope uitbreiding

**Advies**: Bouw basic infrastructure in MVP (ShipComponent resource class), maar slechts 1 implementatie (USP Talon). Later varianten toevoegen is makkelijk.

### Meshy integration

**MVP minimum**: Gekochte pixel art packs als placeholder
**Optie**: NOVA pipeline productie-ready voor custom art
**Voordeel**: Unique art style in MVP
**Nadeel**: Tijd + 1000 credits opgebruikt

**Advies**: Gebruik NOVA pipeline voor NPC portraits (1-2 per Faction) en Rex Varn portrait. Rest met placeholders.

### Blender 3D → sprite renders

**MVP minimum**: 2D pixel art direct
**Optie**: FreeCAD + Blender pipeline voor custom ships
**Voordeel**: Modulair ships systeem functional
**Nadeel**: Complex, traag

**Advies**: Pipeline infrastructure bouwen (past in MVP), maar gebruik het alleen voor 1 ship (USP Talon). Meer ships = full build.

### ElevenLabs voice acting

**MVP minimum**: Text-only dialog
**Optie**: Voice acting voor Rex Varn narrator + 2-3 NPCs
**Voordeel**: Enorm veel immersie
**Nadeel**: Credits kosten, integratie werk

**Advies**: MVP tekst only. Voice komt in Full Build omdat je nog balansjes wilt tweaken eerst.

## Red flags - STOP en review

Als je deze dingen ooit wilt toevoegen tijdens MVP build: STOP, overweeg, kies.

1. **"Ik wil ook even deze faction interactief maken"** → NEE, in full build
2. **"Laat me de starmap ook implementeren"** → NEE, in full build
3. **"Misschien moet ik Synthari race toevoegen"** → NEE, in full build
4. **"Waarom niet alle 28 levels nu?"** → NEE, je brand uit voor je klaar bent

MVP is GENOEG om te testen of je concept werkt. Alles daarna is content.

## Cutoff test

Als Cursor prompt zegt "add this feature", stel jezelf:

1. Staat het expliciet in "IN SCOPE" hierboven?
2. Is het nodig voor 30-min playable experience?
3. Zou weglating de loop breken?

Als 1 van deze niet "ja" is: SKIP het.

## Wanneer MVP klaar is

**Definition of Done voor MVP v1.0:**

- [ ] Main menu → Intro → Char create → Level 1 → Boss → Station → Missie 1 → Debrief → Missie 2 → Debrief → Missie 3 → Debrief → Ending teaser
- [ ] Save/load werkt tussen sessies
- [ ] Alle systemen uit "IN SCOPE" werken
- [ ] Geen crashes in full playthrough
- [ ] Windows build exporteert onder 500MB
- [ ] 5 interne playthroughs zonder major bugs

Bij klaar: git tag v1.0.0-mvp, open Full Build package.

## Full Build heeft eigen scope

**Full Build package** breidt uit:
- Alle "UIT SCOPE" items
- Incrementeel per release (v1.1, v1.2, etc)
- Staan in `black_ledger_full_build.zip`

Niet MVP met full build verwarren. Eén stap tegelijk.
