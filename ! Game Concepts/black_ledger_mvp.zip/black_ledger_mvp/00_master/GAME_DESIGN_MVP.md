# Black Ledger MVP - Game Design Document

## Elevator pitch

Je bent Rex Varn, een bounty hunter in de Helios Fringe, op jacht naar de Ledger - het verborgen netwerk dat de dood van je partner mogelijk maakte. Top-down space shooter met missie keuzes, faction reputation, en consequenties.

## Core loop (MVP, 30 min experience)

```
Main Menu → Intro Cutscene → Character Create → Level 1 (Korrigan-3 Escape) 
→ Boss Fight → Arrive at Station → Winkel → Bounty Board → Kies missie 
→ Play missie → Debriefing (credits + rep) → [loop terug naar station]
```

Na 2-3 missies: ending teaser "This is only the beginning..." met cliffhanger naar full game.

## Spelelementen MVP

### Speler

**Rex Varn (Man versie)**
- Startship: USP Talon (4 slots, 1 front weapon, 3 cargo)
- Starting credits: 500
- Starting reputation: 0 bij alle 6 facties (maar "runaway from Helios" flag)

### Ship combat

**Besturing:**
- WASD: movement (thrust-based of direct, designer choice - start direct)
- Mouse: aim
- Left click: primair wapen
- Right click: secundair wapen (indien equipped)
- Space: boost (3s, 10s cooldown)
- Q: EMP (indien equipped, 15s cooldown)

**Ship stats:**
- HP (armor + shield stacked)
- Speed (afhankelijk van ship class)
- Agility (turn rate)
- Generator (wapen energie)

**Damage model:**
- Shield absorbeert eerst, regenereert na 2.5s zonder schade
- Armor gaat erna, geen regen, alleen via reparatie in station
- Kritiek: ship explodeert, game over (respawn vanuit save)

### Wapens (MVP: 3 types)

1. **Pulse Cannon** (basic, starter)
   - Rate of fire: hoog
   - Damage per shot: laag
   - Energy: laag
   - Range: medium

2. **Missile Launcher** (kopen in winkel)
   - Rate of fire: laag
   - Damage per shot: hoog
   - Tracking: homing op locked target
   - Ammo: 10 max, kopen in winkel

3. **EMP Device** (reward van eerste missie)
   - Rate of fire: utility
   - Damage: geen
   - Effect: disable enemy shields for 8s
   - Cooldown: 15s

### Enemies (MVP)

**Waves tegen:**
- **Rookie pirates**: Harkon Syndicate low-level grunts
  - 50 HP, slow, predictable patterns
  - Drop: 50-100 credits
- **Veteran pirates**: na wave 1
  - 100 HP, evasive, accurate
  - Drop: 150-300 credits
- **Boss: Helios Enforcer**
  - 500 HP armor + 300 HP shield
  - Multiple phases (3)
  - Drops mission-unlock + 2000 credits

### Station (MVP: "Outer Rim Outpost")

**Diensten:**
- **Repair bay**: herstel armor voor credits
- **Winkel**: 
  - Pulse Cannon upgrades (level 1→3 in MVP)
  - Missiles (koop ammo)
  - Shield boost module
  - Armor plating
- **Bounty board**: 3 beschikbare contracts
- **Hangar**: alleen USP Talon zichtbaar (lock icons voor toekomstige ships)
- **Bar**: UI placeholder, naam "Varn's Regular" - toont save slots

### Missies (MVP: 3 stuks)

#### Missie 1: "Clean Sweep"
- **Type**: Eliminate
- **Client**: Outer Rim Outpost security  
- **Objective**: Vernietig 15 Harkon pirates in sector
- **Reward**: 500 credits, +5 rep Marshal Authority
- **Intel**: "Some bounties get shared. Some don't stay shared."

#### Missie 2: "Cargo Run"
- **Type**: Escort
- **Client**: Anonieme Fringe trader
- **Objective**: Bescherm cargo ship naar Sector 4
- **Reward**: 800 credits, +3 rep onbekende factie
- **Risk**: Harkon interceptors kunnen aanvallen
- **Intel datapad reward**: First coordinate pad (leads to future content)

#### Missie 3: "Bounty: Lieutenant Voss"
- **Type**: Bounty hunt
- **Client**: Bounty board (anonymous poster)
- **Objective**: Elimineer Harkon Lt. Daxus Voss (no relation to Mira - a mislead)
- **Reward**: 1500 credits, +8 rep Marshal Authority, -3 rep Harkon
- **Note voor Rex**: Discovery dat Voss niet familie was - eerste hint dat Ledger misleads bestaan

### Reputation system (basis)

**6 Facties** (getoond in station):
1. Harkon Syndicate - kleur: rood/zwart
2. Helios Corporation - kleur: wit/blauw (HOSTILE vanaf begin)
3. Marshal Authority - kleur: blauw/grijs
4. Ghost Market - kleur: paars/zwart
5. Phantom Collective - kleur: groen/zwart
6. Fringe Free States - kleur: bruin/oranje

**Rep ranges:**
- -100 (KOS): faction actively hunts jou
- -50 tot -1: hostile, geen diensten
- 0: neutral
- 1 tot 49: friendly, discount 10%
- 50+: allied, special missions unlock

**MVP scope rep**: Marshal Authority en Harkon Syndicate ontwikkelen, andere blijven 0 tot volledige build.

### Story hooks (MVP)

**Intro cutscene**: Korrigan-3 Hangar 7. Rex schiet twee bewakers neer, steelt USP Talon, vlucht. Voice over (text placeholder): "Mira didn't deserve this. And neither did the others."

**Station arrival**: Unknown NPC bij bar zegt: "You're Varn? Heard you were asking questions. Wrong kind of questions get you disappeared out here."

**Eerste datapad** (als missie reward): Coordinate pad met locatie "DEEPSPACE-7". Niet bereikbaar in MVP - teaser voor full game.

**Ending teaser**: Na missie 3, cutscene op station. Mysterieuze figuur (The Drifter) bij bar: "You killed the wrong Voss tonight. Interesting how easy it was, wasn't it?" Dan credit roll: "TO BE CONTINUED IN BLACK LEDGER FULL"

## UI design

### Main Menu
- NIEUW SPEL / DOORGAAN / OPTIES / AFSLUITEN
- Background: sterrenhemel + langzaam draaiend schip
- Music: Black Ledger theme (placeholder tone-based)

### HUD tijdens gameplay
- Top-left: Shield bar + Armor bar
- Top-center: Wave counter, level name
- Top-right: Credits, Score, Streak multiplier
- Bottom-left: Primary weapon icon + ammo
- Bottom-right: Secondary weapon + cooldown
- Bottom-center: Mission objective text (discrete)
- Mini-map: toggle met M (simple dots)

### Station UI
- Full-screen scene met background van station interior
- Sidebar met: Repair / Shop / Bounties / Hangar / Bar (save)
- Main area: contextual per selectie
- Exit: "Leave Station" knop

### Mission Briefing (Privateer-stijl)
- Left side: 128x128 portrait (static in MVP, animated in full)
- Right side: Client info + mission details
- Bottom: subtitles fade in per character (typewriter)
- Accept / Decline buttons

## Balans parameters (MVP start values)

### Economy
- Starting credits: 500
- Cost pulse cannon lv2: 800
- Cost pulse cannon lv3: 2000
- Cost missile launcher: 1500
- Cost missile ammo (10x): 200
- Cost shield module: 1800
- Cost armor plating: 2500
- Cost full armor repair: 50 per missing HP

### Progression
- Missie 1 reward: 500
- Missie 2 reward: 800
- Missie 3 reward: 1500
- Drop credits per enemy: 50-300 (variabel)
- Boss drop: 2000

### Difficulty curves
- Level 1 average combat difficulty: easy (rookies in de meerderheid)
- Boss difficulty: medium (vereist missiles of 2 upgraded wapens)
- Missie 1 difficulty: easy
- Missie 2 difficulty: medium
- Missie 3 difficulty: medium-hard (Voss heeft escort)

## Art direction (MVP)

**Stijl**: Pixel art, 64x64 ships voor combat sprites
**Palette**: Space noir - dominant dark blues, purples, oranges voor highlights
**Reference**: Tyrian 2000 + Raptor Call of the Shadows
**Assets source (MVP)**:
- Gekochte pixel art packs (al beschikbaar) als placeholder
- Parallel: NOVA v2 pipeline genereert custom assets
- Custom vervangt placeholders incrementeel

## Audio (MVP)

**Muziek**: 4 tracks (placeholder tone-based eerst, later Audiocraft generated)
- Main menu theme
- Combat track (level 1)
- Boss theme
- Station ambient

**SFX**: 
- Pulse cannon fire
- Missile launch
- Explosion (small + large)
- Shield hit
- Armor hit
- UI clicks
- Power-up collect

**Voice acting**: PLACEHOLDERS in MVP. Full build krijgt ElevenLabs of echte voice.

## Technical specs

- **Engine**: Godot 4.6.2
- **Language**: GDScript
- **Target**: Windows 10/11 x64
- **Resolution**: 1920x1080 native, scalable
- **Framerate**: 60 FPS target
- **File size**: < 500 MB voor MVP
- **Save**: JSON serialized, 3 slots

## Save data structure

```json
{
  "version": "0.1.0-mvp",
  "slot": 1,
  "created_at": "2026-XX-XX",
  "last_played": "2026-XX-XX",
  "character": {
    "name": "Rex Varn",
    "type": "man",
    "playtime_seconds": 3600
  },
  "progress": {
    "levels_completed": [1],
    "missions_completed": [1, 2],
    "missions_active": [3],
    "story_flags": ["intro_seen", "first_station_visit"],
    "current_location": "outer_rim_outpost"
  },
  "ship": {
    "ship_id": "usp_talon",
    "armor_current": 75,
    "armor_max": 100,
    "shield_max": 100,
    "weapons": ["pulse_cannon_lv2"],
    "upgrades": ["shield_module"]
  },
  "economy": {
    "credits": 1200,
    "missile_ammo": 5
  },
  "reputation": {
    "harkon": -12,
    "helios": -100,
    "marshal": 8,
    "ghost": 0,
    "phantom": 0,
    "fringe": 3
  }
}
```

## Success criteria MVP

**Launch alpha als:**
- Volledige loop speelbaar zonder crashes
- 30+ min gameplay content
- Save/load werkt
- Windows build onder 500MB
- Minstens 5 playthroughs zonder major bugs

**Nice to have:**
- 60 FPS stabiel
- Controller support
- Audio volume controls werkt
- Volledig Nederlands OF Engels (kies één)

## Niet in MVP - reminder

Expliciet UIT SCOPE voor MVP:
- Synthari race
- Cargo system 
- Starmap + wormholes
- Datapad ledger book complex
- Procedural biomes
- Andere 27 levels
- Boarding minigame
- Cargo scan events
- Complete faction politiek (alleen MA/Harkon MVP)
- Planetside/Blackthorne mode
- Alle voice acting
- Andere 8 ships
- Volledige endings (alleen teaser)

Deze komen in **Full Build package**.
