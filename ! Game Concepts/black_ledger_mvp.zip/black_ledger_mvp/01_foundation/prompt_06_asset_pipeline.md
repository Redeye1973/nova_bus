# Prompt 06: Asset Pipeline Setup

## Wat deze prompt bouwt

AssetCatalog autoload die assets laadt via string ID. Framework voor hot-swapping placeholder → NOVA-generated assets. NOVA pipeline jobs file (.nova_pipeline_jobs.json) parser.

## Voorwaarden

- [ ] Prompt 05 voltooid
- [ ] Project opent zonder critical errors in Godot 4.6.2

## De prompt

```
Bouw Asset Pipeline Setup voor Black Ledger MVP.

CONTEXT:
- Project: L:\1 Nova Cursor Output\Dark Ledger\
- Engine: Godot 4.6.2 (GDScript, Nederlandse comments waar zinvol, Engelse variabelnamen)
- Canon: L:\!Nova V2\canon\BLACK_LEDGER_STORY_BIBLE.md (referentie)
- Design: black_ledger_mvp/00_master/GAME_DESIGN_MVP.md
- Target files: scripts/core/asset_catalog.gd + scripts/core/nova_pipeline_client.gd
- Scope: Assets toegankelijk via AssetCatalog.get('enemy_harkon_rookie'), placeholder/real switch mogelijk

TAAK:
AssetCatalog autoload die assets laadt via string ID. Framework voor hot-swapping placeholder → NOVA-generated assets. NOVA pipeline jobs file (.nova_pipeline_jobs.json) parser.

Specifieke implementatie details staan in GAME_DESIGN_MVP.md. Houd je aan MVP scope - NIET over-engineeren.

STAP 1: Lees relevante sectie van GAME_DESIGN_MVP.md

STAP 2: Maak of update target files volgens design spec
- Follow Godot 4.6 best practices
- GDScript type hints waar mogelijk
- @export properties voor data-driven design
- Signals voor inter-node communicatie

STAP 3: Unit testing waar mogelijk
- GUT framework (als al geinstalleerd) OF
- Handmatige Godot test scripts via F6 (Run Current Scene)

STAP 4: Integratie test in Godot
- Scene loadt zonder errors
- Feature werkt als ontworpen
- Geen breaking changes aan bestaande code

STAP 5: NOVA pipeline integratie (indien applicabel)
Als deze prompt assets nodig heeft die NOVA kan genereren:
- Check .nova_pipeline_jobs.json voor relevante job IDs
- Trigger pipeline via webhook indien agent ready
- Gebruik placeholder als pipeline niet beschikbaar
- Asset verwisselbaar later via AssetCatalog

STAP 6: Documentatie
Append naar docs/build_log_$(Get-Date -Format 'yyyy-MM-dd').md:
```markdown
## Prompt 06: Asset Pipeline Setup - COMPLEET/PARTIAL/FAILED

[wat gebouwd, wat werkt, wat niet, known issues]

## Next
Prompt 07
```

STAP 7: Git commit
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "feat(asset_pipeline): Asset Pipeline Setup

[changes summary]"

REGELS:
- Max 2 retries bij zelfde aanpak
- Bij failure: markeer in build_log, skip indien niet blocking, continue
- MVP scope respecteren - geen features toevoegen buiten GAME_DESIGN_MVP.md
- Test in Godot na elke major change
- Commit regelmatig

RAPPORT:
Toon in chat na klaar:
- Prompt 06 status (COMPLEET/PARTIAL/FAILED)
- Wat gebouwd
- Known issues
- Volgende: prompt_07_*.md
```

## Verwachte output

Files in: `scripts/core/asset_catalog.gd + scripts/core/nova_pipeline_client.gd`
Werkend in Godot: Assets toegankelijk via AssetCatalog.get('enemy_harkon_rookie'), placeholder/real switch mogelijk

## Validatie

1. Open project in Godot
2. Run relevante scene (F6 voor current scene, F5 voor main)
3. Test feature die deze prompt bouwt
4. Check Output panel voor errors
5. Review code in VS Code / Cursor

## Debug bij problemen

- Check Output panel voor Godot errors
- Check `docs/build_log_*.md` voor context
- Review vorige prompt output
- Als blocker: markeer failed, skip, continue met volgende prompt
- Max 2 retries zelfde aanpak (NOVA regel)

## Commit message

```
feat(asset_pipeline): Asset Pipeline Setup
```

## Volgende prompt

`01_foundation/prompt_07_*.md` (zie PROMPT_INDEX.md)
