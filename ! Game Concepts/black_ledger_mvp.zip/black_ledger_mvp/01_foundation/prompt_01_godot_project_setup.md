# Prompt 01: Godot Project Setup

## Wat deze prompt bouwt

Basis Godot 4.6.2 project voor Black Ledger. Configureert project settings, input mappings, renderer, export templates, en eerste placeholder scenes.

## Voorwaarden

- [ ] Godot 4.6.2 geïnstalleerd
- [ ] Project directory aanwezig: `L:\1 Nova Cursor Output\Dark Ledger\`
- [ ] Git geïnitialiseerd in project directory
- [ ] START_HERE.md voltooid (directory structuur gemaakt)

## De prompt

```
Setup Black Ledger Godot project.

CONTEXT:
- Project root: L:\1 Nova Cursor Output\Dark Ledger\
- Godot versie: 4.6.2
- Render pipeline: Forward Plus (kunnen we later naar Mobile degraderen indien nodig)
- Target: Windows 10/11 x64, 1920x1080 native

STAP 1: project.godot bestand maken
Maak L:\1 Nova Cursor Output\Dark Ledger\project.godot met:

[application]
config/name="Black Ledger"
config/description="Space shooter in the Helios Fringe. You don't play Rex Varn. You wear him."
config/version="0.1.0-mvp"
run/main_scene="res://scenes/main_menu/main_menu.tscn"
config/features=PackedStringArray("4.6", "Forward Plus")
config/icon="res://icon.svg"

[autoload]
GameState="*res://scripts/managers/game_state.gd"
GameConstants="*res://scripts/core/game_constants.gd"
AudioManager="*res://scripts/managers/audio_manager.gd"
SaveManager="*res://scripts/managers/save_manager.gd"
SettingsManager="*res://scripts/managers/settings_manager.gd"
ReputationManager="*res://scripts/managers/reputation_manager.gd"
MissionManager="*res://scripts/managers/mission_manager.gd"
StoryManager="*res://scripts/managers/story_manager.gd"

[display]
window/size/viewport_width=1920
window/size/viewport_height=1080
window/size/window_width_override=1280
window/size/window_height_override=720
window/stretch/mode="canvas_items"
window/stretch/aspect="keep"

[input]
move_up={
"deadzone": 0.2,
"events": [InputEventKey{"keycode":87}, InputEventKey{"keycode":4194320}]
}
move_down={...similar for S + Down}
move_left={...similar for A + Left}
move_right={...similar for D + Right}
primary_fire={
"deadzone": 0.2,
"events": [InputEventMouseButton{"button_index":1}, InputEventKey{"keycode":32}]
}
secondary_fire={
"deadzone": 0.2,
"events": [InputEventMouseButton{"button_index":2}]
}
boost={
"deadzone": 0.2,
"events": [InputEventKey{"keycode":32}]
}
emp_device={
"deadzone": 0.2,
"events": [InputEventKey{"keycode":81}]
}
pause={
"deadzone": 0.2,
"events": [InputEventKey{"keycode":4194305}]
}
toggle_minimap={
"deadzone": 0.2,
"events": [InputEventKey{"keycode":77}]
}

[physics]
2d/default_gravity=0
2d/default_linear_damp=1.0

[rendering]
renderer/rendering_method="forward_plus"
textures/canvas_textures/default_texture_filter=0  # NEAREST voor pixel art
environment/defaults/default_clear_color=Color(0.05, 0.05, 0.1, 1)

[layer_names]
2d_physics/layer_1="world"
2d_physics/layer_2="player"
2d_physics/layer_3="player_bullet"
2d_physics/layer_4="enemy"
2d_physics/layer_5="enemy_bullet"
2d_physics/layer_6="powerup"
2d_physics/layer_7="boss"
2d_physics/layer_8="station"

STAP 2: Placeholder singletons maken

Maak L:\1 Nova Cursor Output\Dark Ledger\scripts\core\game_constants.gd:
```gdscript
extends Node
# Black Ledger Game Constants
# Centraal alle enums en vaste waardes

enum Faction {
    NONE = 0,
    HARKON = 1,
    HELIOS = 2,
    MARSHAL = 3,
    GHOST_MARKET = 4,
    PHANTOM = 5,
    FRINGE = 6
}

enum ShipClass {
    FIGHTER = 0,
    BOMBER = 1,
    CORVETTE = 2,
    MINING = 3,
    STEALTH = 4
}

enum WeaponType {
    PULSE_CANNON = 0,
    MISSILE = 1,
    EMP = 2,
    PLASMA = 3,  # Full build
    RAILGUN = 4  # Full build
}

enum EnemySkill {
    ROOKIE = 0,
    VETERAN = 1,
    ELITE = 2,
    ACE = 3
}

enum MissionType {
    ELIMINATE = 0,
    ESCORT = 1,
    BOUNTY = 2,
    CARGO = 3,  # Full build
    SCAN = 4    # Full build
}

enum GameMode {
    STORY = 0,
    ARCADE = 1,  # Full build
    TIMED = 2    # Full build
}

# Kleuren per faction
const FACTION_COLORS = {
    Faction.HARKON: Color("#8B0000"),
    Faction.HELIOS: Color("#F0F0F0"),
    Faction.MARSHAL: Color("#003366"),
    Faction.GHOST_MARKET: Color("#9932CC"),
    Faction.PHANTOM: Color("#2F4F2F"),
    Faction.FRINGE: Color("#8B4513")
}

# Reputation thresholds
const REP_KOS = -100
const REP_HOSTILE = -50
const REP_NEUTRAL = 0
const REP_FRIENDLY = 25
const REP_ALLIED = 50
const REP_HERO = 75

# Ship physics defaults
const SHIP_ACCELERATION_BASE = 300.0
const SHIP_MAX_SPEED_BASE = 600.0
const SHIP_ROTATION_SPEED_BASE = 3.0  # rad/s
const SHIP_FRICTION = 2.0

# Score multipliers
const STREAK_MULTIPLIERS = {5: 2, 10: 3, 20: 4, 40: 5}
const STREAK_TIMEOUT = 3.0  # seconds
```

Maak L:\1 Nova Cursor Output\Dark Ledger\scripts\managers\game_state.gd:
```gdscript
extends Node
# Global game state - klein, voor cross-scene data

signal game_started
signal game_paused(paused: bool)
signal scene_changed(scene_name: String)

var current_scene: String = ""
var is_paused: bool = false
var current_save_slot: int = -1

# Runtime character data
var character_name: String = "Rex Varn"
var character_type: String = "man"

# Debug
var debug_mode: bool = OS.is_debug_build()

func _ready() -> void:
    print("[GameState] Initialized, debug_mode=%s" % debug_mode)

func change_scene(path: String) -> void:
    current_scene = path
    scene_changed.emit(path)
    get_tree().change_scene_to_file(path)

func toggle_pause() -> void:
    is_paused = not is_paused
    get_tree().paused = is_paused
    game_paused.emit(is_paused)
```

Maak placeholder versies (zullen in latere prompts uitgebouwd worden):
- scripts/managers/audio_manager.gd - print statements only
- scripts/managers/save_manager.gd - print statements only  
- scripts/managers/settings_manager.gd - print statements only
- scripts/managers/reputation_manager.gd - print statements only
- scripts/managers/mission_manager.gd - print statements only
- scripts/managers/story_manager.gd - print statements only

Elk heeft deze basis template:
```gdscript
extends Node
# [Manager naam]
# Placeholder - wordt uitgebouwd in prompt XX

func _ready() -> void:
    print("[%s] Initialized (placeholder)" % get_script().resource_path.get_file())
```

STAP 3: Placeholder main_menu scene
Maak scenes/main_menu/main_menu.tscn met:
- CanvasLayer node
- ColorRect background (zwart)
- Label centered: "BLACK LEDGER - PLACEHOLDER"
- Label kleiner eronder: "Main menu wordt gebouwd in prompt 31"
- Script dat bij input space gaat naar test scene

Maak scripts/ui/main_menu_placeholder.gd:
```gdscript
extends CanvasLayer

func _input(event: InputEvent) -> void:
    if event.is_action_pressed("primary_fire"):
        print("[MainMenuPlaceholder] Space pressed, main menu komt later")
```

STAP 4: Icon + default resources
Genereer icon.svg (simpel placeholder):
```xml
<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">
    <rect width="128" height="128" fill="#0d0d1a"/>
    <text x="64" y="74" text-anchor="middle" fill="#f5a623" font-size="24" font-family="monospace">BL</text>
</svg>
```

STAP 5: .gitignore
Maak .gitignore:
```
# Godot 4
.godot/
*.translation
export.cfg
export_presets.cfg

# Mono
.mono/
data_*/

# System
.DS_Store
Thumbs.db

# Editor
*.import

# Build artifacts
exports/
*.exe
*.zip
*.pck

# IDE
.vscode/
*.sublime-*
.idea/

# NOVA
.nova_pipeline_jobs.json  # lokaal, niet in git
save_data/*.save          # playtest saves
```

STAP 6: README voor project
Maak README.md:
```markdown
# Black Ledger

Space shooter in the Helios Fringe. You don't play Rex Varn. You wear him.

## Build

Open `project.godot` in Godot 4.6.2.

## Status

v0.1.0-mvp in development.

See docs/ for design documents.
```

STAP 7: Test in Godot
- Open project.godot in Godot 4.6.2
- Check voor errors in Output panel
- Verwacht: geen critical errors
- Autoloads moeten zichtbaar zijn in Scene tree
- Main menu placeholder scene moet openen

STAP 8: Git commit
cd "L:\1 Nova Cursor Output\Dark Ledger"
git add .
git commit -m "feat(setup): Godot 4.6.2 project scaffold

- project.godot met Black Ledger settings
- 8 autoload singletons (placeholders)
- Input actions gedefinieerd
- GameConstants met enums + kleuren
- GameState singleton
- Placeholder main menu
- .gitignore + README"

STAP 9: Status log
Schrijf docs/build_log_$(Get-Date -Format 'yyyy-MM-dd').md eerste entry:
```markdown
# Build Log - [datum]

## Prompt 01: Godot Project Setup - COMPLEET

- Project configureerd Godot 4.6.2
- Autoloads allemaal placeholder, worden uitgebouwd in latere prompts
- Input mappings: WASD, mouse, Space=boost, Q=EMP, M=minimap, Esc=pause
- GameConstants enums voor Faction, ShipClass, WeaponType, EnemySkill, MissionType

## Volgende: Prompt 02 Core Singletons

Uitbouwen van:
- AudioManager
- SettingsManager
- GameState uitbreidingen
```

RAPPORT:
Toon in chat:
- Prompt 01 compleet
- Project opent zonder errors
- Git commit gedaan
- Volgende: prompt_02_core_singletons.md
```

## Verwachte output

**Files aangemaakt:**
- `project.godot` (volledig geconfigureerd)
- `scripts/core/game_constants.gd` (met alle enums)
- `scripts/managers/game_state.gd` (singleton)
- 6 placeholder managers in `scripts/managers/`
- `scenes/main_menu/main_menu.tscn` (placeholder)
- `scripts/ui/main_menu_placeholder.gd`
- `icon.svg`
- `.gitignore`
- `README.md`
- `docs/build_log_YYYY-MM-DD.md`

## Validatie

1. **Open project in Godot**:
   ```powershell
   & "C:\Program Files\Godot\godot.exe" "L:\1 Nova Cursor Output\Dark Ledger\project.godot"
   ```

2. **Check Output panel**:
   - Geen critical errors
   - Mag warnings hebben voor placeholder managers

3. **Run project (F5)**:
   - Main menu placeholder opent
   - Tekst "BLACK LEDGER - PLACEHOLDER" zichtbaar
   - Spatiebalk triggert console print

4. **Check autoloads**:
   - Ga naar Project Settings > Autoload
   - Verify 8 autoloads in lijst

## Commit message

```
feat(setup): Godot 4.6.2 project scaffold
```

## Volgende prompt

`01_foundation/prompt_02_core_singletons.md`
