# Black Ledger Godot Project Health Check
# Valideert projectintegriteit

param(
    [string]$ProjectPath = "L:\1 Nova Cursor Output\Dark Ledger"
)

Write-Host ""
Write-Host "=== Black Ledger Project Health Check ===" -ForegroundColor Cyan
Write-Host ""

$issues = @()
$warnings = @()

# 1. Directory structure
Write-Host "1. Directory structure..." -ForegroundColor Gray
$requiredDirs = @("scripts/core", "scripts/managers", "scripts/player", "scripts/enemies", "scripts/weapons", "scripts/ui", "scenes", "resources", "assets/sprites", "assets/audio", "docs")
foreach ($d in $requiredDirs) {
    $path = Join-Path $ProjectPath $d
    if (-not (Test-Path $path)) {
        $issues += "Missing dir: $d"
    }
}

# 2. Critical files
Write-Host "2. Critical files..." -ForegroundColor Gray
$requiredFiles = @(
    "project.godot",
    "scripts/core/game_constants.gd",
    "scripts/managers/game_state.gd"
)
foreach ($f in $requiredFiles) {
    $path = Join-Path $ProjectPath $f
    if (-not (Test-Path $path)) {
        $issues += "Missing file: $f"
    }
}

# 3. Godot version check in project.godot
Write-Host "3. Godot version..." -ForegroundColor Gray
$projectFile = Join-Path $ProjectPath "project.godot"
if (Test-Path $projectFile) {
    $content = Get-Content $projectFile -Raw
    if ($content -match 'config/features.*"4\.6"') {
        Write-Host "  Godot 4.6 configured" -ForegroundColor Green
    } else {
        $warnings += "Godot version mag niet 4.6 zijn"
    }
}

# 4. Autoloads check
Write-Host "4. Autoloads in project.godot..." -ForegroundColor Gray
if (Test-Path $projectFile) {
    $content = Get-Content $projectFile -Raw
    $expectedAutoloads = @("GameState", "GameConstants", "AudioManager", "SaveManager", "SettingsManager", "ReputationManager", "MissionManager", "StoryManager")
    $foundCount = 0
    foreach ($auto in $expectedAutoloads) {
        if ($content -match "$auto=") {
            $foundCount++
        } else {
            $warnings += "Autoload missing: $auto"
        }
    }
    Write-Host "  Autoloads found: $foundCount/$($expectedAutoloads.Count)" -ForegroundColor $(if ($foundCount -eq $expectedAutoloads.Count) { "Green" } else { "Yellow" })
}

# 5. Git status
Write-Host "5. Git status..." -ForegroundColor Gray
Push-Location $ProjectPath
try {
    $gitStatus = git status --porcelain 2>&1
    if ($LASTEXITCODE -eq 0) {
        $uncommitted = ($gitStatus | Measure-Object).Count
        if ($uncommitted -eq 0) {
            Write-Host "  All changes committed" -ForegroundColor Green
        } else {
            $warnings += "$uncommitted uncommitted changes"
        }
    } else {
        $warnings += "Git not initialized or not accessible"
    }
    
    # Last commits
    $lastCommits = git log --oneline -5 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  Last 5 commits:" -ForegroundColor Gray
        $lastCommits | ForEach-Object { Write-Host "    $_" -ForegroundColor DarkGray }
    }
} finally {
    Pop-Location
}

# 6. Script count
Write-Host "6. Script count..." -ForegroundColor Gray
$scriptsPath = Join-Path $ProjectPath "scripts"
if (Test-Path $scriptsPath) {
    $gdFiles = Get-ChildItem $scriptsPath -Filter "*.gd" -Recurse
    Write-Host "  GDScript files: $($gdFiles.Count)" -ForegroundColor Green
}

# 7. Scene count
Write-Host "7. Scene count..." -ForegroundColor Gray
$scenesPath = Join-Path $ProjectPath "scenes"
if (Test-Path $scenesPath) {
    $tscnFiles = Get-ChildItem $scenesPath -Filter "*.tscn" -Recurse
    Write-Host "  Scene files: $($tscnFiles.Count)" -ForegroundColor Green
}

# 8. Resource count
Write-Host "8. Resource count..." -ForegroundColor Gray
$resourcesPath = Join-Path $ProjectPath "resources"
if (Test-Path $resourcesPath) {
    $tresFiles = Get-ChildItem $resourcesPath -Filter "*.tres" -Recurse
    Write-Host "  Resource files: $($tresFiles.Count)" -ForegroundColor Green
}

# 9. Build log check
Write-Host "9. Build log..." -ForegroundColor Gray
$buildLogPath = Join-Path $ProjectPath "docs\build_log_$(Get-Date -Format 'yyyy-MM-dd').md"
if (Test-Path $buildLogPath) {
    $lines = (Get-Content $buildLogPath | Measure-Object -Line).Lines
    Write-Host "  Today's build log: $lines lines" -ForegroundColor Green
} else {
    $warnings += "Geen build log voor vandaag"
}

# 10. Assets present
Write-Host "10. Assets..." -ForegroundColor Gray
$spritesPath = Join-Path $ProjectPath "assets\sprites"
if (Test-Path $spritesPath) {
    $pngCount = (Get-ChildItem $spritesPath -Filter "*.png" -Recurse).Count
    Write-Host "  Sprite PNG files: $pngCount" -ForegroundColor $(if ($pngCount -gt 0) { "Green" } else { "Yellow" })
    if ($pngCount -eq 0) {
        $warnings += "Geen sprites gevonden - import placeholder packs?"
    }
}

# Summary
Write-Host ""
Write-Host "=== Summary ===" -ForegroundColor Cyan

if ($issues.Count -gt 0) {
    Write-Host "Issues ($($issues.Count)):" -ForegroundColor Red
    foreach ($i in $issues) {
        Write-Host "  - $i" -ForegroundColor Red
    }
}

if ($warnings.Count -gt 0) {
    Write-Host "Warnings ($($warnings.Count)):" -ForegroundColor Yellow
    foreach ($w in $warnings) {
        Write-Host "  - $w" -ForegroundColor Yellow
    }
}

if ($issues.Count -eq 0 -and $warnings.Count -eq 0) {
    Write-Host "All good! Project looks healthy." -ForegroundColor Green
}

Write-Host ""

# Exit code
if ($issues.Count -gt 0) { exit 1 } else { exit 0 }
