# MVP Asset Lijst

Alles wat assets-wise nodig is voor speelbare MVP. Gesplitst naar productie strategie.

## Strategie categorieën

**A. Placeholder packs (al in bezit)**
Gekochte pixel art uit `L:\Nova Assets\Gekochte Assets\Pixel Art\`. Direct bruikbaar.

**B. NOVA pipeline gegenereerd**
Via FreeCAD/Blender/Aseprite pipeline na Fase 1 agents klaar.

**C. Handwerk (Aseprite/Krita direct)**
Voor cases waar placeholders en pipeline beide tekortschieten.

**D. Later vervangen**
Voor MVP placeholder, in full build upgrade.

## Sprite assets

### Player ship

**USP Talon**
- Strategie: B (NOVA pipeline) of A (placeholder)
- Specs: 64x64, top-down view
- Animations: idle (3 frames), boost (5 frames), damage flash
- 3 damage states
- Source placeholder: `Animated_Pixel_Ships/Plane_02_Normal/*.png`

### Enemy ships (MVP: 3 types)

**Harkon Rookie Pirate**
- Strategie: A → B
- 64x64, gebrekkige pirate ship look
- Rood/zwart faction palette
- 4 rotation frames (omhoog, omlaag, diagonaal)
- Source placeholder: `Pixel_Enemies_for_SHMUP/harkon_variant_01/*.png`

**Harkon Veteran Pirate**  
- Strategie: A → B
- 64x64, slightly larger/meaner dan rookie
- Zelfde kleuren, meer detail
- Source placeholder: `Pixel_Enemies_for_SHMUP/harkon_variant_02/*.png`

**Helios Enforcer (Boss Level 1)**
- Strategie: A → B priority
- 128x128, intimidating military design
- Wit/blauw corporate palette
- Multi-phase animations (phases 1, 2, 3 variants)
- Destruction sequence special VFX
- Source placeholder: `Pixel_Enemies_for_SHMUP/07_Emperor_Boss/*.png`

### Projectiles

**Pulse Cannon bullet**
- Strategie: A
- 16x16, yellow/orange glow
- Directional (pointing toward travel)
- Source: `SHMUP_1.5.1_Projectiles/pulse_*.png`

**Missile**
- Strategie: A
- 24x16, rocket silhouette with flame trail
- Homing animation (rotation)
- Source: `Animated_Pixel_Ships_Projectiles/missile_*.png`

**EMP pulse**
- Strategie: C (handmatig gemaakt want specifiek effect)
- 128x128 expanding ring
- Blauwe electric arcs
- 8 animatie frames expand + fade

**Enemy projectiles**
- Strategie: A
- Verschillende kleuren per faction (rood Harkon, blauw Helios)
- Generic "enemy bullet" placeholder

### VFX

**Explosion small** (enemy rookie destroyed)
- Strategie: A
- 64x64, 8 frames
- Source: `Pixel_Art_VFX_Explosions/small_*.png`

**Explosion large** (boss phases, cargo ship death)
- Strategie: A
- 256x256, 16 frames
- Source: `Pixel_Art_VFX_Explosions/large_*.png`

**Shield hit effect**
- Strategie: A
- 64x64, 4 frames
- Blauwe pulse
- Source: `Animated_Pixel_Ships_Shield/hit_*.png`

**Muzzle flash**
- Strategie: A
- 32x32, 3 frames
- Source: `Animated_Pixel_Ships_Icons/muzzle_*.png`

**Engine thruster**
- Strategie: A
- 48x32, 5 frame loop
- Source: `Animated_Pixel_Ships_Large_Thrusters/thruster_*.png`

### Power-ups

**Health pack**
- Strategie: A
- 32x32, rood cross icon, pulsing
- Source: `Animated_Pixel_Ships_Power-Ups/health_*.png`

**Shield boost**
- Strategie: A  
- 32x32, blauw shield icon
- Source: `Animated_Pixel_Ships_Power-Ups/shield_*.png`

**Missile restock**
- Strategie: A
- 32x32, ammo crate icon
- Source: `Animated_Pixel_Ships_Power-Ups/ammo_*.png`

### Backgrounds

**Level 1 Korrigan sector**
- Strategie: A
- Space backdrop, dim industrial zone
- 4 parallax layers (deep stars, nebula, far planets, near debris)
- Source: `Pixel_Art_Space_Background_SHMUP/industrial_*.png` + `Animated_Pixel_Ships_Background/starry_*.png`

**Mission sector alpha** (Missie 1)
- Strategie: A
- Asteroid field theme
- Tint subtly different dan level 1 voor variatie

**Mission sector beta** (Missie 2 escort)
- Strategie: A  
- Deep space, nebula heavy
- Hint van danger ahead

**Mission sector gamma** (Missie 3 Voss hunt)
- Strategie: A
- Derelict ship zone, debris
- Dim atmosphere

**Station interior (Outer Rim Outpost)**
- Strategie: A + C combination
- 1920x1080 interior view
- Warm amber lighting
- Silhouettes van NPCs op achtergrond
- Source: zoeken in purchased packs OF eigen compositie

## UI assets

### Main menu
- Logo "BLACK LEDGER" (C - handmatig in Krita/Aseprite)
- Button sprites (C of A)
- Star field animated background (A)
- Rotating ship icon (A, USP Talon)

### HUD elements
- Shield bar (C - handmatig)
- Armor bar (C)
- Weapon icons (A - uit purchased packs)
- Credits display (font only)
- Mini-map radar (C)

### Station UI
- Sidebar icons (Repair, Shop, Bounties, Hangar, Bar) (C)
- Faction logos x6 (C - handmatig, stijl matching)
- Ship preview frame (C)
- Item cards voor winkel (C)

### Mission briefing
- Portrait frames (C)
- Portraits NPCs (D - placeholders eerst, later Meshy+polish):
  - Marshal Stellan (Missie 1 client)
  - Unnamed cargo trader (Missie 2)
  - Bounty poster (Missie 3 - generic icon)
  - Bar NPC (save point)
  - The Drifter (ending teaser, face obscured)

### Character creation
- Portrait placeholders (D):
  - Man (Rex Varn)
  - Vrouw (Rexa, LOCKED icon overlay)
  - Synthari (Designation Varn, LOCKED)

## Audio assets

### Music tracks (MVP: 4)

**Main menu theme**
- Strategie: C (placeholder procedural) → B (Audiocraft generated later)
- 2-3 min loopable, ambient space noir
- Reference: Tyrian soundtrack vibe

**Level 1 combat**
- Strategie: C → B
- 3-4 min, driving industrial electronic
- Build tension, action appropriate

**Boss theme**
- Strategie: C → B
- 2-3 min, intense, higher BPM
- Memorable for Helios Enforcer encounter

**Station ambient**
- Strategie: C → B
- 5 min loop, low-key atmospheric
- Bar chatter, mechanical hum hints

### SFX

**Weapon sounds**
- Pulse cannon fire (cached small SFX, 0.3s)
- Missile launch (1.0s)
- EMP pulse (1.5s electric)

**Impact sounds**
- Shield hit (soft, 0.4s)
- Armor hit (harder, 0.5s)
- Small explosion (1.0s)
- Large explosion (2.5s)

**UI sounds**
- Menu click (0.1s)
- Button hover (0.05s)
- Purchase sound (0.8s)
- Save/load (1.0s)
- Mission accept (0.5s)

**Environment**
- Engine hum loop (ship running)
- Thruster boost (1.0s activation)
- Station ambient bed (looping)

### Voice acting

**MVP**: Text-only dialogs, geen voice acting
**Full build**: ElevenLabs integratie voor key lines

Placeholder: text popup met typewriter effect is voldoende voor MVP

## Fonts

**Main font**: system monospace (ingebouwd in Godot) of placeholder
**Optional**: 1 "space noir" font voor titels (C - find free open-source)

## Colors (master palette)

Deze komen uit Design Fase agent (NOVA pipeline). MVP hard-coded palette:

```
# Background
bg_deep = #0d0d1a
bg_panel = #14142a
border = #3c50b4

# Faction colors  
harkon = #8B0000
helios = #F0F0F0
marshal = #003366
ghost = #9932CC
phantom = #2F4F2F
fringe = #8B4513

# UI accents
gold = #f5a623  # positive/success
red = #e94560   # danger/warning
white = #e0e0e0 # primary text
grey = #8080a0  # secondary text
```

## Productie volgorde

### Week 1-2 (tijdens Fase 1 prompts)
- Alle A strategy assets import vanuit purchased packs
- Placeholders beschikbaar voor elke categorie
- AssetCatalog system ingesteld

### Week 3-5 (tijdens Fase 2-3 prompts, NOVA pipeline actief)
- NOVA pipeline genereert B strategy assets
- USP Talon custom renders
- Harkon faction ships via FreeCAD + Blender pipeline
- Helios Enforcer boss (prioriteit)
- Iteratief vervangen placeholders

### Week 4-6 (tijdens Fase 4-5 prompts)
- C strategy: handmatig UI elements, logo, HUD bars
- NPC portraits (D strategy placeholders → later custom)
- Environment compositions

### Week 6-8 (Fase 6 finalization)
- Audio placeholder swap naar generated
- Final polish pass
- Build export

## Kwaliteitscriteria MVP

**Acceptable**:
- Visuele coherentie over alle assets
- Geen broken/missing sprites
- Readable UI op 1080p
- Audio werkt (placeholder kwaliteit OK)

**Desired but optional**:
- Custom art consistent per faction
- Music feels thematic
- Polish details (dust particles, screen shake op big impacts)

**Not required for MVP**:
- AAA-quality sprites
- Full voice acting
- Cinematic cutscenes
- Detailed animations

## Asset budget

**Purchased packs** (reeds betaald): €0 extra
**NOVA pipeline** (Meshy credits): max 300-500 van je 1000 voor references
**Handwerk tijd**: 20-40 uur over 6 weken
**ElevenLabs** (voice, OPTIONEEL MVP): $5-15

**Totaal MVP extra budget**: €0-20

## Licentie tracking

Belangrijk: licenties respecteren

- `LICENSE_ASSETS.md` in project root onderhouden
- Purchased packs: geen redistribution
- Meshy generated: private license (Pro plan)
- NOVA-generated: jouw IP
- Audio: placeholder procedural = safe, licensed music = track

## Post-MVP plan

**Full build asset expansion**:
- 8 additional ships
- 5+ faction variant enemy sprites per faction
- Complete boss roster (~10 bosses)
- 28 level backgrounds
- Full starmap UI
- Complete voice acting
- Environment props voor planetside mode
- Synthari race visual variants
- Audio library complete

Voor MVP: focus op core loop werkend krijgen. Polish later.
