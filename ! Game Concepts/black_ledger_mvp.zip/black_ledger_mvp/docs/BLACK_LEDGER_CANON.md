# Black Ledger Canon - Quick Reference

Dit is de compacte versie. Volledige canon in `L:\!Nova V2\canon\BLACK_LEDGER_STORY_BIBLE.md`.

## De wereld in één zin

Helios Fringe - post-colonial ruimtegebied waar 6 facties elkaar afwisselend beconcurreren en samenwerken, gebonden door The Ledger: een geheim netwerk van schulden dat alles bij elkaar houdt door iedereen chantabel te maken.

## Rex Varn (protagonist)

- Voormalig Helios Corporation piloot
- Partner Mira Voss stierf in corrupte arrestatie (Helios + Harkon deal)
- Rex ontdekte The Ledger, klachten verdwenen, werd vijand
- Stal USP Talon, vluchtte, begon revenge campaign
- Bounty hunter als inkomstenbron
- Chirurgisch, niet massamoordenaar
- Doodt nooit onschuldigen, kinderen, of liegt over naam
- Drinkt niet, slaapt slecht, gelooft hij verdient geen rust

**MVP dialoogstijl**: karig, pragmatisch, cynisch maar niet bitter. Weinig grootse verklaringen. Praat alleen als het telt.

**Canon quote**: "Rex Varn begon niet als monster. Rex Varn werd gemaakt door mensen die dachten dat ze ongestraft een leven konden afschrijven. Ze hadden gelijk - bijna."

## De 6 facties (MVP relevante info)

### 1. Harkon Syndicate
- **Kleur**: rood/zwart
- **Rol MVP**: Main antagonist faction voor Missie 1 + 3
- **Karakter**: Business crimineel. Transparant over wat ze zijn.
- **Houding naar Rex**: Rex financieert zich door Harkon bounties. Harkon ziet Rex als nuisance maar niet echt vijand.
- **Motto**: "Alles heeft een prijs. Als je die niet kent, betaal je te veel."

### 2. Helios Corporation
- **Kleur**: wit/blauw
- **Rol MVP**: Hostile vanaf start. Niet in MVP missies.
- **Karakter**: Corporate monster. Deed Mira arresteren.
- **Houding naar Rex**: KOS (-100 rep vanaf start)
- **In MVP**: Alleen in intro cutscene (guards op Korrigan-3) + boss Helios Enforcer

### 3. Marshal Authority
- **Kleur**: blauw/grijs
- **Rol MVP**: Ambivalent bondgenoot. Client van Missie 1.
- **Karakter**: Bureaucratisch. Soms corrupt.
- **Houding naar Rex**: Classificeert hem officieel als fugitive, in praktijk ontwijken ze confrontatie als hij bounty targets pakt die ook hun targets zijn.

### 4. Ghost Market
- **Kleur**: paars/zwart
- **Rol MVP**: Alleen statisch zichtbaar
- **Karakter**: Anarchisten + tech smokkelaars
- **Houding naar Rex**: Neutraal

### 5. Phantom Collective
- **Kleur**: groen/zwart
- **Rol MVP**: Alleen statisch zichtbaar  
- **Karakter**: Cyborg cultus met technocratie
- **Houding naar Rex**: Fascinated (hij is "interesting case study")

### 6. Fringe Free States
- **Kleur**: bruin/oranje
- **Rol MVP**: Thuis van Rex. Outer Rim Outpost is Fringe station.
- **Karakter**: Pragmatisch, warm onderling, geen hiërarchie
- **Houding naar Rex**: Hero zonder dat hij het zoekt

## The Ledger

- Geen organisatie, geen persoon
- Netwerk van wederzijdse schulden + geheimen
- Elke faction heeft iets dat ze niet openbaar willen
- Maakt iedereen chantabel → niemand durft te vernietigen
- Rex wil het vernietigen, niet beheersen
- **MVP scope**: alleen gerefereerd in dialogen, niet gameplay mechanic

## The Drifter

- Mysterieuze figuur zonder gezicht
- Verschijnt op onverwachte momenten
- Weet dingen niemand zou moeten weten
- **MVP**: Alleen in ending teaser. Zegt "You killed the wrong Voss tonight."

## MVP specifieke characters

### Lt. Daxus Voss (Missie 3 target)
- Harkon lieutenant
- Geen familie van Mira Voss (red herring)
- Escort: 4 veterans
- Drops datapad: "Name match is coincidence. Check your sources."

### Cargo trader (Missie 2 client)
- Anonymous Fringe trader
- Scruffy, bezorgd, pragmatisch
- Pays cash, vraagt geen vragen

### Outpost Security (Missie 1 client)
- Marshal lieutenant, naam "Stellan"
- Friendly naar Rex (grijze zone)
- Gives Marshal bounties unofficially

### Intro guards (Helios, Korrigan-3)
- Geen dialoog, alleen gevecht
- Establishes Helios als vijand

### Station bar NPC (unnamed, save point)
- Old spacer
- Gives hints zonder direct mission briefings
- "Wrong questions get you disappeared"

## Tijdlijn context

- Spel start: "jaar 0" (nu)
- Mira stierf 3 jaar geleden
- Rex stal USP Talon 2 jaar geleden
- MVP speelt 2 jaar na steal, Rex is gevestigd bounty hunter

## Naming conventions

**Good examples (use)**:
- Rex Varn, Mira Voss, Dorian Harkon III
- Places: Korrigan-3, Penal Station Krait, Sector 7
- Ships: USP Talon, Harkon Blade, Ghost Runner
- Factions: The Fringe, Ghost Market, Phantom Collective

**Avoid in MVP (save voor full build)**:
- Synthari naming (Vara Prime, Echo van Zes, Null)
- Sector 0 references (verboden zone)
- Tyvek Convergence (ancient history)

## Writing tone

**Good**:
- "Pulse cannons running hot. Take the left flank."
- "Credit wire cleared. Mission good."
- "The Ledger doesn't forget. Neither do I."

**Avoid**:
- Overly dramatic speeches
- Exposition dumps
- Hero monologues
- Explicit moralizing

Rex Varn is tired, not theatrical.

## Visual style reference

- Noir-industrial
- Space station interiors: dim, amber lighting, metal walls, smoke
- Ship combat: dark starfields, faction-colored projectiles, sharp explosions
- Station: holo displays in faction colors, worn uniforms

**MVP pragmatiek**: gekochte pixel art packs als placeholder, eigen renders waar NOVA pipeline klaar is. Niet perfecte art nodig - coherent genoeg.

## Referentie games

- Tyrian 2000 (visuele stijl basis)
- Raptor: Call of the Shadows (combat feel)
- Wing Commander: Privateer (mission system + factions)
- Later in full build: Blackthorne (planetside mode)

## Wat NIET in MVP canon

Bewaar voor full build:
- Synthari lore (aparte tracking)
- Surilians connectie
- 443 miljoen jaar oude geschiedenis
- Sector 0 / De Kern / De Rand / De Stilte
- Phantom Collective deep philosophy
- Helios-Synthari rechtszaak
- Volledige Ledger unraveling

MVP is introductie aan de wereld, niet encyclopedie.
