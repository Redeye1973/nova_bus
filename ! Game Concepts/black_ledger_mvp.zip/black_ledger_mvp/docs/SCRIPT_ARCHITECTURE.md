# Script Architecture - Black Ledger MVP

## Folder structuur

```
L:\1 Nova Cursor Output\Dark Ledger\
├── project.godot
├── icon.svg
├── README.md
├── .gitignore
├── scripts/
│   ├── core/
│   │   ├── game_constants.gd         # Enums, constants
│   │   ├── asset_catalog.gd          # Asset loading
│   │   ├── health_component.gd       # Reusable health/shield
│   │   ├── ship_component.gd         # Ship component resource
│   │   └── nova_pipeline_client.gd   # NOVA agent calls
│   ├── managers/
│   │   ├── game_state.gd             # Autoload: cross-scene state
│   │   ├── audio_manager.gd          # Autoload: SFX + music
│   │   ├── save_manager.gd           # Autoload: save/load
│   │   ├── settings_manager.gd       # Autoload: user settings
│   │   ├── reputation_manager.gd     # Autoload: faction reputation
│   │   ├── mission_manager.gd        # Autoload: mission tracking
│   │   ├── story_manager.gd          # Autoload: story flags
│   │   ├── score_manager.gd          # Score + streak
│   │   ├── wave_manager.gd           # Enemy wave spawning
│   │   ├── enemy_spawner.gd          # Formation patterns
│   │   ├── vfx_manager.gd            # Pooled VFX
│   │   └── shop_manager.gd           # Shop transactions
│   ├── player/
│   │   ├── player.gd                 # Main player controller
│   │   ├── player_input.gd           # Input handling
│   │   └── player_weapons.gd         # Weapon slot management
│   ├── enemies/
│   │   ├── enemy_base.gd             # Base enemy class
│   │   ├── ai/
│   │   │   ├── rookie_ai.gd
│   │   │   ├── veteran_ai.gd
│   │   │   └── ai_base.gd
│   │   ├── bosses/
│   │   │   └── helios_enforcer.gd
│   │   ├── named/
│   │   │   └── daxus_voss.gd         # Missie 3 target
│   │   └── formations/
│   │       ├── formation_base.gd
│   │       ├── formation_v.gd
│   │       ├── formation_line.gd
│   │       └── formation_swarm.gd
│   ├── weapons/
│   │   ├── weapon_base.gd
│   │   ├── pulse_cannon.gd
│   │   ├── missile_launcher.gd
│   │   ├── missile_projectile.gd
│   │   └── emp_device.gd
│   ├── levels/
│   │   ├── level_base.gd
│   │   └── level_1_korrigan.gd
│   ├── missions/
│   │   ├── mission_base.gd
│   │   ├── mission_clean_sweep.gd
│   │   ├── mission_cargo_run.gd
│   │   └── mission_bounty_voss.gd
│   ├── station/
│   │   ├── station_controller.gd
│   │   └── npcs/
│   │       ├── cargo_ship_ai.gd
│   │       └── bar_npc.gd
│   ├── ui/
│   │   ├── main_menu.gd
│   │   ├── main_menu_placeholder.gd  # Verwijderd na prompt 31
│   │   ├── hud.gd
│   │   ├── pause_menu.gd
│   │   ├── mission_briefing.gd
│   │   ├── mission_debriefing.gd
│   │   ├── bounty_board_ui.gd
│   │   ├── shop_ui.gd
│   │   ├── station_ui.gd
│   │   ├── save_slots_ui.gd
│   │   ├── character_creation.gd
│   │   ├── settings_menu.gd
│   │   └── transition_manager.gd
│   ├── items/
│   │   └── powerup.gd
│   ├── resources/
│   │   ├── ship_data.gd              # Resource class
│   │   ├── weapon_data.gd            # Resource class
│   │   ├── enemy_data.gd             # Resource class
│   │   ├── mission_data.gd           # Resource class
│   │   └── faction_data.gd           # Resource class
│   └── cutscenes/
│       ├── intro_cutscene.gd
│       └── ending_teaser.gd
├── scenes/
│   ├── main_menu/
│   │   └── main_menu.tscn
│   ├── player/
│   │   └── player.tscn
│   ├── enemies/
│   │   ├── harkon_rookie.tscn
│   │   ├── harkon_veteran.tscn
│   │   └── bosses/
│   │       └── helios_enforcer.tscn
│   ├── weapons/
│   │   ├── pulse_cannon.tscn
│   │   ├── missile.tscn
│   │   └── emp_pulse.tscn
│   ├── levels/
│   │   ├── level_base.tscn
│   │   ├── level_1_korrigan.tscn
│   │   ├── mission_sector_alpha.tscn  # Missie 1
│   │   ├── mission_sector_beta.tscn   # Missie 2
│   │   └── mission_sector_gamma.tscn  # Missie 3
│   ├── station/
│   │   └── outer_rim_outpost.tscn
│   ├── ui/
│   │   ├── hud.tscn
│   │   ├── mission_briefing.tscn
│   │   ├── mission_debriefing.tscn
│   │   ├── bounty_board.tscn
│   │   ├── shop.tscn
│   │   ├── station_hub_ui.tscn
│   │   ├── save_slots.tscn
│   │   ├── character_creation.tscn
│   │   ├── settings_menu.tscn
│   │   └── pause_menu.tscn
│   ├── effects/
│   │   ├── explosion_small.tscn
│   │   ├── explosion_large.tscn
│   │   ├── shield_hit.tscn
│   │   ├── muzzle_flash.tscn
│   │   └── engine_thruster.tscn
│   └── cutscenes/
│       ├── intro_cutscene.tscn
│       └── ending_teaser.tscn
├── resources/
│   ├── ships/
│   │   ├── usp_talon.tres
│   │   └── [future ships als locked previews]
│   ├── weapons/
│   │   ├── pulse_cannon_lv1.tres
│   │   ├── pulse_cannon_lv2.tres
│   │   ├── pulse_cannon_lv3.tres
│   │   ├── missile_launcher.tres
│   │   └── emp_device.tres
│   ├── enemies/
│   │   ├── harkon_rookie.tres
│   │   ├── harkon_veteran.tres
│   │   ├── helios_enforcer.tres
│   │   └── daxus_voss.tres
│   ├── missions/
│   │   ├── mission_clean_sweep.tres
│   │   ├── mission_cargo_run.tres
│   │   └── mission_bounty_voss.tres
│   ├── factions/
│   │   ├── harkon.tres
│   │   ├── helios.tres
│   │   ├── marshal.tres
│   │   ├── ghost_market.tres
│   │   ├── phantom.tres
│   │   └── fringe.tres
│   └── components/
│       ├── hull_fighter_medium.tres
│       ├── wings_swept_small.tres
│       ├── engine_dual_standard.tres
│       └── cockpit_bubble_single.tres
├── assets/
│   ├── sprites/
│   │   ├── ships/
│   │   ├── enemies/
│   │   ├── bosses/
│   │   ├── projectiles/
│   │   ├── effects/
│   │   └── ui/
│   ├── audio/
│   │   ├── music/
│   │   ├── sfx/
│   │   └── voice/
│   └── fonts/
├── save_data/
│   └── [Saves, niet in git]
├── docs/
│   ├── build_log_YYYY-MM-DD.md
│   ├── known_issues.md
│   ├── playtest_notes.md
│   └── balance_report.md
└── exports/
    └── [Windows builds, niet in git]
```

## Class hierarchie

### Autoloads (singletons, altijd aanwezig)

1. **GameConstants** - niet extends Node, static-like via autoload
2. **GameState** - cross-scene runtime state
3. **AudioManager** - music + SFX playback
4. **SaveManager** - serialization
5. **SettingsManager** - user prefs
6. **ReputationManager** - faction reputation tracking
7. **MissionManager** - active mission state
8. **StoryManager** - story flags

Niet als autoload (wel per scene):
- ScoreManager (per level)
- WaveManager (per level)
- VFXManager (per level, maar pooled)

### Base classes (inheritance chain)

```
Node2D
├── CharacterBody2D
│   ├── Player (scripts/player/player.gd)
│   └── EnemyBase (scripts/enemies/enemy_base.gd)
│       ├── HarkonRookie
│       ├── HarkonVeteran
│       ├── HeliosEnforcer (boss)
│       └── DaxusVoss (named target)
├── Area2D
│   ├── ProjectileBase
│   │   ├── PulseProjectile
│   │   └── MissileProjectile
│   └── PowerUp
└── Node
    ├── HealthComponent
    ├── WeaponBase
    │   ├── PulseCannon
    │   ├── MissileLauncher
    │   └── EMPDevice
    └── AIBase
        ├── RookieAI
        └── VeteranAI
```

### Resource classes

```
Resource
├── ShipData
├── WeaponData
├── EnemyData
├── MissionData
├── FactionData
└── ShipComponent
```

### Scenes

Elk belangrijk ding is een losse scene:
- Player = scene met root Player node + children
- Enemies = scenes met root EnemyBase + AI component + sprite
- Weapons = scenes met root WeaponBase + particles
- Levels = scenes met root LevelBase + contents
- UI elements = CanvasLayer scenes

## Signal patterns

### Global events (via GameState)

```gdscript
# GameState signals
game_started
game_paused(paused: bool)
scene_changed(scene_name: String)
player_died
player_respawned
```

### Player signals

```gdscript
# Player.gd
health_changed(current: int, max: int)
shield_changed(current: int, max: int)
weapon_fired(weapon_type: int)
died
```

### Manager signals

```gdscript
# MissionManager
mission_accepted(mission_id: StringName)
mission_completed(mission_id: StringName, reward: int)
mission_failed(mission_id: StringName, reason: String)
objective_progress(objective_id: StringName, current: int, total: int)

# ReputationManager  
rep_changed(faction: int, old: int, new: int)
rep_threshold_crossed(faction: int, threshold: String)

# WaveManager
wave_started(wave_index: int)
wave_completed(wave_index: int)
all_waves_done
boss_spawned
```

### UI events

```gdscript
# HUD subscribes to:
- player.health_changed
- player.shield_changed
- ScoreManager.score_changed
- ScoreManager.streak_changed
- MissionManager.objective_progress
```

## Data flow patterns

### Save/Load

```
SaveManager.save_game(slot)
  ↓
Collect state from:
  - GameState (character name/type)
  - ReputationManager (faction values)
  - MissionManager (progress)
  - StoryManager (flags)
  - Player (ship + inventory)
  ↓
Serialize to JSON
  ↓
Write to user://save_slot_X.save
```

### Level loading

```
User clicks "Accept Mission"
  ↓
MissionManager.start_mission(mission_id)
  ↓
Load mission scene (level file)
  ↓
Level instantiates:
  - Spawn player at start position
  - Init WaveManager with mission config
  - Show mission HUD
  - Start wave 1
  ↓
Mission events update MissionManager.objective_progress
  ↓
On win/lose:
  - MissionManager.complete_mission or fail_mission
  - Show debriefing
  - Return to station
```

### NOVA pipeline integration

```
Asset request at runtime:
AssetCatalog.get_sprite("helios_enforcer_pristine")
  ↓
Check if custom asset exists in res://assets/
  ├─ YES: return Texture
  └─ NO: 
      - Check .nova_pipeline_jobs.json for job
      - If job completed: reload + return
      - If pending: return placeholder
      - Trigger pipeline via webhook if not started
```

## Coding conventions

### GDScript style

```gdscript
# Classes PascalCase
class_name PlayerShip

# Vars snake_case
var current_speed: float = 0.0

# Constants UPPER_SNAKE
const MAX_BOOST_DURATION: float = 3.0

# Signals snake_case
signal health_changed(current: int, max: int)

# Functions snake_case
func take_damage(amount: int) -> void:
    pass

# Private methods underscore prefix
func _update_shield() -> void:
    pass

# Type hints altijd
var target: Node2D = null
func get_nearest_enemy() -> EnemyBase:
    pass
```

### Comments

- **Engels** voor code comments (standaard development)
- **Nederlands** voor canon/design references
- `# TODO:`, `# FIXME:`, `# NOTE:` conventions
- Public API docstring in triple-quote

### File organization

Per script file:
1. `class_name` declaration (top)
2. `extends` declaration
3. Signals
4. Constants
5. Exported variables
6. Public variables
7. Private variables (_prefix)
8. `_ready()`, `_process()`, etc (in Godot lifecycle order)
9. Public methods
10. Private methods
11. Static methods

## Performance principes

### Pooling

Gebruik object pools voor:
- Bullets/projectiles (kan 100+ tegelijk zijn)
- Explosion VFX
- Small enemies

### LOD

MVP simpel:
- Off-screen enemies: freeze AI
- Far distance: skip VFX
- 60+ entities: reduce particles

### Physics

- Simple collision shapes (geen concave)
- Minimize rigidbody count
- Use Area2D voor triggers, niet collision
- Disable physics voor stationary objects

## Testing strategy

### Unit tests (optional in MVP, nice-to-have)

Via GUT framework:
- Test ShipData calculations
- Test ReputationManager threshold logic
- Test MissionManager state machine

### Integration tests

Via scene test scripts (F6 in Godot):
- Player movement test scene
- Weapon fire test scene
- Enemy AI test scene

### Playtest

Per fase:
- Speel manual door nieuwe features
- Document issues in known_issues.md
- Verify oude features nog werken

### Full playthrough tests

Final fase:
- 5+ complete playthroughs
- Different strategieën proberen
- Balance feedback verzamelen

## Version control

### Branching

MVP simpel:
- `main` branch
- Commits per prompt
- Tags bij milestones (v0.1.0-mvp-fase1-done, etc)

Full build kan feature branches krijgen.

### Commit messages

Format:
```
feat(scope): korte beschrijving

Details waarom + wat veranderde.

Refs: prompt_XX
```

### Tags

- `v0.1.0-mvp-fase1-done` (na Fase 1)
- `v0.1.0-mvp-alpha` (na alle 42 prompts)
- `v0.1.0-mvp` (na polish + playtest)

## Localization

MVP: Nederlands voor comments + UI mag Engels of Nederlands zijn (kies één).

Framework:
- Godot i18n via tr() function
- CSV of PO files voor strings
- Niet critical voor MVP, full build implements

## Deployment

MVP output: portable Windows zip
- Contains .exe + .pck
- Run in place, no installer
- Config in user://
- Saves in user://
