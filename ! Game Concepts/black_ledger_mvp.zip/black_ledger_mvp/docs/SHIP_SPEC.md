# Ship Specifications - MVP

## USP Talon (enige speelbaar ship in MVP)

### Achtergrond

- Rex's gestolen starter ship uit Korrigan-3 Hangar 7
- Standaard Helios patrol fighter, pre-production model
- "USP" = Universal Security Platform (Helios designation)
- Getekend door cluttered history: nicks, faded paint, improvised repairs

### Base stats

```
ship_id: "usp_talon"
ship_class: FIGHTER
faction: NONE (ex-Helios, Rex-branded)
base_price: 6000 (in-game, start ship)

physical:
  length: 10
  width: 8
  height: 3
  mass: 1.0  # multiplier

combat:
  hp_shield_max: 100
  hp_armor_max: 100
  shield_regen_rate: 8.0  # per second
  shield_regen_delay: 2.5  # seconds no damage
  
movement:
  speed_max: 600
  acceleration: 300
  rotation_speed: 3.0  # rad/s
  boost_multiplier: 1.8
  boost_duration: 3.0
  boost_cooldown: 10.0
  
slots:
  total: 4
  weapon_slots_min: 1  # moet minstens 1 weapon
  weapon_slots_max: 2
  cargo_slots_max: 3  # voor MVP: cargo system niet actief, slots ongebruikt
  
generator:
  energy_max: 100
  energy_regen: 20  # per second
```

### Starter loadout

```
weapons:
  - slot_front: PULSE_CANNON_LV1  # starter weapon
  - slot_rear: EMPTY  # eerste upgrade mogelijkheid
  
upgrades: []  # geen initial upgrades

inventory:
  missile_ammo: 0  # koopt in shop
```

### Visueel

**Silhouette**: Pijlvorm, twee korte vleugels naar achteren, single cockpit bubble vooraan, dual thruster achteraan.

**Kleurenschema starter**:
- Hull: gedoofd grijs (#5a5a66)
- Accent: rood stripes (Helios insignia, oorspronkelijk) - gedeeltelijk overgeschilderd
- Thruster glow: oranje-wit
- Cockpit glass: blauw tint

**Damage states visueel**:
- Pristine (100% armor): zoals beschreven
- Damaged (50-99% armor): scratches, scorch marks op 1-2 plekken
- Critical (1-49% armor): visible damage, flickering panels, smoke trails

### Sprite requirements

**MVP**:
- 1 rotation angle (top-down view, player always faces up from ship perspective)
- Engine flame animatie (3 frames idle, 5 frames boost)
- Damage state swap (full → damaged → critical sprites)
- Muzzle flash position (waar weapons vuren)

**Sprite sheet layout**:
```
usp_talon_sheet.png (256x256)
├── idle_pristine (64x64)
├── idle_damaged (64x64)
├── idle_critical (64x64)
└── engine_flames (5 frames x 64x64)
```

### Audio

**MVP**: 
- Engine hum (looping ambient)
- Boost activation whoosh
- Thruster rumble bij acceleration
- Shield impact (zachte pulse)
- Armor impact (harder thud)
- Ship destruction (explosion chain)

Placeholder audio via AudioStreamGenerator indien ElevenLabs/Audiocraft niet beschikbaar.

## Andere ships in MVP

Alleen als **locked/preview** in Hangar UI:
- Harkon Blade (locked, price 12000)
- Helios Excavator (locked, price 18000)
- Marshal Enforcer (locked, price 15000)
- Ghost Runner (locked, price 20000)
- Phantom Wraith (locked, price 25000)
- Void Stalker (locked, price 22000)
- The Remnant (locked, price 50000, "??? coming")
- The Drifter (locked, price ???, "REQUIRES SPECIAL UNLOCK")

Deze ships krijgen placeholder icons (gekleurd silhouet) maar zijn niet speelbaar in MVP. Full build implementeert ze.

## Ship component systeem (MVP framework)

### Architectuur

```gdscript
class_name ShipData extends Resource

@export var ship_id: StringName
@export var display_name: String
@export var description: String
@export var ship_class: GameConstants.ShipClass
@export var faction: GameConstants.Faction

# Physical
@export var mass_multiplier: float = 1.0

# Combat
@export var shield_max: int = 100
@export var armor_max: int = 100
@export var shield_regen_rate: float = 8.0
@export var shield_regen_delay: float = 2.5

# Movement
@export var speed_max: float = 600.0
@export var acceleration: float = 300.0
@export var rotation_speed: float = 3.0
@export var boost_multiplier: float = 1.8

# Components (MVP: hardcoded USP Talon, full build: swappable)
@export var hull_component: ShipComponent
@export var wing_component: ShipComponent
@export var engine_component: ShipComponent
@export var cockpit_component: ShipComponent

# Slots
@export var total_slots: int = 4
@export var weapon_slots_min: int = 1
@export var weapon_slots_max: int = 2

# Visual
@export var sprite_sheet: Texture2D
@export var icon: Texture2D
@export var preview_model: PackedScene  # For hangar 3D preview, later

# Economy
@export var base_price: int = 6000
```

### MVP implementatie USP Talon

```gdscript
# resources/ships/usp_talon.tres (Godot Resource)
[gd_resource type="ShipData" format=3]

[ext_resource path="res://resources/components/hull_fighter_medium.tres" type="ShipComponent"]
[ext_resource path="res://resources/components/wings_swept_small.tres" type="ShipComponent"]
[ext_resource path="res://resources/components/engine_dual_standard.tres" type="ShipComponent"]
[ext_resource path="res://resources/components/cockpit_bubble_single.tres" type="ShipComponent"]
[ext_resource path="res://assets/sprites/ships/usp_talon_sheet.png" type="Texture2D"]

[resource]
ship_id = &"usp_talon"
display_name = "USP Talon"
description = "Standard Helios patrol fighter. Rex Varn's stolen starter ship."
ship_class = 0  # FIGHTER
faction = 0  # NONE

mass_multiplier = 1.0
shield_max = 100
armor_max = 100
# ... etc per spec

hull_component = ExtResource(1)
wing_component = ExtResource(2)
# etc

sprite_sheet = ExtResource(5)
base_price = 6000
```

### Future-proofing voor Full Build

Framework moet support:
- Runtime component swap (in hangar)
- Stats re-calculation bij component change
- Faction palette apply op components
- Damage states per component (wing damaged, engine out, etc)

**MVP**: Framework aanwezig maar alleen USP Talon loadout bestaat.
**Full build**: 9 ships + 50+ components + color schemes.

## Performance targets

**MVP ship**:
- Godot draw calls: < 5 per ship
- Physics: 1 RigidBody2D, 1-2 CollisionShape2D per ship
- Per frame update: < 0.5ms
- Support 20+ concurrent ships (player + 19 enemies) zonder performance drop

**Shader use**:
- Minimaal in MVP (kosten devel tijd)
- Default sprite materials
- Additief blending voor projectiles
- Shield overlay via simpele modulate tint

## Animation systeem (MVP)

- AnimatedSprite2D voor engine flames
- Tween voor boost effect
- Modulate voor damage flash
- Geen complex skeletal animation in MVP

Full build voegt toe:
- Ship part rotation (turret tracking)
- Boarding animations
- Destruction sequences
- Faction paint swap animations
