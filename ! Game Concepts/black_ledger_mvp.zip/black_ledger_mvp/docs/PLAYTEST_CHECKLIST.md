# Playtest Checklist MVP

## Per fase playtest

### Na Fase 1 (Foundation)

- [ ] Project opent zonder errors
- [ ] Alle 8 autoloads initialiseren
- [ ] Main menu placeholder toont
- [ ] Console shows startup logs correctly
- [ ] Geen memory leaks bij herhaald laden

### Na Fase 2 (Core Gameplay)

- [ ] Player ship beweegt met WASD
- [ ] Player aimt met muis naar cursor
- [ ] Pulse Cannon vuurt (click of space)
- [ ] Shield bar zichtbaar, regenereert na hit
- [ ] Armor daalt bij hits door shield
- [ ] Score telt op bij enemy kills
- [ ] Enemies spawnen en bewegen
- [ ] Rookie AI voelt anders dan Veteran AI
- [ ] SFX speelt bij fire/hit/explosion
- [ ] Geen frame drops bij 10+ entities

### Na Fase 3 (First Level)

- [ ] Level 1 Korrigan scene opent
- [ ] Parallax achtergrond scrollt
- [ ] Wave 1 spawns rookies
- [ ] Wave 2 spawns mix
- [ ] Boss verschijnt na wave 2
- [ ] Boss phase 1, 2, 3 merkbaar anders
- [ ] Power-ups droppen van enemies
- [ ] Pickup power-up werkt (heal, shield boost, missile)
- [ ] Level end triggert station transition
- [ ] Level herhalen (via debug) werkt

### Na Fase 4 (Station Hub)

- [ ] Station scene opent na level 1 win
- [ ] Sidebar navigeerbaar
- [ ] Shop toont items met correct prijzen
- [ ] Kopen aftrekt credits, adds to inventory
- [ ] Bounty Board toont 3 bounties
- [ ] Main menu werkt met new game / continue
- [ ] Save slots UI toont 3 slots
- [ ] Save game werkt, data persistent na restart
- [ ] Character creation scene werkt
- [ ] Naam + type saved

### Na Fase 5 (Missions)

- [ ] Accept mission triggert briefing
- [ ] Briefing typewriter effect werkt
- [ ] Accept start mission scene
- [ ] Missie 1 (Clean Sweep): 15 kills win
- [ ] Missie 2 (Cargo Run): escort ship volgt pad
- [ ] Missie 3 (Bounty Voss): kan target identificeren + killen
- [ ] Debriefing toont correct reward + rep changes
- [ ] Rep waarden updated correctly

### Na Fase 6 (Integration)

- [ ] Volledige playthrough zonder crashes
- [ ] Main menu → character create → intro → level 1 → boss → station → 3 missies → ending teaser
- [ ] Save/load midden in session werkt
- [ ] Alle missies completable
- [ ] Ending teaser triggert na mission 3
- [ ] Credits roll na teaser
- [ ] Windows build exporteert
- [ ] Build draait op test machine

## Daily playtest (5-10 min, elke dag tijdens build)

- [ ] Project opent zonder errors
- [ ] Laatste feature getest
- [ ] Oude features nog werkend
- [ ] Geen regression issues
- [ ] FPS 60 tijdens combat

## Alpha playtest (na fase 6, voor release)

**5 complete playthroughs, verschillende strategieën:**

### Playthrough 1: Speed run
- Doelstelling: zo snel mogelijk alle 3 missies
- Track: totale tijd
- Bugs noteren?

### Playthrough 2: Efficient build
- Doelstelling: maximaliseer credits
- Gebruik alle upgrades
- Balance voelen OK?

### Playthrough 3: No upgrades
- Doelstelling: minimale spend
- Test of basis USP Talon mission 3 kan halen
- Difficulty curve OK?

### Playthrough 4: Try to break
- Doelstelling: find edge cases, exploits, bugs
- Schiet op alles, push systemen
- Document alle crashes/glitches

### Playthrough 5: Fresh eyes
- Doelstelling: alsof eerste keer
- Wat is confusing?
- Waar stok je?
- UX feedback

## Issue tracking

Voor elke bug/issue:
- [ ] Reproduceerbaar? Steps noteren
- [ ] Severity: Blocker / High / Medium / Low
- [ ] In `docs/known_issues.md` loggen
- [ ] Priority per fase einde beoordelen

## Release criteria (v1.0.0-mvp)

**Must have (alpha release blockers):**

- [ ] Geen crashes in 5 full playthroughs
- [ ] Save/load werkt robuust
- [ ] Level 1 boss fight completable
- [ ] Alle 3 missies speelbaar en completable
- [ ] Ending teaser triggert correct
- [ ] Build exporteert en draait

**Should have (strongly preferred):**

- [ ] 60 FPS stabiel tijdens combat
- [ ] Audio werkt (placeholder OK)
- [ ] Settings persist na restart
- [ ] Keybindings werken
- [ ] Pause menu functioneel

**Nice to have (niet blockers):**

- [ ] Polish animations
- [ ] Custom NOVA-generated art volledig
- [ ] Voice acting
- [ ] Generated music
- [ ] Controller support

## Testing infrastructure

### Debug mode

Tijdens development, enable F3 debug overlay:
- FPS counter
- Memory usage
- Active entities count
- Player position
- Current scene

### Cheats (development only)

Voor snelle testing:
- F1: skip to boss
- F2: give 10000 credits
- F3: toggle debug overlay
- F4: heal player
- F5: god mode toggle
- F8: complete current mission instantly

**Alle cheats disablen in release build.**

### Automated tests (optioneel)

Als je tijd hebt in fase 6:

```gdscript
# test_helpers.gd - handmatige Godot test runners
func test_player_movement():
    var player = preload("res://scenes/player/player.tscn").instantiate()
    add_child(player)
    # simulate input
    Input.action_press("move_up")
    await get_tree().create_timer(0.1).timeout
    assert(player.velocity.y < 0)
    player.queue_free()
```

## Reports template

Na elke major playtest, schrijf:

```markdown
# Playtest Report - [datum]

## Session info
- Duration: [tijd]
- Build version: v0.1.0-mvp-faseX
- Platform: Windows 10/11
- Player: [jezelf of tester naam]

## Playthrough summary
- Missies attempted: [lijst]
- Missies completed: [lijst]
- Credits final: [bedrag]
- Time to complete: [minuten]

## Findings

### Blockers
[beschrijf]

### High priority bugs
[beschrijf]

### Balance issues
[beschrijf]

### UX issues
[beschrijf]

### Positive
[wat werkte goed]

## Action items
- [ ] Fix X voor volgende test
- [ ] Address Y in volgende prompt
- [ ] Consider Z voor full build
```

Sla op in `docs/playtest_report_YYYY-MM-DD.md`.
