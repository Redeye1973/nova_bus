# Black Ledger MVP - Vertical Slice Build

## Wat dit pakket doet

Bouwt de **eerste speelbare versie** van Black Ledger: een vertical slice die het kernidee volledig demonstreert zonder alle content.

## Wat is in de MVP

**Speelbare content:**
- Main menu met save/load
- Character creation (alleen Man als starter, Vrouw/Synthari in full build)
- Intro cutscene (Korrigan-3 ontsnapping)
- Eerste level met 2 waves + 1 boss
- Eén station (Outer Rim Outpost)
- Winkel met basis ship upgrades
- Bounty board met 3 starter bounties
- Eerste drie missies: 1 eliminate + 1 escort + 1 bounty
- Ship combat met 1 starter ship (USP Talon)
- 3 wapen types beschikbaar (basic cannon, missiles, EMP)
- HUD met shields/armor/score/credits
- Ending teaser (naar full build)

**Technisch:**
- Godot 4.6.2 project opgezet
- Modulaire ship component systeem (basis)
- Save/load werkt
- Settings menu
- Audio mixing (SFX + music placeholders)
- Windows build export

## Wat is NIET in de MVP

Voor v1.1+ (volledige build):
- Volledige 28 levels
- 3 endings (Clean Slate / New Ledger / Ghosted)
- Complete faction systeem (6 facties interactief)
- Wormholes / starmap
- Datapad ledger book
- Procedural biomes
- Synthari race speelbaar
- Boarding minigame
- Cargo scan enforcement
- Planetside GIS levels (Blackthorne-mode)
- Cross-reference engine
- Story integration met Surilians canon
- Alle voice acting
- Meerdere ships (v1.0 heeft alleen USP Talon)

## Waarom deze scope

**Speelbaar bewijs van concept in 4-6 weken.**

Na MVP kun je:
- Aan vrienden/playtesters laten zien
- Feedback verzamelen
- Systemen valideren voordat je ze uitbouwt
- Motivatie behouden door concrete voortgang

Als MVP werkt: ga door naar full build.
Als MVP niet werkt: scope aanpassen voordat je meer bouwt.

## Voorwaarden

- [ ] NOVA v2 Pipeline klaar (Pipeline Build package uitgevoerd)
- [ ] Agents 20, 02, 21, 22, 23, 25, 26 active (asset pipeline)
- [ ] Agent 10 Game Balance Jury active
- [ ] Godot 4.6.2 op PC geïnstalleerd
- [ ] Cursor Pro actief
- [ ] Git repo ready voor Black Ledger
- [ ] 1000 Meshy credits (optioneel, voor reference models)

## Package structuur

```
black_ledger_mvp/
├── README.md (dit)
├── 00_master/
│   ├── START_HERE.md
│   ├── GAME_DESIGN_MVP.md (compacte GDD)
│   ├── SCOPE_DEFINITION.md (wat WEL, wat NIET)
│   └── PROMPT_INDEX.md
├── 01_foundation/        (prompts 1-8: project setup)
├── 02_core_gameplay/     (prompts 9-18: combat, player, enemies)
├── 03_first_level/       (prompts 19-26: level + boss)
├── 04_station_hub/       (prompts 27-32: station + UI)
├── 05_missions/          (prompts 33-38: 3 missies + briefings)
├── 06_integration/       (prompts 39-42: glue + testing + build)
├── docs/
│   ├── BLACK_LEDGER_CANON.md (compacte lore)
│   ├── SHIP_SPEC.md
│   ├── SCRIPT_ARCHITECTURE.md
│   └── PLAYTEST_CHECKLIST.md
├── utils/
│   ├── godot_project_health.ps1
│   ├── asset_manifest_check.py
│   └── playtest_automation.gd
└── assets_plan/
    ├── MVP_ASSET_LIST.md
    ├── pipeline_jobs.json (NOVA agent calls)
    └── placeholder_spec.md
```

## Sequentie

42 prompts in 6 fases:

### Fase 1 Foundation (prompts 1-8)
- Godot project setup
- Autoloads + singletons
- Resource definities
- Asset import pipeline
- Git setup

### Fase 2 Core Gameplay (prompts 9-18)
- Player ship controller
- Weapon systeem
- Enemy AI (rookie level)
- Health/shield component
- Score manager
- Wave manager basis
- VFX systeem
- Audio manager

### Fase 3 First Level (prompts 19-26)
- Level 1: Korrigan-3 escape
- Parallax background
- Enemy spawning
- Power-ups
- Boss: "Helios Enforcer"
- Win/lose conditions
- Level transitions

### Fase 4 Station Hub (prompts 27-32)
- Station scene
- Winkel UI + systeem
- Bounty board UI
- Character creation
- Save/load systeem
- Main menu

### Fase 5 Missions (prompts 33-38)
- Mission briefing UI (Privateer-stijl)
- 3 missies gedefinieerd
- Mission manager integratie met V1 systeem
- Reputation tracking
- News ticker
- Ending teaser

### Fase 6 Integration (prompts 39-42)
- End-to-end playthrough
- Balance pass
- Build export (Windows)
- Playtest rapport

## Tijdsinschatting

**Per prompt**: 2-4 uur Cursor werk
**Totaal**: 42 prompts × 3u = 126 uur
**Met 24/7 PC**: 3-5 weken doorlopend
**Met 8u/dag**: 16 weken

Realistisch voor een werkende eerste versie: **6-8 weken solo dev met 24/7 build**.

## Na MVP

Als vertical slice werkt:
- Open volgende package: `black_ledger_full_build.zip`
- Dat bevat prompts 43+ voor complete game
- Incrementeel uitbouwen

## Hoe te gebruiken

1. Unzip in `L:\!Nova V2\black_ledger_mvp\`
2. Open `00_master/START_HERE.md`
3. Volg prompts 1 tot 42 sequentieel
4. Tussen prompts: test, commit, volgende

## Documentatie

Tijdens build, Cursor schrijft:
- `docs/build_log_YYYY-MM-DD.md` - dagelijks log
- `docs/known_issues.md` - bijgewerkte bugs lijst
- `docs/playtest_notes.md` - jouw feedback per playthrough

Commit alles regelmatig.

## Release kandidaat

Aan einde van MVP heb je:
- Werkende Windows build
- Speelbaar van menu tot level 1 boss tot station tot eerste missie
- 30-60 minuten gameplay content
- Goed genoeg voor friends-and-family testen

Je kunt dan beslissen: doorbouwen in private? Delen op Itch.io als alpha? Feedback verzamelen?
