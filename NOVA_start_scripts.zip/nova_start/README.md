# NOVA Start/Stop Scripts

## Gebruik

**Starten (dubbelklik):**
- `NOVA_start.bat` — start alles: Tailscale, Ollama, bridge services, Hetzner containers, health checks

**Stoppen (dubbelklik):**
- `NOVA_stop.bat` — stopt alleen lokale services (Hetzner blijft draaien)

## Plaatsing

Kopieer beide .bat + .ps1 bestanden naar bijvoorbeeld:
- `L:\!Nova V2\scripts\` (consistent met rest)
- Of een shortcut op je desktop

## Wat het script doet

1. **Tailscale** — service start + connect (als geïnstalleerd op standaard pad)
2. **Ollama** — service start of `ollama serve` background start, health check models
3. **NOVA lokale services** (NSSM) — bridge service, watchdog, heartbeat
   - Als NSSM nog niet geïnstalleerd is (voor Day Build D3): fallback via `start_bridge.ps1`
4. **Bridge health** — localhost:8500 check, max 3 retries
5. **SSH Hetzner test** — zonder password prompt via BatchMode
6. **Hetzner V1 + V2 containers** — status via SSH, auto-restart als down
7. **V1 + V2 endpoint health** — HTTP checks
8. **Samenvatting** — URLs + totale starttijd

## Output

Kleuren in console:
- **[ OK ]** groen — component werkt
- **[INFO]** cyaan — actie bezig
- **[WARN]** geel — niet kritiek probleem
- **[FAIL]** rood — kritiek probleem, aandacht vereist

## Verwachte tijden

- Met alles al running: 5-10 seconden
- Met Hetzner containers die moeten starten: 20-40 seconden
- Als Tailscale/Ollama opnieuw moeten: 10-30 seconden extra

## Aanpassen

Config staat bovenaan NOVA_start.ps1:
```
$HetznerHost = "178.104.207.194"
$V1_URL      = "http://$HetznerHost:5678"
$V2_URL      = "http://$HetznerHost:5679"
```

## Troubleshooting

**"Tailscale niet gevonden":**
- Installeer Tailscale, of pas pad aan in script (zoek `$tailscaleBin`)

**"Ollama niet bereikbaar":**
- Check of `ollama serve` daadwerkelijk draait: `ollama list` in ander venster
- Check poort: `netstat -ano | findstr :11434`

**"SSH faalt":**
- SSH key niet opgezet? Draai eenmalig: `ssh-copy-id root@178.104.207.194`
- BatchMode vereist key-based auth, geen passwords

**"NOVA_Bridge_Service niet geïnstalleerd":**
- Day Build D3 nog niet gedraaid. Script valt dan terug op manual start via start_bridge.ps1.

**"V1/V2 niet bereikbaar":**
- Check Hetzner server status: console.hetzner.com
- SSH naar server + `docker ps` om te zien waar het vastloopt

## Shortcut op Desktop

Rechtsklik NOVA_start.bat → Create Shortcut → Move to Desktop → Rename "NOVA Start"

Optioneel: rechtsklik shortcut → Properties → Change Icon → kies een icon
