# ============================================================
# NOVA_stop.ps1 — stop lokale NOVA services
# Remote containers blijven draaien (die wil je meestal aanhouden)
# ============================================================

function Write-Info($msg) { Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-OK($msg)   { Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }

Write-Host ""
Write-Host "=== NOVA Stop (lokaal) ===" -ForegroundColor Magenta
Write-Host ""

$services = @("NOVA_Heartbeat", "NOVA_Bridge_Watchdog", "NOVA_Bridge_Service")

foreach ($svc in $services) {
    $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
    if ($s -and $s.Status -eq "Running") {
        Write-Info "Stopping $svc..."
        Stop-Service -Name $svc -Force
        Write-OK "$svc stopped"
    } elseif ($s) {
        Write-OK "$svc was niet running"
    } else {
        Write-Warn "$svc niet geïnstalleerd"
    }
}

# Cleanup: kill leftover uvicorn bridge processen
$leftover = Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -and $_.Id -ne $PID }
if ($leftover) {
    Write-Info "Cleanup python processen..."
    foreach ($p in $leftover) {
        try {
            $cmdLine = (Get-CimInstance Win32_Process -Filter "ProcessId = $($p.Id)").CommandLine
            if ($cmdLine -like "*uvicorn*8500*" -or $cmdLine -like "*bridge_watchdog*" -or $cmdLine -like "*bridge_heartbeat*") {
                Stop-Process -Id $p.Id -Force
                Write-OK "Killed PID $($p.Id)"
            }
        } catch {}
    }
}

Write-Host ""
Write-Host "Lokale NOVA services gestopt." -ForegroundColor Green
Write-Host "Remote Hetzner containers blijven draaien." -ForegroundColor DarkGray
Write-Host ""
