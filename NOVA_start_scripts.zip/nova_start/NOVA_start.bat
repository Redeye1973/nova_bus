@echo off
REM ============================================================
REM NOVA_start.bat — start alles op (V1 + V2 + Hetzner + Ollama + Tailscale)
REM ============================================================
REM Wrapt PowerShell script met execution policy bypass
REM Dubbelklik om te starten

powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0NOVA_start.ps1"

REM Houd venster open na afloop (Press any key)
pause
