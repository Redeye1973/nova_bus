@echo off
REM ============================================================
REM NOVA_stop.bat — stop lokale NOVA services (remote blijft draaien)
REM ============================================================

powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0NOVA_stop.ps1"
pause
