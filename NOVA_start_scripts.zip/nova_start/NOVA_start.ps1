# ============================================================
# NOVA_start.ps1 — master startup voor NOVA v1 + v2
# ============================================================
# Start lokaal: bridge, watchdog, heartbeat, Ollama, Tailscale
# Start remote: Hetzner V1 + V2 Docker stacks (als down)
# Health check alles
# ============================================================

$Host.UI.RawUI.WindowTitle = "NOVA Start"

# Kleuren
function Write-Info($msg)    { Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-OK($msg)      { Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Warn($msg)    { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg)     { Write-Host "[FAIL] $msg" -ForegroundColor Red }
function Write-Section($msg) {
    Write-Host ""
    Write-Host "=== $msg ===" -ForegroundColor Magenta
}

# Config
$HetznerHost = "178.104.207.194"
$V1_URL      = "http://$HetznerHost:5678"
$V2_URL      = "http://$HetznerHost:5679"
$V2_WEBHOOK  = "http://$HetznerHost:5680"
$BridgeURL   = "http://localhost:8500/health"
$OllamaURL   = "http://localhost:11434/api/tags"

$timeStart = Get-Date
Write-Host ""
Write-Host "=================================" -ForegroundColor Magenta
Write-Host " NOVA Startup — $(Get-Date -Format 'HH:mm:ss')" -ForegroundColor Magenta
Write-Host "=================================" -ForegroundColor Magenta

# ============================================================
# 1. Tailscale
# ============================================================
Write-Section "Tailscale"

$tailscaleBin = "C:\Program Files\Tailscale\tailscale.exe"
if (Test-Path $tailscaleBin) {
    $tsService = Get-Service -Name "Tailscale" -ErrorAction SilentlyContinue
    if ($tsService) {
        if ($tsService.Status -ne "Running") {
            Write-Info "Starting Tailscale service..."
            Start-Service -Name "Tailscale"
            Start-Sleep 3
        }
        # Bring up (connect)
        try {
            $status = & $tailscaleBin status 2>&1
            if ($LASTEXITCODE -eq 0) {
                Write-OK "Tailscale connected"
                ($status | Select-Object -First 3) | ForEach-Object { Write-Host "       $_" -ForegroundColor DarkGray }
            } else {
                Write-Info "Starting Tailscale connection..."
                & $tailscaleBin up 2>&1 | Out-Null
                Start-Sleep 2
                Write-OK "Tailscale up"
            }
        } catch {
            Write-Warn "Tailscale status check faalde: $_"
        }
    } else {
        Write-Warn "Tailscale service niet geïnstalleerd"
    }
} else {
    Write-Warn "Tailscale niet gevonden op standaard pad"
}

# ============================================================
# 2. Ollama
# ============================================================
Write-Section "Ollama (lokaal)"

# Check of Ollama service of proces draait
$ollamaProcess = Get-Process -Name "ollama*" -ErrorAction SilentlyContinue
$ollamaService = Get-Service -Name "Ollama" -ErrorAction SilentlyContinue

if ($ollamaService -and $ollamaService.Status -ne "Running") {
    Write-Info "Starting Ollama service..."
    Start-Service -Name "Ollama" -ErrorAction SilentlyContinue
    Start-Sleep 3
} elseif (-not $ollamaProcess -and -not $ollamaService) {
    # Try starting via ollama command
    $ollamaBin = Get-Command ollama -ErrorAction SilentlyContinue
    if ($ollamaBin) {
        Write-Info "Starting ollama serve in background..."
        Start-Process -FilePath "ollama" -ArgumentList "serve" -WindowStyle Hidden
        Start-Sleep 4
    } else {
        Write-Warn "Ollama niet gevonden (geen service, geen binary in PATH)"
    }
}

# Health check Ollama
try {
    $r = Invoke-WebRequest -Uri $OllamaURL -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
    $models = ($r.Content | ConvertFrom-Json).models
    Write-OK "Ollama running — $($models.Count) models loaded"
    foreach ($m in $models | Select-Object -First 5) {
        Write-Host "       - $($m.name)" -ForegroundColor DarkGray
    }
} catch {
    Write-Warn "Ollama niet bereikbaar op :11434"
}

# ============================================================
# 3. NOVA lokale services (NSSM)
# ============================================================
Write-Section "NOVA lokale services (NSSM)"

$novaServices = @(
    "NOVA_Bridge_Service",
    "NOVA_Bridge_Watchdog",
    "NOVA_Heartbeat"
)

foreach ($svcName in $novaServices) {
    $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
    if ($svc) {
        if ($svc.Status -ne "Running") {
            Write-Info "Starting $svcName..."
            try {
                Start-Service -Name $svcName
                Start-Sleep 2
                Write-OK "$svcName started"
            } catch {
                Write-Err "$svcName failed to start: $_"
            }
        } else {
            Write-OK "$svcName already running"
        }
    } else {
        Write-Warn "$svcName niet geïnstalleerd (nog niet door Day Build D3/D4 gegaan)"
    }
}

# Als geen NSSM services bestaan: fallback — start bridge manueel
if (-not (Get-Service -Name "NOVA_Bridge_Service" -ErrorAction SilentlyContinue)) {
    Write-Info "Fallback: bridge starten via start_bridge.ps1..."
    $startScript = "L:\!Nova V2\scripts\start_bridge.ps1"
    if (Test-Path $startScript) {
        Start-Process powershell.exe -ArgumentList "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$startScript`"" -WindowStyle Hidden
        Start-Sleep 5
    } else {
        Write-Warn "start_bridge.ps1 niet gevonden — bridge niet gestart"
    }
}

# ============================================================
# 4. Bridge health check
# ============================================================
Write-Section "Bridge health"

$retry = 0
$bridgeOK = $false
while ($retry -lt 3 -and -not $bridgeOK) {
    try {
        $r = Invoke-WebRequest -Uri $BridgeURL -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
        if ($r.StatusCode -eq 200) {
            Write-OK "Bridge online op localhost:8500"
            $bridgeOK = $true
        }
    } catch {
        $retry++
        if ($retry -lt 3) {
            Write-Info "Bridge nog niet bereikbaar, wachten 3s... (poging $retry/3)"
            Start-Sleep 3
        }
    }
}
if (-not $bridgeOK) {
    Write-Err "Bridge niet bereikbaar na 3 pogingen"
}

# ============================================================
# 5. SSH Hetzner connection test
# ============================================================
Write-Section "Hetzner SSH"

try {
    $sshTest = ssh -o BatchMode=yes -o ConnectTimeout=5 "root@$HetznerHost" "echo OK" 2>&1
    if ($sshTest -eq "OK") {
        Write-OK "SSH naar Hetzner werkt ($HetznerHost)"
    } else {
        Write-Err "SSH faalt: $sshTest"
    }
} catch {
    Write-Err "SSH command faalde: $_"
}

# ============================================================
# 6. Hetzner V1 + V2 containers check/start
# ============================================================
Write-Section "Hetzner Docker containers"

$sshCmd = @"
echo '--- V1 ---'
cd /docker/nova-v1 2>/dev/null && docker compose ps --format 'table {{.Name}}\t{{.Status}}' 2>/dev/null || echo 'V1 compose niet gevonden'

echo ''
echo '--- V2 ---'
cd /docker/nova-v2 2>/dev/null && docker compose ps --format 'table {{.Name}}\t{{.Status}}' 2>/dev/null || echo 'V2 compose niet gevonden'
"@

try {
    Write-Info "Container status ophalen via SSH..."
    $containerStatus = ssh -o BatchMode=yes "root@$HetznerHost" $sshCmd 2>&1
    $containerStatus | ForEach-Object { Write-Host "       $_" -ForegroundColor DarkGray }
    
    # Check of er exited/unhealthy containers zijn
    $hasDown = $containerStatus | Select-String -Pattern "Exit|Dead|Restarting" -Quiet
    
    if ($hasDown) {
        Write-Warn "Sommige containers zijn niet healthy — probeer te herstarten..."
        $startCmd = @"
cd /docker/nova-v1 2>/dev/null && docker compose up -d 2>&1
cd /docker/nova-v2 2>/dev/null && docker compose up -d 2>&1
"@
        ssh -o BatchMode=yes "root@$HetznerHost" $startCmd 2>&1 | ForEach-Object {
            Write-Host "       $_" -ForegroundColor DarkGray
        }
        Start-Sleep 5
    }
} catch {
    Write-Err "Container check faalde: $_"
}

# ============================================================
# 7. V1 + V2 endpoint health
# ============================================================
Write-Section "V1 + V2 endpoint health"

$endpoints = @(
    @{Name="V1 N8n"          ; Url=$V1_URL     }
    @{Name="V2 N8n Main"     ; Url=$V2_URL     }
    @{Name="V2 N8n Webhook"  ; Url=$V2_WEBHOOK }
)

foreach ($ep in $endpoints) {
    try {
        $r = Invoke-WebRequest -Uri $ep.Url -UseBasicParsing -TimeoutSec 8 -ErrorAction Stop
        Write-OK "$($ep.Name) → HTTP $($r.StatusCode)"
    } catch {
        # 401 is ook OK (N8n vraagt login) — dat betekent service draait
        if ($_.Exception.Response.StatusCode.value__ -in @(401,403)) {
            Write-OK "$($ep.Name) → HTTP $($_.Exception.Response.StatusCode.value__) (service running)"
        } else {
            Write-Err "$($ep.Name) niet bereikbaar"
        }
    }
}

# ============================================================
# 8. Samenvatting
# ============================================================
$elapsed = (Get-Date) - $timeStart
Write-Section "Samenvatting"
Write-Host "Totale tijd: $([math]::Round($elapsed.TotalSeconds, 1)) sec" -ForegroundColor Cyan
Write-Host ""
Write-Host "Quick URLs:" -ForegroundColor Cyan
Write-Host "  V1 N8n:        $V1_URL" -ForegroundColor White
Write-Host "  V2 N8n:        $V2_URL" -ForegroundColor White
Write-Host "  Bridge tools:  http://localhost:8500/tools" -ForegroundColor White
Write-Host "  Ollama:        http://localhost:11434" -ForegroundColor White
Write-Host ""
Write-Host "NOVA ready." -ForegroundColor Green
Write-Host ""
